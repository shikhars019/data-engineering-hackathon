-- ===========================================================================
-- CHALLENGE 1 - TEAM 5 - The Code Chaos
--
-- THIS IS YOUR FILE. Edit it, save it, then run:   ./check.sh 1
--
-- It already runs, and one test already passes. Your job is to turn the
-- rest green, one task at a time.
--
-- The big idea: nobody can count anything until everyone agrees on the
-- words. 'ACTIVE', 'A', 'LIVE', 'In Payment' and 'INPAY' are five ways of
-- saying one thing. Until you fix that, "how many people are being paid?"
-- has five different answers - and the agency reports that number to Parliament.
-- ===========================================================================

TRUNCATE clean.payment;
TRUNCATE clean.claim;
TRUNCATE clean.claimant;


-- ---------------------------------------------------------------------------
-- Load the people. Written for you: leave it alone.
-- ---------------------------------------------------------------------------
INSERT INTO clean.claimant (nino, title, first_name, last_name, date_of_birth,
                            sex, marital_status, date_of_death, email, phone)
SELECT
    upper(btrim(nino)),
    replace(initcap(btrim(title)), '.', ''),
    initcap(btrim(first_name)),
    initcap(btrim(last_name)),
    util.to_date(date_of_birth, 'YYYY-MM-DD'),
    upper(btrim(sex)),
    CASE WHEN btrim(coalesce(marital_status, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE initcap(btrim(marital_status)) END,
    util.to_date(date_of_death, 'YYYY-MM-DD'),
    CASE WHEN btrim(coalesce(email, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE lower(btrim(email)) END,
    CASE WHEN btrim(coalesce(phone, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE replace(btrim(phone), ' ', '') END
FROM raw.claimant;


INSERT INTO clean.claim (claim_ref, nino, claim_status, pension_type,
                         claim_start_date, qualifying_years, weekly_amount,
                         deferral_indicator, payment_frequency)
SELECT
    c.claim_ref,
    upper(btrim(c.claimant_ref)),

    ----------------------------------------------------------------
    -- TASK 1 - Read this one. It is the pattern for everything else.
    --                                                  <<< START HERE
    -- LOOK FIRST:
    --   ./explore.sh values raw.claim claim_status
    --
    -- Thirteen spellings, three actual meanings. upper(btrim(x)) first,
    -- so you only have to list each spelling once instead of worrying
    -- about capitals and spaces.
    --
    -- This one is finished. Its test already passes. Study it, then do
    -- the same thing for the three below.
    ----------------------------------------------------------------
    CASE upper(btrim(c.claim_status))
        WHEN 'ACTIVE'     THEN 'ACTIVE'
        WHEN 'A'          THEN 'ACTIVE'
        WHEN 'LIVE'       THEN 'ACTIVE'
        WHEN 'IN PAYMENT' THEN 'ACTIVE'
        WHEN 'INPAY'      THEN 'ACTIVE'
        WHEN 'SUSPENDED'  THEN 'SUSPENDED'
        WHEN 'SUSP'       THEN 'SUSPENDED'
        WHEN 'S'          THEN 'SUSPENDED'
        WHEN 'ON HOLD'    THEN 'SUSPENDED'
        WHEN 'CLOSED'     THEN 'CLOSED'
        WHEN 'C'          THEN 'CLOSED'
        WHEN 'CEASED'     THEN 'CLOSED'
        WHEN 'TERMINATED' THEN 'CLOSED'
    END,

    ----------------------------------------------------------------
    -- TASK 3 - Pension type: two schemes describing the same products
    --
    -- LOOK FIRST:
    --   ./explore.sh values raw.claim pension_type
    --
    -- This one needs you to think, not just type. There are TWO different
    -- naming schemes in this column, from two different eras:
    --
    --   the modern names  'New State Pension', 'nSP', 'Single Tier'
    --   the old legal categories  'Category A', 'Cat A', 'Category B'
    --
    -- Category A and Category B are both forms of the OLD pension, so
    -- they both map to BASIC_STATE_PENSION. Getting that wrong is easy
    -- and the counts will tell you if you did.
    --
    -- Allowed answers: NEW_STATE_PENSION, BASIC_STATE_PENSION
    --
    -- TODO: write the CASE. Replace the line below.
    ----------------------------------------------------------------
    CASE upper(btrim(c.pension_type))
        WHEN 'NEW STATE PENSION'   THEN 'NEW_STATE_PENSION'
        WHEN 'NSP'                 THEN 'NEW_STATE_PENSION'
        WHEN 'NEW'                 THEN 'NEW_STATE_PENSION'
        WHEN 'SINGLE TIER'         THEN 'NEW_STATE_PENSION'
        WHEN 'ST'                  THEN 'NEW_STATE_PENSION'
        WHEN 'BASIC STATE PENSION' THEN 'BASIC_STATE_PENSION'
        WHEN 'BSP'                 THEN 'BASIC_STATE_PENSION'
        WHEN 'BASIC'               THEN 'BASIC_STATE_PENSION'
        WHEN 'CATEGORY A'          THEN 'BASIC_STATE_PENSION'
        WHEN 'CAT A'               THEN 'BASIC_STATE_PENSION'
        WHEN 'CATEGORY B'          THEN 'BASIC_STATE_PENSION'
        WHEN 'CAT B'               THEN 'BASIC_STATE_PENSION'
    END,

    util.to_date(c.claim_start_date, 'YYYY-MM-DD'),
    util.to_number(c.qualifying_years)::int,
    util.to_number(c.weekly_amount),

    ----------------------------------------------------------------
    -- TASK 4 - A yes/no flag with eleven spellings
    --
    -- LOOK FIRST:
    --   ./explore.sh values raw.claim deferral_indicator
    --
    -- 'Y' 'y' 'YES' 'Yes' 'TRUE' 'T' '1' all mean yes.
    -- 'N' 'NO' 'FALSE' 'F' '0' and empty all mean no.
    --
    -- The column in clean.claim is a real BOOLEAN, so you need true/false,
    -- not text. In SQL, a comparison IS a boolean:
    --     upper(btrim(x)) IN ('Y','YES','TRUE','T','1')
    -- is already true or false. You do not need a CASE at all.
    --
    -- TODO: replace  false  below with that comparison.
    --       Watch out for the empty ones - coalesce(x, 'N') is your friend.
    ----------------------------------------------------------------
    upper(btrim(coalesce(c.deferral_indicator, 'N'))) IN ('Y','YES','TRUE','T','1'),

    ----------------------------------------------------------------
    -- TASK 5 - How often they get paid
    --
    -- LOOK FIRST:
    --   ./explore.sh values raw.claim payment_frequency
    --
    -- Allowed answers: WEEKLY, FOUR_WEEKLY, QUARTERLY
    -- Careful: '1', '4' and '13' are in there too - they are the number
    -- of weeks between payments, not a count of anything.
    --
    -- TODO: write the CASE, same shape as Task 1.
    ----------------------------------------------------------------
    CASE upper(btrim(c.payment_frequency))
        WHEN 'WEEKLY'      THEN 'WEEKLY'
        WHEN 'W'           THEN 'WEEKLY'
        WHEN 'WKLY'        THEN 'WEEKLY'
        WHEN '1'           THEN 'WEEKLY'
        WHEN '4-WEEKLY'    THEN 'FOUR_WEEKLY'
        WHEN '4W'          THEN 'FOUR_WEEKLY'
        WHEN 'FOUR WEEKLY' THEN 'FOUR_WEEKLY'
        WHEN '4'           THEN 'FOUR_WEEKLY'
        WHEN '4 WEEKLY'    THEN 'FOUR_WEEKLY'
        WHEN 'QUARTERLY'   THEN 'QUARTERLY'
        WHEN 'Q'           THEN 'QUARTERLY'
        WHEN 'QTR'         THEN 'QUARTERLY'
        WHEN '13'          THEN 'QUARTERLY'
    END

FROM raw.claim c
----------------------------------------------------------------
-- TASK 2 - Claims for people who do not exist
--
-- LOOK FIRST:
--   SELECT count(*) FROM raw.claim c
--   WHERE NOT EXISTS (SELECT 1 FROM raw.claimant p
--                     WHERE upper(btrim(p.nino)) = upper(btrim(c.claimant_ref)));
--
-- Thirty claims point at a National Insurance number that is not in the
-- claimant table at all. They came from a system that was switched off
-- and nobody migrated the people. A claim with no claimant cannot be
-- paid, cannot be reported on, and must not be counted.
--
-- TODO: add a WHERE clause that keeps only claims whose claimant_ref
--       exists in clean.claimant. Hint:
--         WHERE EXISTS (SELECT 1 FROM clean.claimant cc
--                       WHERE cc.nino = upper(btrim(c.claimant_ref)))
----------------------------------------------------------------
WHERE EXISTS (SELECT 1 FROM clean.claimant cc
              WHERE cc.nino = upper(btrim(c.claimant_ref)))
;


INSERT INTO clean.payment (payment_id, claim_ref, payment_date, amount,
                           payment_method, payment_status)
SELECT
    p.payment_id,
    p.claim_ref,
    util.to_date(p.payment_date, 'YYYY-MM-DD'),
    util.to_number(p.amount),

    ----------------------------------------------------------------
    -- TASK 6 - Use the lookup table, and cope when it lets you down
    --
    -- LOOK FIRST - the mapping table:
    --   SELECT * FROM ref.code_mapping WHERE domain = 'payment_method';
    --
    -- LOOK FIRST - what is actually in the data:
    --   ./explore.sh values raw.payment payment_method
    --
    -- Compare the two lists. The mapping table is maintained by another
    -- team and they have not kept up: some spellings in the data are
    -- simply not in it.
    --
    -- The LEFT JOIN below already brings the mapping in. For the rows
    -- with no match, m.standard_value is NULL.
    --
    -- Do NOT drop those rows. A payment you cannot categorise is still a
    -- payment, and losing it would make the totals wrong. Mark it UNKNOWN
    -- so it stays visible and someone can fix the mapping later.
    --
    -- TODO: wrap the line below in  coalesce( ... , 'UNKNOWN')
    ----------------------------------------------------------------
    coalesce(m.standard_value, 'UNKNOWN'),

    CASE WHEN upper(btrim(p.payment_status)) IN ('SETTLED', 'S') THEN 'SETTLED'
         ELSE 'REVERSED' END
FROM raw.payment p
LEFT JOIN ref.code_mapping m
       ON m.domain = 'payment_method'
      AND m.raw_value = p.payment_method
----------------------------------------------------------------
-- TASK 7 - Payments for claims that do not exist
--
-- Same problem one level down: some payments quote a claim reference
-- that is not in clean.claim. Note this must be checked against YOUR
-- cleaned claims - a payment belonging to one of the orphan claims you
-- removed in Task 2 is now an orphan itself.
--
-- TODO: add   WHERE EXISTS (SELECT 1 FROM clean.claim c
--                           WHERE c.claim_ref = p.claim_ref)
----------------------------------------------------------------
WHERE EXISTS (SELECT 1 FROM clean.claim c WHERE c.claim_ref = p.claim_ref)
;


-- ===========================================================================
-- BONUS - only once every core test is green
-- ===========================================================================
--
-- BONUS A - How many claims are SUSPENDED? If your Task 1 mapping is
--   right this should already be correct - it is a free check that you
--   did not miss a spelling.
--
-- BONUS B - How many claims are paid four-weekly?
--
-- BONUS C - Make sure no payment_method came out NULL. "Not in the
--   mapping table" and "missing" are different things, and only one of
--   them is acceptable.
-- ===========================================================================
