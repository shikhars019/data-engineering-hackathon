-- ===========================================================================
-- CHALLENGE 1 - TEAM 2 - The Date Disaster
--
-- THIS IS YOUR FILE. Edit it, save it, then run:   ./check.sh 1
--
-- It already runs, and one test already passes. Your job is to turn the
-- rest green, one task at a time.
--
-- The big idea: three source systems write dates three different ways.
-- '06/05/1955' is the 6th of May to a British system and the 5th of June
-- to an American one. You cannot guess - you have to know which system
-- sent the row. That is what source_system is for.
-- ===========================================================================

TRUNCATE clean.claim;
TRUNCATE clean.claimant;


INSERT INTO clean.claimant (nino, title, first_name, last_name, date_of_birth,
                            sex, marital_status, date_of_death, email, phone)
WITH parsed AS (
    SELECT
        upper(btrim(nino))                                     AS nino,
        replace(initcap(btrim(title)), '.', '')                AS title,
        initcap(btrim(first_name))                             AS first_name,
        initcap(btrim(last_name))                              AS last_name,
        upper(btrim(sex))                                      AS sex,

        ----------------------------------------------------------------
        -- TASKS 1, 2 and 3 - Read each system's dates    <<< START HERE
        --
        -- LOOK FIRST:
        --   SELECT source_system, date_of_birth
        --   FROM raw.claimant
        --   ORDER BY source_system, random() LIMIT 30;
        --
        -- You should see three completely different styles:
        --   CIS         1955-08-31     year, month, day
        --   LEGACY_CSV  06/05/1955     day/month/year  (British order!)
        --   DIGITAL     12-Jul-1948    day-monthname-year
        --
        -- util.to_date(text, format) converts text into a real date.
        -- If the text does not match the format you give it, you get NULL
        -- rather than an error - so a wrong format shows up as a missing
        -- date, not a crash.
        --
        -- Format letters:  YYYY = 4-digit year    MM = month number
        --                  DD   = day             Mon = Jan, Feb, Mar ...
        --
        -- CIS is done for you, and its test already passes.
        -- TODO Task 2: fix the LEGACY_CSV format string
        -- TODO Task 3: fix the DIGITAL format string
        ----------------------------------------------------------------
        CASE source_system
            WHEN 'CIS'        THEN util.to_date(date_of_birth, 'YYYY-MM-DD')
            WHEN 'LEGACY_CSV' THEN util.to_date(date_of_birth, 'DD/MM/YYYY')
            WHEN 'DIGITAL'    THEN util.to_date(date_of_birth, 'DD-Mon-YYYY')
        END                                                    AS dob,

        ----------------------------------------------------------------
        -- TASK 5 - Dates of death are written the same three ways
        -- TODO: once Tasks 2 and 3 work, copy the same three formats here.
        ----------------------------------------------------------------
        CASE source_system
            WHEN 'CIS'        THEN util.to_date(date_of_death, 'YYYY-MM-DD')
            WHEN 'LEGACY_CSV' THEN util.to_date(date_of_death, 'DD/MM/YYYY')
            WHEN 'DIGITAL'    THEN util.to_date(date_of_death, 'DD-Mon-YYYY')
        END                                                    AS dod,

        CASE WHEN btrim(coalesce(marital_status, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
             THEN NULL ELSE initcap(btrim(marital_status)) END AS marital_status,
        CASE WHEN btrim(coalesce(email, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
             THEN NULL ELSE lower(btrim(email)) END            AS email,
        CASE WHEN btrim(coalesce(phone, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
             THEN NULL ELSE replace(btrim(phone), ' ', '') END AS phone
    FROM raw.claimant
)
SELECT
    nino, title, first_name, last_name, dob, sex, marital_status,

    ----------------------------------------------------------------
    -- TASK 6 - Impossible deaths
    --
    -- LOOK FIRST:
    --   SELECT nino, date_of_birth, date_of_death, source_system
    --   FROM raw.claimant
    --   WHERE date_of_death LIKE '%2029%';
    --
    -- Some records say the person died before they were born. Others say
    -- they died in 2029. Both are data entry errors, not deaths. A wrong
    -- date is worse than no date: leave them as NULL.
    --
    -- Today, for this exercise, is always DATE '2026-04-06'.
    --
    -- TODO: replace  dod  below with a CASE that returns NULL when
    --         - dod is on or before dob, or
    --         - dod is later than 2026-04-06
    --       and otherwise returns dod.
    ----------------------------------------------------------------
    CASE WHEN dod IS NULL             THEN NULL
         WHEN dod <= dob              THEN NULL
         WHEN dod > DATE '2026-04-06' THEN NULL
         ELSE dod
    END,

    email, phone
FROM parsed

----------------------------------------------------------------
-- TASK 4 - Leave out what cannot be rescued
--
-- LOOK FIRST - how many are unusable?
--   SELECT count(*) FROM raw.claimant
--   WHERE date_of_birth IN ('', 'N/A', 'UNKNOWN', 'NULL');
--
-- Some birth dates are placeholders the old systems used to mean
-- "we do not know": 1900-01-01 and 9999-12-31. Others are blank, or
-- are dated in the future. None of them can be repaired.
--
-- A State Pension claimant in 2026 was born between about 1930 and 1961.
-- Anything outside that is wrong.
--
-- TODO: add a WHERE clause keeping only rows where dob
--         - is not NULL, and
--         - is on or after 1930-01-01, and
--         - is on or before 2026-04-06
--       Example:  WHERE dob IS NOT NULL AND dob >= DATE '1930-01-01'
----------------------------------------------------------------
WHERE dob IS NOT NULL
  AND dob >= DATE '1930-01-01'
  AND dob <= DATE '2026-04-06'
;


-- ===========================================================================
-- BONUS - only once every core test is green
-- ===========================================================================
--
-- BONUS A - clean.claim has the same problem. Claim start dates are written
--   in the same three styles, and raw.claim does not have a source_system
--   column - so you will need to join back to raw.claimant to find out
--   which system the person came from.
--
--   Uncomment and finish this:
--
-- INSERT INTO clean.claim (claim_ref, nino, claim_status, pension_type,
--                          claim_start_date, qualifying_years, weekly_amount,
--                          deferral_indicator, payment_frequency)
-- SELECT c.claim_ref,
--        c.claimant_ref,
--        c.claim_status,
--        c.pension_type,
--        CASE r.source_system
--            WHEN 'CIS' THEN util.to_date(c.claim_start_date, 'YYYY-MM-DD')
--            -- TODO the other two
--        END,
--        util.to_number(c.qualifying_years)::int,
--        util.to_number(c.weekly_amount),
--        upper(btrim(c.deferral_indicator)) IN ('Y','YES','TRUE','T','1'),
--        c.payment_frequency
-- FROM raw.claim c
-- JOIN raw.claimant   r  ON upper(btrim(r.nino)) = upper(btrim(c.claimant_ref))
-- JOIN clean.claimant cc ON cc.nino              = upper(btrim(c.claimant_ref));
--
-- BONUS B - Nobody can claim a State Pension before they turn 66. Once
--   Bonus A works, the last test checks that no claim starts too early.
-- ===========================================================================

INSERT INTO clean.claim (claim_ref, nino, claim_status, pension_type,
                         claim_start_date, qualifying_years, weekly_amount,
                         deferral_indicator, payment_frequency)
SELECT c.claim_ref,
       c.claimant_ref,
       c.claim_status,
       c.pension_type,
       CASE r.source_system
           WHEN 'CIS'        THEN util.to_date(c.claim_start_date, 'YYYY-MM-DD')
           WHEN 'LEGACY_CSV' THEN util.to_date(c.claim_start_date, 'DD/MM/YYYY')
           WHEN 'DIGITAL'    THEN util.to_date(c.claim_start_date, 'DD-Mon-YYYY')
       END,
       util.to_number(c.qualifying_years)::int,
       util.to_number(c.weekly_amount),
       upper(btrim(c.deferral_indicator)) IN ('Y','YES','TRUE','T','1'),
       c.payment_frequency
FROM raw.claim c
JOIN raw.claimant   r  ON upper(btrim(r.nino)) = upper(btrim(c.claimant_ref))
JOIN clean.claimant cc ON cc.nino              = upper(btrim(c.claimant_ref));
