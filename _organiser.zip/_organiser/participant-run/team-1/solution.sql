-- ===========================================================================
-- CHALLENGE 1 - TEAM 1 - The Duplicate Claimants
--
-- THIS IS YOUR FILE. Edit it, save it, then run:   ./check.sh 1
--
-- It already runs. Try it now, before you change anything - you should get
-- some tests passing and some failing. Your job is to turn the FAILs green,
-- one task at a time.
--
-- Every task has a LOOK FIRST query. Run that in TablePlus (or with
-- ./explore.sh) before you write anything. You cannot clean data you have
-- not looked at.
-- ===========================================================================

-- Start from empty every time, so you can run this file as often as you like.
TRUNCATE clean.claimant;


INSERT INTO clean.claimant (nino, title, first_name, last_name, date_of_birth,
                            sex, marital_status, date_of_death, email, phone)
WITH tidied AS (
    SELECT
        record_id,
        ingested_at,

        ----------------------------------------------------------------
        -- TASK 3 - One spelling for each National Insurance number
        --
        -- LOOK FIRST:
        --   SELECT nino FROM raw.claimant ORDER BY random() LIMIT 20;
        --
        -- You will see the same format written five different ways:
        --   'QQ123456C'   'qq123456c'   'QQ 12 34 56 C'
        --   'QQ-12-34-56-C'   '  QQ123456C  '
        -- These are all the SAME person.
        --
        -- Below handles the capitals and the outside spaces. It does not
        -- yet handle the spaces in the middle, or the dashes.
        --
        -- TODO: wrap this in replace(...) twice more - once to remove ' '
        --       and once to remove '-'.
        --       replace(text, ' ', '') removes every space.
        ----------------------------------------------------------------
        upper(replace(replace(btrim(nino), ' ', ''), '-', '')) AS nino,

        replace(initcap(btrim(title)), '.', '')                AS title,

        ----------------------------------------------------------------
        -- TASK 1 - Tidy the names            <<< START HERE
        --
        -- LOOK FIRST:
        --   ./explore.sh values raw.claimant first_name
        --   (the square brackets in the output show you the stray spaces)
        --
        -- You will see '  John', 'JOHN  ', 'john'. All the same name.
        --
        -- TODO: replace  first_name  with  initcap(btrim(first_name))
        --       and do the same for last_name.
        --         btrim(x)   removes spaces from both ends
        --         initcap(x) makes it Look Like This
        ----------------------------------------------------------------
        initcap(btrim(first_name))                             AS first_name,
        initcap(btrim(last_name))                              AS last_name,

        util.to_date(date_of_birth, 'YYYY-MM-DD')              AS date_of_birth,
        upper(btrim(sex))                                      AS sex,

        ----------------------------------------------------------------
        -- TASK 2 - 'N/A' is not a value
        --
        -- LOOK FIRST:
        --   ./explore.sh values raw.claimant marital_status
        --
        -- Source systems fill empty fields with all sorts of rubbish:
        --   ''   'N/A'   'UNKNOWN'   'NULL'   'n/a'   '-'
        -- None of those are marital statuses. They all mean "we do not know",
        -- and in a database that is spelled NULL.
        --
        -- marital_status is done for you. Copy the same CASE for email
        -- and phone.
        ----------------------------------------------------------------
        CASE WHEN btrim(coalesce(marital_status, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
             THEN NULL
             ELSE initcap(btrim(marital_status))
        END                                                    AS marital_status,

        util.to_date(date_of_death, 'YYYY-MM-DD')              AS date_of_death,

        CASE WHEN btrim(coalesce(email, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
             THEN NULL
             ELSE lower(btrim(email))
        END                                                    AS email,
        CASE WHEN btrim(coalesce(phone, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
             THEN NULL
             ELSE replace(btrim(phone), ' ', '')
        END                                                    AS phone

    FROM raw.claimant
),
ranked AS (
    SELECT
        t.*,
        ----------------------------------------------------------------
        -- TASK 4 - Look at the duplicates before you delete anything
        --
        -- LOOK FIRST - how bad is it?
        --   SELECT count(*) AS records,
        --          count(DISTINCT upper(replace(replace(btrim(nino),' ',''),'-',''))) AS people
        --   FROM raw.claimant;
        --
        -- LOOK FIRST - pick one person and study them:
        --   SELECT record_id, nino, first_name, email, source_system, ingested_at
        --   FROM raw.claimant
        --   WHERE upper(replace(replace(btrim(nino),' ',''),'-','')) = 'QQ209469B'
        --   ORDER BY ingested_at;
        --
        -- Three records, one person, three different email addresses.
        -- Which one is right?
        --
        ----------------------------------------------------------------
        -- TASK 5 - Decide which record wins
        --
        -- ROW_NUMBER() numbers the rows within each group. Here the group
        -- is one person (PARTITION BY nino), and the numbering follows
        -- whatever you put in ORDER BY. Keeping rn = 1 keeps one record
        -- per person - so ORDER BY decides who survives.
        --
        -- Right now it orders by record_id, which is meaningless: it keeps
        -- whichever record happens to have been written first.
        --
        -- The rule the agency uses is: THE MOST RECENTLY INGESTED RECORD WINS.
        --
        -- TODO: change the ORDER BY so the newest ingested_at comes first.
        --       Hint: ORDER BY ingested_at DESC, record_id DESC
        --       (the second part only breaks ties, so the answer is stable)
        ----------------------------------------------------------------
        ROW_NUMBER() OVER (PARTITION BY nino
                           ORDER BY ingested_at DESC, record_id DESC) AS rn,
        max(email) OVER (PARTITION BY nino)                    AS fallback_email

    FROM tidied t
)
SELECT nino, title, first_name, last_name, date_of_birth, sex, marital_status,
       date_of_death, coalesce(email, fallback_email), phone
FROM ranked
WHERE rn = 1;


-- ===========================================================================
-- BONUS - only once every core test is green
-- ===========================================================================
--
-- BONUS A - Tidy the titles to exactly Mr, Mrs, Ms or Miss.
--   LOOK FIRST:  ./explore.sh values raw.claimant title
--   You will find 'MR.', 'mr', 'Mr.' and more. Two functions will do it:
--   one to fix the capitals, one to get rid of the full stop.
--
-- BONUS B - Recover the best available email.
--   Some people lose their email in Task 5, because the newest record
--   happens to have 'N/A' in it - even though an older record had a real
--   address. Keeping the newest record should not mean throwing away
--   information you already had.
--   Hint: max(email) OVER (PARTITION BY nino) gives you an email from ANY
--   of that person's records. coalesce() picks the first non-NULL value.
--
-- BONUS C - Store phone numbers as 11 digits with no spaces.
--   '07700 900123' should become '07700900123'.
-- ===========================================================================
