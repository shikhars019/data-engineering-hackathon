-- ===========================================================================
-- CHALLENGE 1 - TEAM 3 - The Address Mess
--
-- THIS IS YOUR FILE. Edit it, save it, then run:   ./check.sh 1
--
-- It already runs, and one test already passes. Your job is to turn the
-- rest green, one task at a time.
--
-- The big idea: a postcode is how the agency works out which region a pensioner
-- lives in, and which office looks after them. 'sw1a1aa', 'SW1A  1AA' and
-- 'SW1A 1AA' are the same place, but only the last one will join to
-- anything. Getting the format right is what makes the data usable.
-- ===========================================================================

TRUNCATE clean.address;
TRUNCATE clean.claimant;


-- ---------------------------------------------------------------------------
-- TASK 1 - Load the people. Written for you: just leave it alone.
-- Your work is the addresses, below.
-- ---------------------------------------------------------------------------
INSERT INTO clean.claimant (nino, title, first_name, last_name, date_of_birth,
                            sex, marital_status, date_of_death, email, phone)
SELECT
    upper(btrim(nino)),
    replace(initcap(btrim(title)), '.', ''),
    initcap(btrim(first_name)),
    initcap(btrim(last_name)),
    util.to_date(date_of_birth, 'YYYY-MM-DD'),
    upper(btrim(sex)),
    CASE WHEN btrim(coalesce(marital_status, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE initcap(btrim(marital_status)) END,
    util.to_date(date_of_death, 'YYYY-MM-DD'),
    CASE WHEN btrim(coalesce(email, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE lower(btrim(email)) END,
    CASE WHEN btrim(coalesce(phone, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE replace(btrim(phone), ' ', '') END
FROM raw.claimant;


INSERT INTO clean.address (address_id, nino, line_1, line_2, town, county,
                           postcode, valid_from, valid_to, is_current)
WITH squashed AS (
    ----------------------------------------------------------------
    -- TASK 2 - Squash every postcode into one shape   <<< START HERE
    --
    -- LOOK FIRST:
    --   ./explore.sh values raw.address postcode
    --   (brackets in the output show you the stray spaces)
    --
    -- You will see 'SW1A 1AA', 'sw1a1aa', 'SW1A  1AA', '  sw1a 1aa '.
    -- The trick is to throw away ALL the spaces first, and put one back
    -- in the right place afterwards. That way you do not have to care
    -- how many spaces there were to begin with.
    --
    -- This line is done for you. Read it and make sure you follow it.
    ----------------------------------------------------------------
    SELECT a.*,
           replace(upper(btrim(a.postcode)), ' ', '') AS pc_squashed
    FROM raw.address a
),
tidied AS (
    SELECT
        address_id,
        upper(btrim(claimant_ref))                  AS nino,

        -- TODO Task 3: tidy these two the same way you would a name,
        --              with initcap(btrim( ... ))
        initcap(btrim(address_line_1))              AS line_1,
        address_line_2                              AS line_2,
        initcap(btrim(town))                        AS town,

        county                                      AS county,

        ----------------------------------------------------------------
        -- TASK 2 continued - Put ONE space back
        --
        -- A UK postcode is always "some characters, a space, then exactly
        -- three characters":   SW1A 1AA     M14 5TG     B1 1AA
        --
        -- So the space always goes three from the end.
        --   left(text, n)   gives the first n characters
        --   right(text, n)  gives the last n characters
        --   length(text)    gives how long it is
        --   a || b          glues two pieces of text together
        --
        -- TODO: replace  pc_squashed  below with
        --         left(pc_squashed, length(pc_squashed) - 3)
        --         || ' ' ||
        --         right(pc_squashed, 3)
        --
        --       Keep the CASE around it. Some postcodes are rubbish like
        --       'N/A' or '12345', and taking 3 characters off something
        --       2 characters long makes no sense - the CASE keeps those
        --       out of the way for now.
        ----------------------------------------------------------------
        CASE WHEN length(pc_squashed) BETWEEN 5 AND 7
             THEN left(pc_squashed, length(pc_squashed) - 3)
                  || ' ' || right(pc_squashed, 3)
        END                                         AS postcode,

        util.to_date(valid_from, 'YYYY-MM-DD')      AS valid_from,
        util.to_date(valid_to,   'YYYY-MM-DD')      AS valid_to
    FROM squashed
),
usable AS (
    ----------------------------------------------------------------
    -- TASK 4 - Throw out the postcodes that are not postcodes
    --
    -- LOOK FIRST:
    --   SELECT postcode, count(*) FROM raw.address
    --   WHERE length(replace(upper(btrim(postcode)),' ','')) NOT BETWEEN 5 AND 7
    --   GROUP BY 1 ORDER BY 2 DESC;
    --
    -- 'N/A', 'TBC', 'NOT KNOWN', '12345'. None of these are addresses.
    --
    -- Here is a pattern that matches a real UK postcode. You do not have
    -- to understand it, just use it:
    --
    --     postcode ~ '^[A-Z]{1,2}[0-9][A-Z0-9]? [0-9][A-Z]{2}$'
    --
    -- The ~ means "matches this pattern".
    --
    -- TASK 5 - Throw out addresses for people who do not exist
    --
    -- LOOK FIRST:
    --   SELECT count(*) FROM raw.address a
    --   WHERE NOT EXISTS (SELECT 1 FROM raw.claimant c
    --                     WHERE upper(btrim(c.nino)) = upper(btrim(a.claimant_ref)));
    --
    -- Joining to clean.claimant quietly drops any address whose person is
    -- not there - an inner join only keeps rows that match on both sides.
    --
    -- TODO Task 5: add    JOIN clean.claimant c ON c.nino = t.nino
    -- TODO Task 4: add    WHERE t.postcode ~ '^[A-Z]{1,2}[0-9][A-Z0-9]? [0-9][A-Z]{2}$'
    ----------------------------------------------------------------
    SELECT t.*
    FROM tidied t
    JOIN clean.claimant c ON c.nino = t.nino
    WHERE t.postcode ~ '^[A-Z]{1,2}[0-9][A-Z0-9]? [0-9][A-Z]{2}$'
),
ranked AS (
    ----------------------------------------------------------------
    -- TASK 6 - Which address is the person at NOW?
    --
    -- LOOK FIRST - the flag cannot be trusted:
    --   SELECT claimant_ref, address_id, valid_from, valid_to, is_current
    --   FROM raw.address
    --   WHERE claimant_ref IN (
    --       SELECT claimant_ref FROM raw.address GROUP BY 1 HAVING count(*) > 1)
    --   ORDER BY claimant_ref, valid_from
    --   LIMIT 20;
    --
    -- You will find people with TWO addresses both flagged 'Y', and people
    -- with none flagged at all. The flag was filled in by hand and nobody
    -- maintained it.
    --
    -- What you CAN trust is valid_from: the address someone moved to most
    -- recently is the one they live at now.
    --
    -- ROW_NUMBER() numbers rows within each person. Number 1 is the
    -- current address - so the ORDER BY decides which one that is.
    --
    -- TODO: change the ORDER BY so the most recent valid_from comes first.
    --       Hint: ORDER BY valid_from DESC, address_id DESC
    ----------------------------------------------------------------
    SELECT u.*,
           ROW_NUMBER() OVER (PARTITION BY nino
                              ORDER BY valid_from DESC, address_id DESC) AS rn
    FROM usable u
)
SELECT address_id, nino, line_1, line_2, town, county, postcode,
       valid_from, valid_to, (rn = 1) AS is_current
FROM ranked;


-- ===========================================================================
-- BONUS - only once every core test is green
-- ===========================================================================
--
-- BONUS A - Every postcode starts with one or two letters that say which
--   part of the country it is in: SW is London, M is Manchester. That is
--   what ref.postcode_area is for.
--
--   This expression pulls the letters off the front of a postcode:
--       substring(postcode from '^[A-Z]{1,2}')
--
--   Check every one of your postcodes matches something in ref.postcode_area.
--
-- BONUS B - valid_to should be filled in for an address someone has moved
--   out of, and empty for the one they are at now.
--
-- BONUS C - How many of your claimants currently live in London? Join
--   clean.address to ref.postcode_area using the expression from Bonus A.
-- ===========================================================================
