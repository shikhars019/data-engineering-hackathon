-- ===========================================================================
-- CHALLENGE 1 - TEAM 4 - The Money Problem
--
-- THIS IS YOUR FILE. Edit it, save it, then run:   ./check.sh 1
--
-- It already runs, and one test already passes. Your job is to turn the
-- rest green, one task at a time.
--
-- The big idea: this data decides what lands in a pensioner's bank account.
-- Pay someone twice and the money is gone. Miss a payment and someone does
-- not eat. Every number here has to be exactly right, and you have to be
-- able to prove it - which is why so many of your tests are totals.
-- ===========================================================================

TRUNCATE clean.payment;
TRUNCATE clean.claim;
TRUNCATE clean.claimant;


-- ---------------------------------------------------------------------------
-- Load the people. Written for you: leave it alone.
-- ---------------------------------------------------------------------------
INSERT INTO clean.claimant (nino, title, first_name, last_name, date_of_birth,
                            sex, marital_status, date_of_death, email, phone)
SELECT
    upper(btrim(nino)),
    replace(initcap(btrim(title)), '.', ''),
    initcap(btrim(first_name)),
    initcap(btrim(last_name)),
    util.to_date(date_of_birth, 'YYYY-MM-DD'),
    upper(btrim(sex)),
    CASE WHEN btrim(coalesce(marital_status, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE initcap(btrim(marital_status)) END,
    util.to_date(date_of_death, 'YYYY-MM-DD'),
    CASE WHEN btrim(coalesce(email, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE lower(btrim(email)) END,
    CASE WHEN btrim(coalesce(phone, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE replace(btrim(phone), ' ', '') END
FROM raw.claimant;


-- ---------------------------------------------------------------------------
-- TASKS 1 and 2 - Turn the weekly amount into a number   <<< START HERE
--
-- LOOK FIRST:
--   ./explore.sh values raw.claim weekly_amount
--
-- Every system writes money differently:
--   '185.15'      fine
--   '£185.15'     has a currency symbol
--   '  185.15 '   has spaces round it
--   '185.15 GBP'  has the currency spelled out
--
-- A NUMERIC column will not accept any of those except the first, so you
-- have to strip the decoration off before converting.
--
--   replace(text, 'x', '')  removes every 'x'
--   util.to_number(text)    turns text into a number, or NULL if it can't
--
-- replace() calls nest, innermost first:
--   replace(replace(btrim(x), '£', ''), 'GBP', '')
--
-- TODO Task 1: strip the '£'
-- TODO Task 2: strip 'GBP', and then any leftover spaces with
--              replace(..., ' ', '')
-- ---------------------------------------------------------------------------
INSERT INTO clean.claim (claim_ref, nino, claim_status, pension_type,
                         claim_start_date, qualifying_years, weekly_amount,
                         deferral_indicator, payment_frequency)
SELECT
    claim_ref,
    upper(btrim(claimant_ref)),
    claim_status,
    pension_type,
    util.to_date(claim_start_date, 'YYYY-MM-DD'),
    util.to_number(qualifying_years)::int,

    util.to_number(
        replace(replace(replace(replace(btrim(weekly_amount),
            '£', ''), ',', ''), 'GBP', ''), ' ', '')
    ),

    upper(btrim(deferral_indicator)) IN ('Y', 'YES', 'TRUE', 'T', '1'),
    payment_frequency
FROM raw.claim;


INSERT INTO clean.payment (payment_id, claim_ref, payment_date, amount,
                           payment_method, payment_status)
WITH stripped AS (
    SELECT
        payment_id,
        claim_ref,
        util.to_date(payment_date, 'YYYY-MM-DD') AS payment_date,
        payment_method,
        upper(btrim(payment_status))             AS payment_status,

        ----------------------------------------------------------------
        -- TASK 3 - Payments have commas and brackets too
        --
        -- LOOK FIRST:
        --   SELECT amount FROM raw.payment ORDER BY random() LIMIT 25;
        --
        -- Four-weekly payments run into four figures, so you also get
        -- thousands separators: '1,234.56' and '£1,234.56'.
        --
        -- And you will see amounts in brackets: '(185.15)'. In accounting,
        -- brackets mean a NEGATIVE number. That is money going back the
        -- other way - which matters enormously in Task 6.
        --
        -- TODO: add replace() calls for  ','  '('  ')'  and 'GBP'
        --       so that every amount ends up as bare digits and a dot.
        ----------------------------------------------------------------
        btrim(amount) LIKE '(%'                  AS is_bracketed,
        replace(replace(replace(replace(replace(replace(btrim(amount),
            '(', ''), ')', ''), '£', ''), ',', ''), 'GBP', ''), ' ', '') AS digits
    FROM raw.payment
),
parsed AS (
    ----------------------------------------------------------------
    -- TASK 4 - Make bracketed amounts negative
    -- TODO: if is_bracketed, the amount should be negative.
    --       Hint:  CASE WHEN is_bracketed THEN -util.to_number(digits)
    --                   ELSE util.to_number(digits) END
    ----------------------------------------------------------------
    SELECT
        payment_id, claim_ref, payment_date, payment_method, payment_status,
        CASE WHEN is_bracketed THEN -util.to_number(digits)
             ELSE util.to_number(digits) END AS amount
    FROM stripped
),
kept AS (
    ----------------------------------------------------------------
    -- TASK 5 - Only money that actually moved
    --
    -- LOOK FIRST:
    --   ./explore.sh values raw.payment payment_status
    --
    -- SETTLED   the money arrived
    -- REVERSED  the money arrived and was then taken back - still real
    -- FAILED    the bank rejected it. No money moved.
    -- PENDING   has not happened yet.
    --
    -- Counting FAILED payments as real would overstate what the agency has paid
    -- out by hundreds of thousands of pounds.
    --
    -- TODO: keep only SETTLED and REVERSED.
    --       Hint: WHERE payment_status IN ('SETTLED', 'REVERSED')
    ----------------------------------------------------------------
    SELECT * FROM parsed
    WHERE payment_status IN ('SETTLED', 'REVERSED')
),
deduped AS (
    ----------------------------------------------------------------
    -- TASK 6 - The same payment entered twice
    --
    -- LOOK FIRST:
    --   SELECT claim_ref, payment_date, amount, count(*)
    --   FROM raw.payment
    --   GROUP BY 1,2,3 HAVING count(*) > 1
    --   ORDER BY 4 DESC LIMIT 10;
    --
    -- Some payments were keyed in twice by two different offices. Same
    -- claim, same day, same amount - one real payment.
    --
    -- *** BE CAREFUL HERE ***
    -- A REVERSAL also has the same claim and the same day and the same
    -- value as the payment it cancels - but the opposite sign. It is a
    -- real, separate transaction and it must survive. If you decide two
    -- payments are the same by ignoring the sign, you will delete 120
    -- genuine reversals and your totals will be wrong.
    --
    -- Grouping by amount (not by its size) keeps +185.15 and -185.15 in
    -- different groups, which is exactly what you want.
    --
    -- TODO: keep only the first row in each group - add  WHERE rn = 1
    --       to the final SELECT below.
    ----------------------------------------------------------------
    SELECT k.*,
           ROW_NUMBER() OVER (PARTITION BY claim_ref, payment_date, amount
                              ORDER BY payment_id) AS rn
    FROM kept k
)
SELECT payment_id, claim_ref, payment_date, amount, payment_method, payment_status
FROM deduped
WHERE rn = 1;


-- ===========================================================================
-- BONUS - only once every core test is green
-- ===========================================================================
--
-- BONUS A - What is the total value of the reversals? (It should be a
--   negative number.)
--
-- BONUS B - Is there any claim with no payments at all? A LEFT JOIN from
--   clean.claim to clean.payment, keeping rows where the payment side is
--   NULL, will tell you.
--
-- BONUS C - Is anything dated after 2026-04-06? Payments cannot be in the
--   future, and if one is, somebody has mis-keyed a year.
-- ===========================================================================
