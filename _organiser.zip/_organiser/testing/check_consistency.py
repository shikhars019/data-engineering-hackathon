#!/usr/bin/env python3
"""
ORGANISER ONLY - does the whole pack tell the same story?

The same fact (a task number, a test count, a line number, a command name)
is written down in up to five places: the starter, the brief, the printed
handout, the test file and the runbook. Nothing stops them drifting apart,
and they have drifted three times already.

This checks all of it. Run it after ANY change to the pack:

    python _organiser/testing/check_consistency.py
"""
import io
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
HANDOUT = os.path.join(ROOT, "_organiser", "handouts", "hackathon-handouts.html")
RUNBOOK = os.path.join(ROOT, "_organiser", "ORGANISER-RUNBOOK.md")

WORDS = {"THREE": 3, "FOUR": 4, "FIVE": 5, "SIX": 6, "SEVEN": 7, "EIGHT": 8}

problems = []
checks = 0


def read(p):
    return io.open(p, encoding="utf-8").read()


def ok(msg):
    global checks
    checks += 1
    print("  ok    %s" % msg)


def bad(msg):
    global checks
    checks += 1
    problems.append(msg)
    print("  FAIL  %s" % msg)


def starter_path(team):
    if team == "c2":
        return os.path.join(ROOT, "challenges", "challenge-2", "solution.sql")
    return os.path.join(ROOT, "challenges", "challenge-1", "team-%s" % team, "solution.sql")


def brief_path(team):
    if team == "c2":
        return os.path.join(ROOT, "challenges", "challenge-2", "BRIEF.md")
    return os.path.join(ROOT, "challenges", "challenge-1", "team-%s" % team, "BRIEF.md")


def test_path(team):
    if team == "c2":
        return os.path.join(ROOT, "tests", "challenge2_tests.sql")
    return os.path.join(ROOT, "tests", "challenge1_team%s_tests.sql" % team)


def checklist_rows(text):
    """The 'Task N  title  line X' rows from a starter's job checklist."""
    return re.findall(r"^--   Tasks? ?([0-9+]+)\s+(.*)$", text, re.M)


def marker_lines(text):
    return [i + 1 for i, l in enumerate(text.split("\n"))
            if "<<<<<< EDIT THIS LINE" in l and not l.lstrip().startswith("--")]


TEAMS = ["1", "2", "3", "4", "5", "c2"]
LABEL = {"1": "team 1", "2": "team 2", "3": "team 3", "4": "team 4",
         "5": "team 5", "c2": "challenge 2"}

print("Checking the pack tells one consistent story")
print("=" * 70)

for t in TEAMS:
    name = LABEL[t]
    print("\n%s" % name.upper())
    st = read(starter_path(t))
    br = read(brief_path(t))
    te = read(test_path(t))

    # ---- 1. the job checklist ------------------------------------------
    rows = checklist_rows(st)
    marks = marker_lines(st)

    m = re.search(r"YOUR JOB: ([A-Z]+) LINES", st)
    if not m:
        bad("%s: starter has no 'YOUR JOB: N LINES' header" % name)
    elif WORDS.get(m.group(1)) != len(marks):
        bad("%s: header says %s LINES but there are %d edit markers"
            % (name, m.group(1), len(marks)))
    else:
        ok("%s: header says %s lines, and there are %d markers"
           % (name, m.group(1), len(marks)))

    # every line number quoted in the checklist must really hold a marker
    quoted = [int(n) for _, rest in rows for n in re.findall(r"\b(\d{2,4})\b", rest)]
    wrong = [n for n in quoted if n not in marks]
    if wrong:
        bad("%s: checklist points at line(s) %s, which hold no edit marker"
            % (name, wrong))
    elif quoted:
        ok("%s: all %d line numbers in the checklist land on a marker"
           % (name, len(quoted)))
    if quoted and sorted(quoted) != sorted(marks):
        missing = [n for n in marks if n not in quoted]
        bad("%s: markers on line(s) %s are not listed in the checklist"
            % (name, missing))

    # ---- 2. task numbers sequential, and the same everywhere -----------
    task_nums = sorted({int(n) for num, _ in rows for n in re.findall(r"\d+", num)})
    if task_nums != list(range(1, len(task_nums) + 1)):
        bad("%s: starter task numbers are %s, not 1..N" % (name, task_nums))
    else:
        ok("%s: starter tasks run 1..%d" % (name, len(task_nums)))

    brief_nums = [int(x) for x in re.findall(r"^\| (\d) \|", br, re.M)]
    if not brief_nums:
        bad("%s: brief has no task table" % name)
    elif brief_nums != list(range(1, len(brief_nums) + 1)):
        bad("%s: brief task table is %s, not 1..N" % (name, brief_nums))
    elif brief_nums != task_nums:
        bad("%s: brief lists tasks %s but the starter has %s"
            % (name, brief_nums, task_nums))
    else:
        ok("%s: brief task table matches the starter" % name)

    # ---- 3. test counts quoted in the brief ----------------------------
    core = len(re.findall(r"'core'", te))
    bonus = len(re.findall(r"'bonus'", te))
    bm = re.search(r"(\d+) core tests? \+ (\d+) bonus", br)
    if not bm:
        bad("%s: brief does not state its test counts" % name)
    elif (int(bm.group(1)), int(bm.group(2))) != (core, bonus):
        bad("%s: brief says %s core + %s bonus, tests have %d + %d"
            % (name, bm.group(1), bm.group(2), core, bonus))
    else:
        ok("%s: brief's %d core + %d bonus matches the test file" % (name, core, bonus))

    # ---- 4. every task a test points at must exist ---------------------
    referenced = set()
    for tk in re.findall(r"test\.check\('[^']+', '\w+', '([0-9 and]+)'", te):
        referenced.update(int(n) for n in re.findall(r"\d+", tk))
    unknown = sorted(referenced - set(task_nums))
    if unknown:
        bad("%s: tests point at task(s) %s which the starter does not have"
            % (name, unknown))
    else:
        ok("%s: every task a test points at exists" % name)

print("\nHANDOUT")
ho = read(HANDOUT)
# team cards: each <tr><td>N</td> block must run 1..N and match the starter
for t in ["1", "2", "3", "4", "5"]:
    st_rows = checklist_rows(read(starter_path(t)))
    st_count = len({n for num, _ in st_rows for n in re.findall(r"\d+", num)})
    # Some cards carry another table before the task list, so anchor on the
    # "Your tasks" heading rather than the first <table> after the title.
    card = re.search(r"TEAM %s</div>.*?Your tasks</h2>\s*<table>(.*?)</table>" % t,
                     ho, re.S)
    if not card:
        bad("handout: no 'Your tasks' table found for team %s" % t)
        continue
    nums = [int(n) for n in re.findall(r"<tr><td>(\d)</td>", card.group(0))]
    if nums != list(range(1, len(nums) + 1)):
        bad("handout team %s: task rows are %s, not 1..N" % (t, nums))
    elif len(nums) != st_count:
        bad("handout team %s: %d task rows but the starter has %d tasks"
            % (t, len(nums), st_count))
    else:
        ok("handout team %s: %d task rows, matching the starter" % (t, len(nums)))

print("\nSCORECARD EXAMPLES")
# Every place that shows a mock scorecard must show the task column, or
# students will be looking for something the tool no longer prints.
for f in [os.path.join(ROOT, "README.md"),
          os.path.join(ROOT, "docs", "04-running-tests.md"),
          HANDOUT]:
    txt = read(f)
    if "CORE" not in txt or "|" not in txt:
        continue
    shows_board = re.search(r"\n[^\n]*\|[^\n]*expected[^\n]*\|[^\n]*you got", txt)
    if not shows_board:
        continue
    if re.search(r"task\s*\|", shows_board.group(0)):
        ok("%s: scorecard example shows the task column" % os.path.basename(f))
    else:
        bad("%s: scorecard example is missing the task column" % os.path.basename(f))

print("\nCOMMANDS AND PATHS")
# every ./script.sh mentioned in student-facing docs must exist
student_docs = [os.path.join(ROOT, "README.md")] + \
    [os.path.join(ROOT, "docs", f) for f in sorted(os.listdir(os.path.join(ROOT, "docs")))]
mentioned = set()
for f in student_docs:
    mentioned.update(re.findall(r"\./([a-z0-9_\-]+\.sh)", read(f)))
    mentioned.update(re.findall(r"\./(scripts/[a-z0-9_\-]+\.sh)", read(f)))
missing = [c for c in sorted(mentioned) if not os.path.exists(os.path.join(ROOT, c))]
if missing:
    bad("docs mention scripts that do not exist: %s" % missing)
else:
    ok("all %d scripts mentioned in student docs exist" % len(mentioned))

# every markdown link target in the README must exist
for link in re.findall(r"\]\(([^)]+\.md)\)", read(os.path.join(ROOT, "README.md"))):
    if not os.path.exists(os.path.join(ROOT, link)):
        bad("README links to %s, which does not exist" % link)
ok("README's internal links all resolve")

# the port must be the same story everywhere
compose = read(os.path.join(ROOT, "docker-compose.yml"))
if "127.0.0.1:55432:5432" not in compose:
    bad("docker-compose does not bind the port to 127.0.0.1")
else:
    ok("database port bound to 127.0.0.1 only")
for f in student_docs + [HANDOUT]:
    txt = read(f)
    if "5432" in txt and "55432" not in txt:
        bad("%s mentions 5432 but never 55432" % os.path.basename(f))
ok("every doc that mentions the port says 55432")

print("\n" + "=" * 70)
if problems:
    print("%d PROBLEM(S) out of %d checks\n" % (len(problems), checks))
    for p in problems:
        print("  - " + p)
    sys.exit(1)
print("All %d checks passed - the pack tells one story." % checks)
