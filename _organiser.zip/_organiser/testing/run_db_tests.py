#!/usr/bin/env python3
"""
ORGANISER ONLY - validation harness.

Rebuilds the whole hackathon database against a real PostgreSQL server and
runs the tests, exactly as the students' container would:

    initdb/*.sql  ->  data/teamN.sql  ->  solution  ->  tests

Students never use this. They use ./start.sh and ./check.sh with Docker.

Usage (connection string comes from PGURL, or scratchpad/pgurl.txt):
    python _organiser/testing/run_db_tests.py --team 1
    python _organiser/testing/run_db_tests.py --team 1 --no-solution
    python _organiser/testing/run_db_tests.py --challenge2
    python _organiser/testing/run_db_tests.py --all
"""
import argparse
import glob
import io
import os
import re
import sys
import time

import psycopg2

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SCHEMAS = ["raw", "ref", "clean", "curated", "analytics", "meta", "test", "util"]

COPY_RE = re.compile(r"^COPY\s+([\w.]+)\s*\(([^)]*)\)\s+FROM\s+stdin;\s*$", re.I)


def conn_string():
    url = os.environ.get("PGURL")
    if url:
        return url
    for p in (os.path.join(os.path.dirname(__file__), "pgurl.txt"),
              os.path.join(ROOT, "_organiser", "testing", "pgurl.txt")):
        if os.path.exists(p):
            return io.open(p, encoding="utf-8").read().strip()
    sys.exit("No connection string. Set PGURL or create _organiser/testing/pgurl.txt")


def split_sql(text):
    """Split a file into ('sql', body) and ('copy', stmt, data) segments."""
    segments = []
    buf = []
    lines = text.split("\n")
    i = 0
    while i < len(lines):
        m = COPY_RE.match(lines[i].strip())
        if m:
            if buf:
                segments.append(("sql", "\n".join(buf)))
                buf = []
            stmt = lines[i].strip().rstrip(";")
            i += 1
            data = []
            while i < len(lines) and lines[i] != "\\.":
                data.append(lines[i])
                i += 1
            segments.append(("copy", stmt, "\n".join(data) + "\n"))
        else:
            buf.append(lines[i])
        i += 1
    if buf:
        segments.append(("sql", "\n".join(buf)))
    return segments


def run_file(cur, path, label=None):
    text = io.open(path, encoding="utf-8").read()
    for seg in split_sql(text):
        if seg[0] == "sql":
            body = seg[1].strip()
            if body and not all(l.strip().startswith("--") or not l.strip()
                                for l in body.split("\n")):
                cur.execute(body)
        else:
            cur.copy_expert(seg[1], io.StringIO(seg[2]))
    if label:
        print("    %s" % label)


def reset(cur):
    for r in ("analyst_ro",):
        for stmt in ("DROP OWNED BY %s" % r, "DROP ROLE %s" % r):
            try:
                cur.execute(stmt)
            except Exception:
                pass
    cur.execute("DROP SCHEMA IF EXISTS %s CASCADE" % ", ".join(SCHEMAS))


def build(cur, team):
    """Do what the container's init scripts do."""
    reset(cur)
    for f in sorted(glob.glob(os.path.join(ROOT, "initdb", "*.sql"))):
        run_file(cur, f)
    # emulate 08_load_team_data.sh
    run_file(cur, os.path.join(ROOT, "data", "team%d.sql" % team))
    cur.execute("INSERT INTO meta.dataset_info (team) VALUES (%s)", (team,))


def report(cur, title):
    cur.execute("""SELECT id, kind, name, expected, actual, status, hint
                   FROM test.result ORDER BY kind DESC, seq""")
    rows = cur.fetchall()
    core = [r for r in rows if r[1] == "core"]
    bonus = [r for r in rows if r[1] == "bonus"]
    cp = sum(1 for r in core if r[5] == "PASS")
    bp = sum(1 for r in bonus if r[5] == "PASS")

    print("\n  %-7s %-52s %-14s %-14s %s"
          % ("#", "TEST", "EXPECTED", "YOU GOT", "RESULT"))
    print("  " + "-" * 104)
    for r in rows:
        exp = (r[3] or "")[:14]
        act = (r[4] or "")[:14]
        print("  %-7s %-52s %-14s %-14s %s" % (r[0], r[2][:52], exp, act, r[5]))
    print("  " + "-" * 104)
    print("  %s:  CORE %d/%d   BONUS %d/%d"
          % (title, cp, len(core), bp, len(bonus)))
    for r in rows:
        if r[5] != "PASS":
            print("        FAILED %s  %s" % (r[0], r[2]))
            print("               expected [%s]  got [%s]" % (r[3], r[4]))
    return cp, len(core), bp, len(bonus)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--team", type=int)
    ap.add_argument("--challenge2", action="store_true")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--no-solution", action="store_true",
                    help="run the STARTER file instead of the reference solution")
    args = ap.parse_args()

    conn = psycopg2.connect(conn_string())
    conn.autocommit = True
    cur = conn.cursor()

    teams = [args.team] if args.team else ([1, 2, 3, 4, 5] if args.all else [])
    results = []

    for team in teams:
        t0 = time.time()
        which = "STARTER" if args.no_solution else "SOLUTION"
        print("\n" + "=" * 106)
        print("TEAM %d  (%s)" % (team, which))
        print("=" * 106)
        build(cur, team)
        print("    database built in %.1fs" % (time.time() - t0))

        sol = (os.path.join(ROOT, "challenges", "challenge-1", "team-%d" % team, "solution.sql")
               if args.no_solution else
               os.path.join(ROOT, "_organiser", "solutions", "challenge-1",
                            "team-%d-solution.sql" % team))
        try:
            run_file(cur, sol, "%s ran cleanly" % which.lower())
        except Exception as ex:
            print("    !! %s FAILED TO RUN: %s" % (which, str(ex).strip()[:300]))
            results.append((("team %d %s" % (team, which.lower())), 0, 0, 0, 0))
            continue

        run_file(cur, os.path.join(ROOT, "tests",
                                   "challenge1_team%d_tests.sql" % team))
        results.append((("team %d %s" % (team, which.lower())),) +
                       report(cur, "Team %d" % team))

    if args.challenge2 or args.all:
        print("\n" + "=" * 106)
        print("CHALLENGE 2  (%s)" % ("STARTER" if args.no_solution else "SOLUTION"))
        print("=" * 106)
        build(cur, 1)
        sol = (os.path.join(ROOT, "challenges", "challenge-2", "solution.sql")
               if args.no_solution else
               os.path.join(ROOT, "_organiser", "solutions", "challenge-2", "solution.sql"))
        try:
            run_file(cur, sol, "pipeline ran cleanly")
            if not args.no_solution:
                run_file(cur, sol, "pipeline ran a SECOND time (idempotency)")
        except Exception as ex:
            print("    !! FAILED TO RUN: %s" % str(ex).strip()[:300])
            sys.exit(1)
        run_file(cur, os.path.join(ROOT, "tests", "challenge2_tests.sql"))
        results.append(("challenge 2",) + report(cur, "Challenge 2"))

    print("\n" + "=" * 106)
    print("SUMMARY")
    print("=" * 106)
    allgreen = True
    for name, cp, ct, bp, bt in results:
        flag = "OK " if (ct and cp == ct) else "!! "
        if not ct or cp != ct:
            allgreen = False
        print("  %s %-24s core %2d/%-2d   bonus %2d/%-2d" % (flag, name, cp, ct, bp, bt))
    print("=" * 106)
    sys.exit(0 if allgreen else 1)


if __name__ == "__main__":
    main()
