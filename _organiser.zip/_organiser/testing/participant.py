#!/usr/bin/env python3
"""
ORGANISER ONLY - play the hackathon as a participant would.

Mimics what a student's ./start.sh, ./explore.sh and ./check.sh do, but
against the validation database.

    python _organiser/testing/participant.py reset 3
    python _organiser/testing/participant.py sql "SELECT count(*) FROM raw.address"
    python _organiser/testing/participant.py values raw.claim claim_status
    python _organiser/testing/participant.py check 3

`check` runs MY working copy at _organiser/participant-run/team-N/solution.sql
(seeded from the shipped starter on first reset), never the reference solution.
"""
import io
import os
import shutil
import sys

import psycopg2

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import run_db_tests as R                                   # noqa: E402

ROOT = R.ROOT
WORK = os.path.join(ROOT, "_organiser", "participant-run")


def connect():
    c = psycopg2.connect(R.conn_string())
    c.autocommit = True
    return c


def show(cur, sql, limit_note=True):
    cur.execute(sql)
    if cur.description is None:
        print("   (no rows returned)")
        return
    cols = [d[0] for d in cur.description]
    rows = cur.fetchall()
    widths = [len(c) for c in cols]
    for r in rows:
        for i, v in enumerate(r):
            widths[i] = min(max(widths[i], len(str(v)) if v is not None else 6), 46)
    line = "  " + "  ".join(c[:widths[i]].ljust(widths[i]) for i, c in enumerate(cols))
    print(line)
    print("  " + "  ".join("-" * w for w in widths))
    for r in rows[:60]:
        print("  " + "  ".join(
            (("NULL" if v is None else str(v))[:widths[i]]).ljust(widths[i])
            for i, v in enumerate(r)))
    if limit_note and len(rows) > 60:
        print("  ... %d more rows" % (len(rows) - 60))
    print("  (%d rows)" % len(rows))


def cmd_reset(team):
    conn = connect()
    cur = conn.cursor()
    print("Rebuilding the database as team %d ..." % team)
    R.build(cur, team)
    cur.execute("SELECT count(*) FROM raw.claimant")
    n = cur.fetchone()[0]
    print("  ready: %d rows in raw.claimant" % n)

    # Seed my working copy from the shipped starter, like opening the file
    # for the first time.
    d = os.path.join(WORK, "team-%d" % team)
    os.makedirs(d, exist_ok=True)
    dest = os.path.join(d, "solution.sql")
    src = os.path.join(ROOT, "challenges", "challenge-1", "team-%d" % team, "solution.sql")
    if not os.path.exists(dest):
        shutil.copyfile(src, dest)
        print("  working copy created: %s" % os.path.relpath(dest, ROOT))
    else:
        print("  working copy kept:    %s" % os.path.relpath(dest, ROOT))


def cmd_check(team):
    conn = connect()
    cur = conn.cursor()
    sol = os.path.join(WORK, "team-%d" % team, "solution.sql")
    print("Running my SQL (%s)" % os.path.relpath(sol, ROOT))
    try:
        R.run_file(cur, sol, "ran cleanly")
    except Exception as ex:
        print("\n  *** MY SQL DID NOT RUN ***")
        print("  " + str(ex).strip()[:500])
        return
    R.run_file(cur, os.path.join(ROOT, "tests", "challenge1_team%d_tests.sql" % team))
    R.report(cur, "Team %d" % team)


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    cmd = sys.argv[1]
    if cmd == "reset":
        cmd_reset(int(sys.argv[2]))
    elif cmd == "check":
        cmd_check(int(sys.argv[2]))
    elif cmd == "sql":
        show(connect().cursor(), sys.argv[2])
    elif cmd == "values":
        tbl, col = sys.argv[2], sys.argv[3]
        show(connect().cursor(), """
            SELECT '[' || COALESCE(%s::text,'<NULL>') || ']' AS value_in_brackets,
                   count(*) AS rows
            FROM %s GROUP BY %s ORDER BY count(*) DESC, 1 LIMIT 40""" % (col, tbl, col))
    else:
        sys.exit("unknown command: " + cmd)


if __name__ == "__main__":
    main()
