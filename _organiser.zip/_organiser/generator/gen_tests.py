#!/usr/bin/env python3
"""
Build the test files from the manifest, so tests and data can never drift.

Run:  python _organiser/generator/gen_tests.py
"""
import io
import json
import os
import re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
M = json.load(io.open(os.path.join(ROOT, "_organiser/generator/manifest.json"),
                      encoding="utf-8"))
REF = M["reference_date"]

JUNK = "('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')"
NINO_NORM = "upper(replace(replace(btrim(nino), ' ', ''), '-', ''))"
MONEY = "to_char(%s, 'FM99999999990.00')"


TASKS = {'C1.01': '5',
         'C1.02': '5',
         'C1.03': '5',
         'C1.04': '3',
         'C1.05': '1',
         'C1.06': '1',
         'C1.07': '2',
         'C1.08': '5',
         'C1.09': '5',
         'C2.01': '6',
         'C2.02': '6',
         'C2.03': '6',
         'C2.04': '2',
         'C2.05': '3',
         'C2.06': '1',
         'C2.07': '5',
         'C2.08': '6',
         'C3.01': '1',
         'C3.02': '4 and 5',
         'C3.03': '3',
         'C3.04': '5',
         'C3.05': '6',
         'C3.06': '4',
         'C3.07': '2',
         'C3.08': '6',
         'C4.01': '1 and 2',
         'C4.02': '1 and 2',
         'C4.03': '1 and 2',
         'C4.04': '5 and 6',
         'C4.05': '6',
         'C4.06': '6',
         'C4.07': '3',
         'C4.08': '6',
         'C5.01': '5',
         'C5.02': '1',
         'C5.03': '1',
         'C5.04': '1',
         'C5.05': '2',
         'C5.06': '2',
         'C5.07': '3',
         'C5.08': '7',
         'C5.09': '6',
         'D.01': '2',
         'D.02': '5',
         'D.03': '5',
         'D.04': '4',
         'D.05': '2',
         'D.06': '2',
         'D.07': '2',
         'D.08': '6',
         'D.09': '6',
         'D.10': '3 and 4',
         'D.11': '7',
         'D.12': '8'}


def q(sql):
    return " ".join(sql.split())


def chk(tid, kind, name, expected, sql, hint=""):
    """The task number comes from TASKS, so it cannot drift from the hint."""
    task = TASKS.get(tid) or ""
    return ("SELECT test.check('%s', '%s', %s, $n$%s$n$, $e$%s$e$,\n"
            "    $q$%s$q$,\n"
            "    $h$%s$h$);\n"
            % (tid, kind,
               ("'%s'" % task) if task else "NULL",
               name, expected, q(sql), hint))


def header(title, subtitle):
    return """-- ---------------------------------------------------------------------------
-- %s
-- %s
--
-- YOU DO NOT NEED TO READ THIS FILE.
--
-- It is the machinery that marks your work, and it is written for the
-- database rather than for a person. The readable version is the
-- scorecard it produces:
--
--     ./check.sh 1
--
-- That prints every check in plain English, what the right answer is,
-- what your SQL produced, and which task to look at. That scorecard is
-- your specification - you were given it at the start on purpose. If you
-- can make it all say PASS, you have done the job.
--
-- Reading a failure:
--   'expected' is the right answer. 'you got' is what your SQL produced.
--   'ERROR: ...' means that one check could not run - usually a table
--   that does not exist yet, or a misspelled column. The others still ran.
--
-- (Curious how it works? Read on. Nothing here is a secret. But nothing
--  here is required either.)
-- ---------------------------------------------------------------------------

SELECT test.reset();

""" % (title, subtitle)


def write(path, text):
    full = os.path.join(ROOT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with io.open(full, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    print("  wrote %s" % path)


# ===========================================================================
# TEAM 1 - The Duplicate Claimants
# ===========================================================================
def team1():
    e = M["teams"]["1"]
    out = [header("CHALLENGE 1 - TEAM 1 - The Duplicate Claimants",
                  "Goal: one row per real person in clean.claimant.")]

    out.append(chk("C1.01", "core",
        "clean.claimant has one row for each real person",
        e["clean_claimant_count"],
        "SELECT count(*)::text FROM clean.claimant",
        "Are you inserting anything at all?"))

    out.append(chk("C1.02", "core",
        "Nobody was lost - everyone in raw is in clean",
        "0",
        """SELECT count(*)::text FROM (
             SELECT DISTINCT %s AS n FROM raw.claimant
           ) r LEFT JOIN clean.claimant c ON c.nino = r.n
           WHERE c.nino IS NULL""" % NINO_NORM,
        "De-duplicating must not throw whole people away."))

    out.append(chk("C1.03", "core",
        "%d raw records became %d people" % (e["raw_claimant_rows"], e["clean_claimant_count"]),
        "%d -> %d" % (e["raw_claimant_rows"], e["clean_claimant_count"]),
        """SELECT (SELECT count(*) FROM raw.claimant)::text || ' -> ' ||
                  (SELECT count(*) FROM clean.claimant)::text""",
        "Too many rows means duplicates survived."))

    out.append(chk("C1.04", "core",
        "Every NINO is 2 letters, 6 digits and 1 letter",
        "0",
        """SELECT count(*)::text FROM clean.claimant
           WHERE nino !~ '^[A-Z]{2}[0-9]{6}[A-Z]$'""",
        "'qq 12 34 56 c' and 'QQ-12-34-56-C' are the same person."))

    out.append(chk("C1.05", "core",
        "Names have no leading or trailing spaces",
        "0",
        """SELECT count(*)::text FROM clean.claimant
           WHERE first_name <> btrim(first_name) OR last_name <> btrim(last_name)""",
        "Use btrim() (also called trim)."))

    out.append(chk("C1.06", "core",
        "Names are Title Case, not SHOUTING or lower case",
        "0",
        """SELECT count(*)::text FROM clean.claimant
           WHERE first_name <> initcap(first_name) OR last_name <> initcap(last_name)""",
        "Use initcap() after trimming."))

    out.append(chk("C1.07", "core",
        "Placeholder text like N/A and UNKNOWN is gone",
        "0",
        """SELECT count(*)::text FROM clean.claimant
           WHERE btrim(coalesce(email,'x')) IN %s
              OR btrim(coalesce(phone,'x')) IN %s
              OR btrim(coalesce(marital_status,'x')) IN %s""" % (JUNK, JUNK, JUNK),
        "'N/A' is not a value - it should be NULL."))

    out.append(chk("C1.08", "core",
        "Survivorship: the newest record won (person A)",
        e["anchor_email"],
        """SELECT coalesce(lower(email), '<no email>') FROM clean.claimant
           WHERE nino = '%s'""" % e["anchor_nino"],
        "%s has %d records, each with a different email."
        % (e["anchor_nino"], e["anchor_records"])))

    out.append(chk("C1.09", "core",
        "Survivorship: the newest record won (person B)",
        e["anchor2_email"],
        """SELECT coalesce(lower(email), '<no email>') FROM clean.claimant
           WHERE nino = '%s'""" % e["anchor2_nino"],
        "Order by ingested_at, newest first."))

    out.append(chk("C1.B1", "bonus",
        "Titles tidied to Mr / Mrs / Ms / Miss",
        "0",
        """SELECT count(*)::text FROM clean.claimant
           WHERE title IS NULL OR title NOT IN ('Mr','Mrs','Ms','Miss')""",
        "Bonus A. Watch out for 'MR.' and 'mr'."))

    out.append(chk("C1.B2", "bonus",
        "Best available email recovered from all of a person's records",
        e["emails_null_best_available"],
        """SELECT count(*)::text FROM clean.claimant WHERE email IS NULL""",
        "Bonus B. If the newest record has no email, look at the older ones."))

    out.append(chk("C1.B3", "bonus",
        "Phone numbers stored as 11 digits, no spaces",
        "0",
        """SELECT count(*)::text FROM clean.claimant
           WHERE phone IS NOT NULL AND phone !~ '^0[0-9]{10}$'""",
        "Bonus C. Strip the spaces out of the phone number."))

    return "".join(out)


# ===========================================================================
# TEAM 2 - The Date Disaster
# ===========================================================================
def team2():
    e = M["teams"]["2"]
    out = [header("CHALLENGE 1 - TEAM 2 - The Date Disaster",
                  "Goal: every date in clean.claimant is a real, believable date.")]

    out.append(chk("C2.01", "core",
        "clean.claimant holds only people with a usable date of birth",
        e["clean_claimant_count"],
        "SELECT count(*)::text FROM clean.claimant",
        "Records with an unusable date of birth are left out."))

    out.append(chk("C2.02", "core",
        "%d raw records became %d usable people" % (e["raw_claimant_rows"], e["clean_claimant_count"]),
        "%d -> %d" % (e["raw_claimant_rows"], e["clean_claimant_count"]),
        """SELECT (SELECT count(*) FROM raw.claimant)::text || ' -> ' ||
                  (SELECT count(*) FROM clean.claimant)::text""",
        "%d records cannot be saved and must be excluded." % e["excluded_count"]))

    out.append(chk("C2.03", "core",
        "Every date of birth is believable for a pensioner",
        "0",
        """SELECT count(*)::text FROM clean.claimant
           WHERE date_of_birth < DATE '1930-01-01'
              OR date_of_birth > DATE '1961-12-31'""",
        "1900-01-01 and 9999-12-31 are not real birthdays."))

    out.append(chk("C2.04", "core",
        "LEGACY_CSV dates read as day/month (%s is %s)"
        % (e["anchor_uk_raw"], e["anchor_uk_dob"]),
        e["anchor_uk_dob"],
        """SELECT coalesce(to_char(date_of_birth, 'YYYY-MM-DD'), '<missing>')
           FROM clean.claimant WHERE nino = '%s'""" % e["anchor_uk_nino"],
        "LEGACY_CSV writes DD/MM/YYYY, not MM/DD/YYYY."))

    out.append(chk("C2.05", "core",
        "DIGITAL dates like %s parsed correctly" % e["anchor_mon_raw"],
        e["anchor_mon_dob"],
        """SELECT coalesce(to_char(date_of_birth, 'YYYY-MM-DD'), '<missing>')
           FROM clean.claimant WHERE nino = '%s'""" % e["anchor_mon_nino"],
        "The format string for 12-Jul-1948 is DD-Mon-YYYY."))

    out.append(chk("C2.06", "core",
        "CIS dates parsed correctly",
        e["anchor_iso_dob"],
        """SELECT coalesce(to_char(date_of_birth, 'YYYY-MM-DD'), '<missing>')
           FROM clean.claimant WHERE nino = '%s'""" % e["anchor_iso_nino"],
        "CIS writes YYYY-MM-DD."))

    out.append(chk("C2.07", "core",
        "Exactly %d people have really died" % e["deceased_count"],
        e["deceased_count"],
        "SELECT count(*)::text FROM clean.claimant WHERE date_of_death IS NOT NULL",
        "A death before birth, or in 2029, is an error - not a death."))

    out.append(chk("C2.08", "core",
        "The oldest person was born %s" % e["oldest_dob"],
        e["oldest_dob"],
        "SELECT coalesce(to_char(min(date_of_birth),'YYYY-MM-DD'),'<none>') FROM clean.claimant",
        "If this is 1900 you have kept a placeholder date."))

    out.append(chk("C2.B1", "bonus",
        "clean.claim is populated with converted start dates",
        e["claim_count"],
        "SELECT count(*)::text FROM clean.claim",
        "Bonus A. Same CASE pattern, applied to raw.claim."))

    out.append(chk("C2.B2", "bonus",
        "Claim start dates parsed correctly",
        e["anchor_claim_start"],
        """SELECT coalesce(to_char(claim_start_date,'YYYY-MM-DD'),'<missing>')
           FROM clean.claim WHERE claim_ref = '%s'""" % e["anchor_claim_ref"],
        "Bonus A. Join to raw.claimant to find the source system."))

    out.append(chk("C2.B3", "bonus",
        "Nobody claimed their pension before turning 66",
        "0",
        """SELECT count(*)::text
           FROM clean.claim c JOIN clean.claimant p ON p.nino = c.nino
           WHERE c.claim_start_date < (p.date_of_birth + INTERVAL '66 years')""",
        "Bonus B. Needs Bonus A finished first."))

    return "".join(out)


# ===========================================================================
# TEAM 3 - The Address Mess
# ===========================================================================
def team3():
    e = M["teams"]["3"]
    out = [header("CHALLENGE 1 - TEAM 3 - The Address Mess",
                  "Goal: one tidy, valid, current address for every claimant.")]

    out.append(chk("C3.01", "core",
        "clean.claimant is populated (this part is written for you)",
        e["clean_claimant_count"],
        "SELECT count(*)::text FROM clean.claimant",
        "Just run the INSERT that is already in your file."))

    out.append(chk("C3.02", "core",
        "clean.address holds only usable addresses",
        e["clean_address_count"],
        "SELECT count(*)::text FROM clean.address",
        "%d bad postcodes and %d orphans must go."
        % (e["bad_postcodes"], e["orphan_addresses"])))

    out.append(chk("C3.03", "core",
        "Every postcode is a valid UK postcode, tidily formatted",
        "0",
        """SELECT count(*)::text FROM clean.address
           WHERE postcode IS NULL
              OR postcode !~ '^[A-Z]{1,2}[0-9][A-Z0-9]? [0-9][A-Z]{2}$'""",
        "'sw1a1aa' should become 'SW1A 1AA'."))

    out.append(chk("C3.04", "core",
        "Addresses belonging to unknown people were dropped",
        e["clean_claimant_count"],
        "SELECT count(DISTINCT nino)::text FROM clean.address",
        "%d addresses point at people who do not exist."
        % e["orphan_addresses"]))

    out.append(chk("C3.05", "core",
        "Each claimant has ONE current address, and it is the latest one",
        "0",
        """SELECT count(*)::text FROM (
             SELECT nino FROM clean.address
             GROUP BY nino
             HAVING count(*) FILTER (WHERE is_current) <> 1
                 OR max(valid_from) FILTER (WHERE is_current)
                    IS DISTINCT FROM max(valid_from)
           ) bad""",
        "Do not trust is_current - the latest valid_from wins."))

    out.append(chk("C3.06", "core",
        "Nobody was left without an address",
        "0",
        """SELECT count(*)::text FROM clean.claimant c
           LEFT JOIN clean.address a ON a.nino = c.nino
           WHERE a.nino IS NULL""",
        "Only ever drop an address the person is no longer at."))

    out.append(chk("C3.07", "core",
        "Town names are tidy",
        "0",
        """SELECT count(*)::text FROM clean.address
           WHERE town <> initcap(btrim(town))""",
        "btrim() then initcap()."))

    out.append(chk("C3.08", "core",
        "A known claimant's current postcode is correct",
        e["anchor_postcode"],
        """SELECT coalesce(max(postcode), '<missing>') FROM clean.address
           WHERE nino = '%s' AND is_current""" % e["anchor_nino"],
        "Check you picked the newest address for this person."))

    out.append(chk("C3.B1", "bonus",
        "clean.address_summary has one row per region",
        e["regions_present"],
        "SELECT count(*)::text FROM clean.address_summary",
        "Bonus. Build the table first - see the bottom of your file."))

    out.append(chk("C3.B2", "bonus",
        "The summary says %d claimants live in London" % e["region_london"],
        e["region_london"],
        """SELECT coalesce(max(claimant_count)::text, '<no row>')
           FROM clean.address_summary WHERE region = 'London'""",
        "Bonus. Join through ref.postcode_area to get the region."))

    out.append(chk("C3.B3", "bonus",
        "The summary accounts for all %d claimants" % e["clean_claimant_count"],
        e["clean_claimant_count"],
        "SELECT coalesce(sum(claimant_count)::text, '0') FROM clean.address_summary",
        "Bonus. Count current addresses only, or you will double-count movers."))

    return "".join(out)


# ===========================================================================
# TEAM 4 - The Money Problem
# ===========================================================================
def team4():
    e = M["teams"]["4"]
    out = [header("CHALLENGE 1 - TEAM 4 - The Money Problem",
                  "Goal: money stored as numbers, and every payment counted once.")]

    out.append(chk("C4.01", "core",
        "clean.claim has every claim",
        e["clean_claim_count"],
        "SELECT count(*)::text FROM clean.claim",
        "Every claim should make it through."))

    out.append(chk("C4.02", "core",
        "Weekly amounts are sensible numbers",
        "0",
        """SELECT count(*)::text FROM clean.claim
           WHERE weekly_amount IS NULL OR weekly_amount <= 0 OR weekly_amount > 300""",
        "A stray comma turns 185.15 into something odd."))

    out.append(chk("C4.03", "core",
        "The weekly amounts add up to %s" % e["weekly_amount_total"],
        e["weekly_amount_total"],
        "SELECT %s FROM clean.claim" % (MONEY % "sum(weekly_amount)"),
        "If this is out, a pound sign or comma got through."))

    out.append(chk("C4.04", "core",
        "Failed and pending payments were left out",
        e["clean_payment_count"],
        "SELECT count(*)::text FROM clean.payment",
        "%d FAILED and %d PENDING must go, and %d double-postings."
        % (e["failed_payments"], e["pending_payments"], e["duplicate_payments"])))

    out.append(chk("C4.05", "core",
        "No payment was entered twice",
        "0",
        """SELECT count(*)::text FROM (
             SELECT claim_ref, payment_date, amount
             FROM clean.payment
             GROUP BY 1, 2, 3 HAVING count(*) > 1
           ) d""",
        "Same claim, same date, same amount = entered twice."))

    out.append(chk("C4.06", "core",
        "Reversals were KEPT, not deleted (%d of them)" % e["reversal_count"],
        e["reversal_count"],
        "SELECT count(*)::text FROM clean.payment WHERE amount < 0",
        "A reversal is a real payment. Do not remove it as a duplicate."))

    out.append(chk("C4.07", "core",
        "Total value paid out is %s" % e["settled_total"],
        e["settled_total"],
        "SELECT %s FROM clean.payment WHERE amount > 0" % (MONEY % "sum(amount)"),
        "Parse the amounts before adding them up."))

    out.append(chk("C4.08", "core",
        "Net total after reversals is %s" % e["net_total"],
        e["net_total"],
        "SELECT %s FROM clean.payment" % (MONEY % "sum(amount)"),
        "Should be the total paid out minus the reversals."))

    out.append(chk("C4.B1", "bonus",
        "clean.claim_payment_summary has one row per claim",
        e["clean_claim_count"],
        "SELECT count(*)::text FROM clean.claim_payment_summary",
        "Bonus. Build the table first - see the bottom of your file."))

    out.append(chk("C4.B2", "bonus",
        "The summary accounts for all %d payments" % e["clean_payment_count"],
        e["clean_payment_count"],
        "SELECT coalesce(sum(payment_count)::text, '0') FROM clean.claim_payment_summary",
        "Bonus. Every payment belongs to exactly one claim."))

    out.append(chk("C4.B3", "bonus",
        "The summary totals to %s, the net figure" % e["net_total"],
        e["net_total"],
        "SELECT %s FROM clean.claim_payment_summary" % (MONEY % "sum(total_paid)"),
        "Bonus. Reversals are negative, so they pull the total down."))

    return "".join(out)


# ===========================================================================
# TEAM 5 - The Code Chaos
# ===========================================================================
def team5():
    e = M["teams"]["5"]
    out = [header("CHALLENGE 1 - TEAM 5 - The Code Chaos",
                  "Goal: one agreed code for each thing, and no orphan records.")]

    out.append(chk("C5.01", "core",
        "clean.claim excludes claims for people who do not exist",
        e["clean_claim_count"],
        "SELECT count(*)::text FROM clean.claim",
        "%d of the %d raw claims are orphans."
        % (e["orphan_claims"], e["clean_claim_count"] + e["orphan_claims"])))

    out.append(chk("C5.02", "core",
        "Claim status only ever uses the three agreed codes",
        "0",
        """SELECT count(*)::text FROM clean.claim
           WHERE claim_status IS NULL
              OR claim_status NOT IN ('ACTIVE','SUSPENDED','CLOSED')""",
        "Anything you did not map will show up here."))

    out.append(chk("C5.03", "core",
        "%d claims are ACTIVE" % e["status_active"],
        e["status_active"],
        "SELECT count(*)::text FROM clean.claim WHERE claim_status = 'ACTIVE'",
        "'A', 'LIVE', 'In Payment' and 'INPAY' all mean ACTIVE."))

    out.append(chk("C5.04", "core",
        "%d claims are CLOSED" % e["status_closed"],
        e["status_closed"],
        "SELECT count(*)::text FROM clean.claim WHERE claim_status = 'CLOSED'",
        "'C', 'Ceased' and 'Terminated' all mean CLOSED."))

    out.append(chk("C5.05", "core",
        "Every claim uses one of the two standard pension types",
        "0",
        """SELECT count(*)::text FROM clean.claim
           WHERE pension_type IS NULL
              OR pension_type NOT IN ('NEW_STATE_PENSION','BASIC_STATE_PENSION')""",
        "Category A and Category B are both BASIC_STATE_PENSION."))

    out.append(chk("C5.06", "core",
        "%d claims are New State Pension" % e["pension_new"],
        e["pension_new"],
        "SELECT count(*)::text FROM clean.claim WHERE pension_type = 'NEW_STATE_PENSION'",
        "'nSP', 'NEW' and 'Single Tier' all mean the same thing."))

    out.append(chk("C5.07", "core",
        "%d claims are marked as deferred" % e["deferral_true"],
        e["deferral_true"],
        "SELECT count(*)::text FROM clean.claim WHERE deferral_indicator IS TRUE",
        "'Y', 'YES', 'TRUE', 'T' and '1' all mean yes."))

    out.append(chk("C5.08", "core",
        "clean.payment excludes payments for claims that do not exist",
        e["clean_payment_count"],
        "SELECT count(*)::text FROM clean.payment",
        "%d payments point at a claim that is not there."
        % e["orphan_payments"]))

    out.append(chk("C5.09", "core",
        "Methods missing from ref.code_mapping became UNKNOWN",
        e["method_unknown"],
        "SELECT count(*)::text FROM clean.payment WHERE payment_method = 'UNKNOWN'",
        "ref.code_mapping is incomplete. Do not lose those rows."))

    out.append(chk("C5.B1", "bonus",
        "%d claims are SUSPENDED" % e["status_suspended"],
        e["status_suspended"],
        "SELECT count(*)::text FROM clean.claim WHERE claim_status = 'SUSPENDED'",
        "Bonus A. 'SUSP', 'S' and 'On Hold' all mean SUSPENDED."))

    out.append(chk("C5.B2", "bonus",
        "%d claims are paid four-weekly" % e["freq_four_weekly"],
        e["freq_four_weekly"],
        "SELECT count(*)::text FROM clean.claim WHERE payment_frequency = 'FOUR_WEEKLY'",
        "Bonus B. '4W', '4', 'FOUR WEEKLY' and '4-Weekly' are the same."))

    out.append(chk("C5.B3", "bonus",
        "No payment method was left empty",
        "0",
        "SELECT count(*)::text FROM clean.payment WHERE payment_method IS NULL",
        "Bonus C. Unmapped is not the same as missing - use UNKNOWN."))

    return "".join(out)


# ===========================================================================
# CHALLENGE 2 - the same for every team
# ===========================================================================
def challenge2():
    c = M["curated"]
    out = ["""-- ---------------------------------------------------------------------------
-- CHALLENGE 2 - Safe Data for Analysts
-- Goal: publish analytics tables that are useful but cannot identify anyone.
--
-- These tests are your specification. Run them with:   ./check.sh 2
-- ---------------------------------------------------------------------------

SELECT test.reset();

-- Helper: search every text column in the analytics schema for a pattern.
-- This is how the tests check that no personal data leaked out, wherever
-- you happened to put it.
CREATE OR REPLACE FUNCTION test.scan_analytics(p_pattern TEXT)
RETURNS bigint AS $fn$
DECLARE
    r     RECORD;
    n     bigint;
    total bigint := 0;
BEGIN
    FOR r IN
        SELECT table_name, column_name
        FROM information_schema.columns
        WHERE table_schema = 'analytics'
          AND data_type IN ('text', 'character varying', 'character')
    LOOP
        BEGIN
            EXECUTE format('SELECT count(*) FROM analytics.%I WHERE %I ~ %L',
                           r.table_name, r.column_name, p_pattern)
            INTO n;
            total := total + n;
        EXCEPTION WHEN OTHERS THEN
            NULL;
        END;
    END LOOP;
    RETURN total;
END;
$fn$ LANGUAGE plpgsql;

"""]

    out.append(chk("D.01", "core",
        "analytics.dim_claimant_anon has one row per person",
        c["claimant_count"],
        "SELECT count(*)::text FROM analytics.dim_claimant_anon",
        "Anonymising should not lose anybody."))

    out.append(chk("D.02", "core",
        "No column in analytics is named after personal data",
        "0",
        """SELECT count(*)::text FROM information_schema.columns
           WHERE table_schema = 'analytics'
             AND column_name ~* '(nino|national_insurance|surname|first_name|last_name|email|phone|telephone|date_of_birth|^dob$|full_address|address_line|postcode$)'""",
        "If a column is called 'nino', it should not be here at all."))

    out.append(chk("D.03", "core",
        "No value anywhere in analytics looks like a NINO",
        "0",
        "SELECT test.scan_analytics('[A-Z]{2}[0-9]{6}[A-Z]')::text",
        "A renamed column is still a leak. Do not carry the value."))

    out.append(chk("D.04", "core",
        "No value anywhere in analytics looks like a full postcode",
        "0",
        "SELECT test.scan_analytics('[A-Z]{1,2}[0-9][A-Z0-9]? [0-9][A-Z]{2}')::text",
        "Publish the area (SW), never the full postcode."))

    out.append(chk("D.05", "core",
        "Every person has a different pseudonym",
        c["claimant_count"],
        "SELECT count(DISTINCT person_pseudo_id)::text FROM analytics.dim_claimant_anon",
        "Two people sharing a pseudonym would corrupt every count."))

    out.append(chk("D.06", "core",
        "Pseudonyms are 32-character hashes",
        "0",
        """SELECT count(*)::text FROM analytics.dim_claimant_anon
           WHERE person_pseudo_id IS NULL OR person_pseudo_id !~ '^[0-9a-f]{32}$'""",
        "md5() returns 32 hex characters."))

    out.append(chk("D.07", "core",
        "The pseudonym is SALTED, not a plain hash of the NINO",
        "0",
        """SELECT count(*)::text
           FROM analytics.dim_claimant_anon d
           JOIN curated.claimant c ON d.person_pseudo_id = md5(c.nino)""",
        "Use md5(salt || nino). Read the salt from meta.etl_config."))

    out.append(chk("D.08", "core",
        "Every claim links back to a person in the dimension",
        "0",
        """SELECT count(*)::text FROM analytics.fct_claim_anon f
           LEFT JOIN analytics.dim_claimant_anon d
             ON d.person_pseudo_id = f.person_pseudo_id
           WHERE d.person_pseudo_id IS NULL""",
        "Pseudonymise consistently or the join breaks."))

    out.append(chk("D.09", "core",
        "analytics.fct_claim_anon has one row per claim",
        c["claim_count"],
        "SELECT count(*)::text FROM analytics.fct_claim_anon",
        "Build this from curated.claim."))

    out.append(chk("D.10", "core",
        "Everyone has a region and an age band",
        "0",
        """SELECT count(*)::text FROM analytics.dim_claimant_anon
           WHERE region IS NULL OR age_band IS NULL""",
        "A NULL region usually means the join missed."))

    out.append(chk("D.11", "core",
        "k-anonymity: no group of age band + sex + region is smaller than 5",
        "0",
        """SELECT count(*)::text FROM (
             SELECT age_band, sex, region
             FROM analytics.dim_claimant_anon
             GROUP BY 1, 2, 3
             HAVING count(*) < 5
           ) too_small""",
        "Widen your age bands until every group has 5 or more people."))

    out.append(chk("D.12", "core",
        "The published summary never shows a count of 1 to 4",
        "0",
        """SELECT count(*)::text FROM analytics.agg_claims_by_region
           WHERE claim_count BETWEEN 1 AND 4""",
        "A count of 2 leaks as badly as a group of 2. Use NULL."))

    out.append(chk("D.B1", "bonus",
        "The summary covers all %d regions" % c["regions"],
        c["regions"],
        "SELECT count(DISTINCT region)::text FROM analytics.agg_claims_by_region",
        "Bonus A. Suppressing a count is fine. Losing the row is not."))

    out.append(chk("D.B2", "bonus",
        "An analyst role exists and can read the analytics schema",
        "yes",
        """SELECT CASE WHEN has_table_privilege('analyst_ro',
                        'analytics.dim_claimant_anon', 'SELECT')
                  THEN 'yes' ELSE 'no' END""",
        "Bonus B. CREATE ROLE analyst_ro; then GRANT SELECT."))

    out.append(chk("D.B3", "bonus",
        "The analyst role CANNOT read the curated schema",
        "no",
        """SELECT CASE WHEN has_table_privilege('analyst_ro',
                        'curated.claimant', 'SELECT')
                  THEN 'yes' ELSE 'no' END""",
        "Bonus B. Analysts must not reach the personal data."))

    return "".join(out)


# ---------------------------------------------------------------------------
# Guard: every task number a test points at must actually exist in that
# team's starter file. Task numbers have drifted three times now; this makes
# it impossible to ship a hint that sends a student to a task that is not
# there.
# ---------------------------------------------------------------------------
def check_tasks_exist():
    problems = []
    for team in range(1, 6):
        path = os.path.join(ROOT, "challenges", "challenge-1",
                            "team-%d" % team, "solution.sql")
        text = io.open(path, encoding="utf-8").read()
        available = set()
        for line in re.findall(r"^--   Tasks? ?[0-9+]+.*$", text, re.M):
            available.update(re.findall(r"\d+", line.split("line")[0]))
        for tid, task in TASKS.items():
            if not tid.startswith("C%d." % team) or not task:
                continue
            for n in re.findall(r"\d+", task):
                if n not in available:
                    problems.append("  %s points at Task %s; team %d has only %s"
                                    % (tid, n, team, sorted(available, key=int)))
    # Challenge 2 is one shared file, checked the same way.
    c2 = io.open(os.path.join(ROOT, "challenges", "challenge-2", "solution.sql"),
                 encoding="utf-8").read()
    c2_available = set()
    for line in re.findall(r"^--   Tasks? ?[0-9+]+.*$", c2, re.M):
        c2_available.update(re.findall(r"\d+", line.split("line")[0]))
    for tid, task in TASKS.items():
        if not tid.startswith("D.") or not task:
            continue
        for n in re.findall(r"\d+", task):
            if n not in c2_available:
                problems.append("  %s points at Task %s; challenge 2 has only %s"
                                % (tid, n, sorted(c2_available, key=int)))

    if problems:
        raise SystemExit("TASK NUMBERS DO NOT MATCH THE STARTERS:\n" + "\n".join(problems))
    print("  task numbers checked against all five starters and challenge 2: OK")


print("Generating test files")
check_tasks_exist()
print("=" * 62)
write("tests/challenge1_team1_tests.sql", team1())
write("tests/challenge1_team2_tests.sql", team2())
write("tests/challenge1_team3_tests.sql", team3())
write("tests/challenge1_team4_tests.sql", team4())
write("tests/challenge1_team5_tests.sql", team5())
write("tests/challenge2_tests.sql", challenge2())
print("=" * 62)
print("Done.")
