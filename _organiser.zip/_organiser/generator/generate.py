#!/usr/bin/env python3
"""
State Pension Hackathon - dataset generator (ORGANISER ONLY).

Produces, deterministically:
    data/team1.sql .. data/team5.sql   the five corrupted Challenge 1 datasets
    initdb/02_reference_data.sql       ref.postcode_area, ref.code_mapping
    initdb/05_curated_data.sql         the Challenge 2 input (same for all teams)
    _organiser/generator/manifest.json ground truth used to build the tests

Run:  python _organiser/generator/generate.py
"""

import io
import json
import os
import random
from datetime import date, timedelta

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

REFERENCE_DATE = date(2026, 4, 6)   # start of the 2026/27 tax year
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

N_PEOPLE = 1200          # distinct people per team dataset
N_CURATED = 1500         # people in the Challenge 2 dataset

# --------------------------------------------------------------------------
# Name and place pools
# --------------------------------------------------------------------------
FIRST_M = ["John", "Peter", "David", "Michael", "Brian", "Alan", "Keith", "Derek",
           "Colin", "Roy", "Trevor", "Malcolm", "Gordon", "Raymond", "Terence",
           "Clive", "Norman", "Stanley", "Leonard", "Cyril", "Arthur", "Bernard",
           "Frank", "Harold", "Sidney", "Reginald", "Wilfred", "Ronald", "Douglas",
           "Maurice", "Nigel", "Graham", "Barry", "Neville", "Stuart"]
FIRST_F = ["Margaret", "Patricia", "Susan", "Linda", "Barbara", "Elizabeth", "Jean",
           "Sheila", "Joan", "Maureen", "Doreen", "Brenda", "Pauline", "Janet",
           "Sylvia", "Irene", "Marion", "Gillian", "Hazel", "Valerie", "Beryl",
           "Eileen", "Audrey", "Vera", "Rosemary", "Kathleen", "Dorothy", "Edna",
           "Muriel", "Norma", "Sandra", "Carol", "Christine", "Wendy", "Diane"]
LAST = ["Smith", "Jones", "Taylor", "Brown", "Williams", "Wilson", "Johnson",
        "Davies", "Robinson", "Wright", "Thompson", "Evans", "Walker", "White",
        "Roberts", "Green", "Hall", "Wood", "Jackson", "Clarke", "Turner",
        "Hill", "Harris", "Cooper", "Ward", "Morris", "Moore", "Clark", "Lee",
        "King", "Baker", "Harrison", "Morgan", "Allen", "James", "Scott",
        "Phillips", "Watson", "Davis", "Parker", "Price", "Bennett", "Young",
        "Griffiths", "Mitchell", "Kelly", "Cook", "Carter", "Richardson", "Bailey",
        "Murphy", "Rogers", "Bell", "Collins", "Shaw", "Gray", "Chapman"]

STREETS = ["High Street", "Station Road", "Church Lane", "Victoria Road",
           "Mill Lane", "Park Avenue", "The Green", "Manor Road", "Kings Road",
           "Queens Road", "New Road", "School Lane", "Alexandra Road",
           "Grange Road", "Windsor Road", "Albert Road", "York Road",
           "Chapel Street", "West Street", "Springfield Road", "Oak Avenue",
           "Elm Close", "Beech Drive", "Cedar Grove", "Meadow View"]

# (town, county, postcode area, region)
PLACES = [
    ("London",              "Greater London",   "SW", "London"),
    ("London",              "Greater London",   "SE", "London"),
    ("Manchester",          "Greater Manchester", "M",  "North West"),
    ("Liverpool",           "Merseyside",       "L",  "North West"),
    ("Preston",             "Lancashire",       "PR", "North West"),
    ("Leeds",               "West Yorkshire",   "LS", "Yorkshire and The Humber"),
    ("Sheffield",           "South Yorkshire",  "S",  "Yorkshire and The Humber"),
    ("Hull",                "East Yorkshire",   "HU", "Yorkshire and The Humber"),
    ("Birmingham",          "West Midlands",    "B",  "West Midlands"),
    ("Coventry",            "West Midlands",    "CV", "West Midlands"),
    ("Nottingham",          "Nottinghamshire",  "NG", "East Midlands"),
    ("Leicester",           "Leicestershire",   "LE", "East Midlands"),
    ("Bristol",             "Somerset",         "BS", "South West"),
    ("Plymouth",            "Devon",            "PL", "South West"),
    ("Exeter",              "Devon",            "EX", "South West"),
    ("Southampton",         "Hampshire",        "SO", "South East"),
    ("Brighton",            "East Sussex",      "BN", "South East"),
    ("Reading",             "Berkshire",        "RG", "South East"),
    ("Norwich",             "Norfolk",          "NR", "East of England"),
    ("Cambridge",           "Cambridgeshire",   "CB", "East of England"),
    ("Newcastle upon Tyne", "Tyne and Wear",    "NE", "North East"),
    ("Sunderland",          "Tyne and Wear",    "SR", "North East"),
    ("Cardiff",             "South Glamorgan",  "CF", "Wales"),
    ("Swansea",             "West Glamorgan",   "SA", "Wales"),
    ("Glasgow",             "Lanarkshire",      "G",  "Scotland"),
    ("Edinburgh",           "Midlothian",       "EH", "Scotland"),
    ("Belfast",             "County Antrim",    "BT", "Northern Ireland"),
]

REGIONS = sorted({p[3] for p in PLACES})
AREA_TO_REGION = {}
for _t, _c, _a, _r in PLACES:
    AREA_TO_REGION[_a] = _r
PLACES_BY_REGION = {}
for p in PLACES:
    PLACES_BY_REGION.setdefault(p[3], []).append(p)


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------
def iso(d):
    return d.strftime("%Y-%m-%d") if d else None


def fmt_date(d, style):
    """Write a date the way a particular source system writes it."""
    if d is None:
        return None
    if style == "iso":                       # CIS
        return "%04d-%02d-%02d" % (d.year, d.month, d.day)
    if style == "uk_slash":                  # LEGACY_CSV
        return "%02d/%02d/%04d" % (d.day, d.month, d.year)
    if style == "mon":                       # DIGITAL
        return "%02d-%s-%04d" % (d.day, MONTHS[d.month - 1], d.year)
    raise ValueError(style)


def copy_val(v):
    """Escape one value for a COPY ... FROM stdin block."""
    if v is None:
        return "\\N"
    s = str(v)
    s = s.replace("\\", "\\\\").replace("\t", "\\t")
    s = s.replace("\n", "\\n").replace("\r", "\\r")
    return s


def copy_block(table, cols, rows):
    out = ["COPY %s (%s) FROM stdin;" % (table, ", ".join(cols))]
    for r in rows:
        out.append("\t".join(copy_val(r.get(c)) for c in cols))
    out.append("\\.")
    out.append("")
    return "\n".join(out)


def write(path, text):
    full = os.path.join(ROOT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with io.open(full, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    kb = len(text.encode("utf-8")) / 1024.0
    print("  wrote %-42s %8.1f KB" % (path, kb))


def nino(prefix, n, rng):
    return "%s%06d%s" % (prefix, n, rng.choice("ABCD"))


def messy_ws(s, rng):
    """Add the stray whitespace and casing real data is full of."""
    r = rng.random()
    if r < 0.18:
        s = "  " + s
    elif r < 0.32:
        s = s + "  "
    elif r < 0.38:
        s = " " + s + " "
    r = rng.random()
    if r < 0.22:
        s = s.upper()
    elif r < 0.34:
        s = s.lower()
    return s


def junk_null(rng, real_value, p=0.16):
    """Sometimes replace a value with one of the many ways to say 'nothing'."""
    if rng.random() < p:
        return rng.choice(["", "N/A", "UNKNOWN", "NULL", "n/a", "-", None])
    return real_value


def make_postcode(area, rng):
    district = rng.randint(1, 20)
    inward = "%d%s%s" % (rng.randint(0, 9),
                         rng.choice("ABDEFGHJLNPQRSTUWXYZ"),
                         rng.choice("ABDEFGHJLNPQRSTUWXYZ"))
    return "%s%d %s" % (area, district, inward)


def dob_for_age(age, rng):
    """A birth date that gives exactly this age on the reference date."""
    latest = date(REFERENCE_DATE.year - age, REFERENCE_DATE.month, REFERENCE_DATE.day)
    d = latest - timedelta(days=rng.randint(0, 364))
    return d


def age_on(d, ref=REFERENCE_DATE):
    a = ref.year - d.year
    if (ref.month, ref.day) < (d.month, d.day):
        a -= 1
    return a


# --------------------------------------------------------------------------
# The canonical population (before anyone breaks it)
# --------------------------------------------------------------------------
def make_people(rng, n, nino_prefix, nino_start=100000):
    people = []
    used = set()
    for i in range(n):
        while True:
            num = rng.randint(nino_start, nino_start + 800000)
            if num not in used:
                used.add(num)
                break
        sex = "M" if rng.random() < 0.47 else "F"
        first = rng.choice(FIRST_M if sex == "M" else FIRST_F)
        last = rng.choice(LAST)
        age = rng.choices([66, 68, 71, 74, 77, 80, 83, 86, 89],
                          weights=[16, 15, 14, 13, 12, 11, 8, 6, 5])[0]
        age += rng.randint(0, 2)
        dob = dob_for_age(age, rng)

        dod = None
        if rng.random() < 0.07:
            dod = dob + timedelta(days=int(365.25 * (age - rng.randint(0, 3))) + rng.randint(0, 300))
            if dod >= REFERENCE_DATE:
                dod = REFERENCE_DATE - timedelta(days=rng.randint(30, 900))
            if dod <= dob:
                dod = None

        place = rng.choice(PLACES)
        people.append({
            "nino": nino(nino_prefix, num, rng),
            "title": ("Mr" if sex == "M" else rng.choice(["Mrs", "Ms", "Miss"])),
            "first_name": first,
            "last_name": last,
            "dob": dob,
            "sex": sex,
            "marital_status": rng.choices(
                ["Single", "Married", "Widowed", "Divorced", "Civil Partnership"],
                weights=[18, 44, 22, 13, 3])[0],
            "dod": dod,
            "email": "%s.%s%d@example.invalid" % (first.lower(), last.lower(), num % 1000),
            "phone": "07%03d %06d" % (rng.randint(100, 999), rng.randint(0, 999999)),
            "place": place,
            "source": rng.choices(["CIS", "LEGACY_CSV", "DIGITAL"], weights=[45, 30, 25])[0],
        })
    return people


def make_claim_for(person, idx, rng):
    """One State Pension claim for a person."""
    # State Pension age is 66. The claim starts on the 66th birthday exactly,
    # so a test can safely assert "nobody claimed before turning 66".
    start_age = 66
    dob = person["dob"]
    try:
        start = date(dob.year + start_age, dob.month, dob.day)
    except ValueError:          # born 29 February
        start = date(dob.year + start_age, 3, 1)
    if start > REFERENCE_DATE:
        start = REFERENCE_DATE - timedelta(days=rng.randint(30, 400))
    qual = rng.randint(10, 35)
    if qual >= 35:
        weekly = 221.20
    else:
        weekly = round(221.20 * qual / 35.0, 2)
    if rng.random() < 0.35:
        weekly = round(weekly * rng.uniform(0.75, 1.18), 2)
    weekly = max(20.0, min(weekly, 295.0))

    if person["dod"] is not None:
        status = "CLOSED"
    else:
        status = rng.choices(["ACTIVE", "SUSPENDED", "CLOSED"], weights=[88, 6, 6])[0]

    return {
        "claim_ref": "SP%07d" % (3200000 + idx),
        "nino": person["nino"],
        "claim_status": status,
        "pension_type": ("NEW_STATE_PENSION" if start >= date(2016, 4, 6)
                         else "BASIC_STATE_PENSION"),
        "claim_start_date": start,
        "qualifying_years": qual,
        "weekly_amount": round(weekly, 2),
        "deferral_indicator": rng.random() < 0.12,
        "payment_frequency": rng.choices(["WEEKLY", "FOUR_WEEKLY", "QUARTERLY"],
                                         weights=[30, 60, 10])[0],
    }


def make_payments_for(claim, start_idx, rng, n_min=5, n_max=9):
    """A run of payments against one claim, ending before the reference date."""
    freq_days = {"WEEKLY": 7, "FOUR_WEEKLY": 28, "QUARTERLY": 91}[claim["payment_frequency"]]
    per = {"WEEKLY": 1, "FOUR_WEEKLY": 4, "QUARTERLY": 13}[claim["payment_frequency"]]
    amount = round(float(claim["weekly_amount"]) * per, 2)

    n = rng.randint(n_min, n_max)
    pays = []
    d = REFERENCE_DATE - timedelta(days=freq_days * n + rng.randint(0, 6))
    for k in range(n):
        d = d + timedelta(days=freq_days)
        if d >= REFERENCE_DATE:
            break
        pays.append({
            "payment_id": "PAY%08d" % (start_idx + k),
            "claim_ref": claim["claim_ref"],
            "payment_date": d,
            "amount": amount,
            "payment_method": rng.choices(["BACS", "CHEQUE", "POST_OFFICE"],
                                          weights=[80, 6, 14])[0],
            "payment_status": "SETTLED",
        })
    return pays


def make_address_for(person, idx, rng, older=False):
    town, county, area, region = person["place"]
    vf = REFERENCE_DATE - timedelta(days=rng.randint(400, 9000))
    if older:
        vf = vf - timedelta(days=rng.randint(2000, 8000))
    return {
        "address_id": "ADR%07d" % idx,
        "nino": person["nino"],
        "line_1": "%d %s" % (rng.randint(1, 180), rng.choice(STREETS)),
        "line_2": (rng.choice(["Flat A", "Apartment 3", "The Annexe", None, None, None])),
        "town": town,
        "county": county,
        "postcode": make_postcode(area, rng),
        "valid_from": vf,
        "valid_to": None,
        "is_current": True,
    }


# ==========================================================================
# TEAM 1 - The Duplicate Claimants
# ==========================================================================
NINO_STYLES = ["plain", "lower", "spaced", "dashed", "padded", "mixed"]


def write_nino(n, style):
    a, b, c = n[:2], n[2:8], n[8]
    if style == "plain":
        return n
    if style == "lower":
        return n.lower()
    if style == "spaced":
        return "%s %s %s %s %s" % (a, b[0:2], b[2:4], b[4:6], c)
    if style == "dashed":
        return "%s-%s-%s-%s-%s" % (a, b[0:2], b[2:4], b[4:6], c)
    if style == "padded":
        return "  %s  " % n
    if style == "mixed":
        return a[0] + a[1].lower() + b + c.lower()
    return n


def email_variant(p, k):
    """The same person, reached at a different address on each system."""
    f = p["first_name"].lower()
    l = p["last_name"].lower()
    n = int(p["nino"][2:8]) % 1000
    return [
        "%s.%s%d@oldmail.invalid" % (f, l, n),
        "%s.%s%d@example.invalid" % (f[0], l, n),
        "%s%d@webmail.invalid" % (f, n),
    ][k % 3]


def phone_variant(p, k):
    base = p["phone"].replace(" ", "")
    return "0%s %s" % (base[1:5], base[5:]) if k % 2 else "%s %s" % (base[:5], base[5:])


MESSY_TITLES = {"Mr": ["Mr", "MR", "mr", "Mr.", "MR."],
                "Mrs": ["Mrs", "MRS", "mrs", "Mrs."],
                "Ms": ["Ms", "MS", "ms", "Ms."],
                "Miss": ["Miss", "MISS", "miss"]}


def build_team1(rng):
    people = make_people(rng, N_PEOPLE, "QQ")
    rows, exp = [], {}
    rid = 0
    base_ts = date(2025, 1, 5)

    dup_people = rng.sample(people, 250)
    dup_extra = {p["nino"]: (1 if i < 200 else 2) for i, p in enumerate(dup_people)}

    winners = {}
    for p in people:
        n_records = 1 + dup_extra.get(p["nino"], 0)
        # Unique, ordered ingest timestamps so "newest wins" is unambiguous.
        offsets = rng.sample(range(0, 420), n_records)
        offsets.sort()
        recs = []
        for k in range(n_records):
            rid += 1
            ts = base_ts + timedelta(days=offsets[k], hours=rng.randint(0, 23))
            source = rng.choice(["CIS", "LEGACY_CSV", "DIGITAL"]) if k else p["source"]
            style = "plain" if (k == 0 and rng.random() < 0.4) else rng.choice(NINO_STYLES)

            # Each record carries a DIFFERENT contact address - an old work
            # one, a newer personal one, and so on. That is what makes
            # "which record wins?" a real question rather than a formality.
            email = junk_null(rng, email_variant(p, k), 0.22 if k else 0.10)
            phone = junk_null(rng, phone_variant(p, k), 0.20)
            marital = junk_null(rng, p["marital_status"], 0.14)

            recs.append({
                "record_id": "REC%07d" % rid,
                "nino": write_nino(p["nino"], style),
                "title": rng.choice(MESSY_TITLES[p["title"]]),
                "first_name": messy_ws(p["first_name"], rng),
                "last_name": messy_ws(p["last_name"], rng),
                "date_of_birth": iso(p["dob"]),
                "sex": p["sex"],
                "marital_status": marital,
                "date_of_death": iso(p["dod"]),
                "email": email,
                "phone": phone,
                "source_system": source,
                "ingested_at": ts.strftime("%Y-%m-%d %H:%M:%S"),
                "_email_real": email,
            })
        winners[p["nino"]] = recs[-1]     # latest ingested_at
        rows.extend(recs)

    rng.shuffle(rows)

    JUNK = {"", "N/A", "UNKNOWN", "NULL", "n/a", "-"}

    def tidy(v):
        if v is None:
            return None
        v = v.strip()
        return None if v in JUNK else v

    # Anchors: people who genuinely appear several times, whose winning
    # record has a usable email. Picking any other record gives a different
    # answer, so these tests really do prove the survivorship rule.
    anchors = []
    for p in sorted(dup_people, key=lambda x: -dup_extra[x["nino"]]):
        w = winners[p["nino"]]
        if tidy(w["_email_real"]):
            anchors.append((p["nino"], tidy(w["_email_real"]),
                            p["first_name"], 1 + dup_extra[p["nino"]]))
        if len(anchors) == 2:
            break
    anchor = anchors[0]

    emails_null = sum(1 for p in people if tidy(winners[p["nino"]]["_email_real"]) is None)
    # Bonus: best-available email across all of a person's records.
    best_null = 0
    by_nino = {}
    for r in rows:
        by_nino.setdefault(r["nino"].strip().upper().replace(" ", "").replace("-", ""), []).append(r)
    for n, rs in by_nino.items():
        if not any(tidy(r["_email_real"]) for r in rs):
            best_null += 1

    for r in rows:
        r.pop("_email_real", None)

    addrs, claims, pays = [], [], []
    pid = 1
    for i, p in enumerate(people):
        addrs.append(make_address_for(p, i + 1, rng))
        c = make_claim_for(p, i + 1, rng)
        claims.append(c)
        ps = make_payments_for(c, pid, rng)
        pid += len(ps) + 2
        pays.extend(ps)

    exp = {
        "clean_claimant_count": len(people),
        "raw_claimant_rows": len(rows),
        "anchor_nino": anchor[0],
        "anchor_email": anchor[1],
        "anchor_first_name": anchor[2],
        "anchor_records": anchor[3],
        "anchor2_nino": anchors[1][0],
        "anchor2_email": anchors[1][1],
        "anchor2_records": anchors[1][3],
        "emails_null_after_dedup": emails_null,
        "emails_null_best_available": best_null,
    }
    return rows, addrs, claims, pays, exp


# ==========================================================================
# TEAM 2 - The Date Disaster
# ==========================================================================
STYLE_BY_SOURCE = {"CIS": "iso", "LEGACY_CSV": "uk_slash", "DIGITAL": "mon"}


def build_team2(rng):
    people = make_people(rng, N_PEOPLE, "QQ")

    # Disjoint groups of broken dates, so the expected counts are unambiguous.
    idx = list(range(len(people)))
    rng.shuffle(idx)
    sentinel_old = set(idx[0:22])        # parses to 1900-01-01
    sentinel_future = set(idx[22:44])    # parses to 9999-12-31
    future_dob = set(idx[44:66])         # a real but impossible date
    unparseable = set(idx[66:84])        # '', 'N/A', 'UNKNOWN'
    death_before_birth = set(idx[84:106])
    future_death = set(idx[106:124])     # died in 2029. Also an error.
    excluded = sentinel_old | sentinel_future | future_dob | unparseable

    rows = []
    anchors = {}
    kept = []
    for i, p in enumerate(people):
        style = STYLE_BY_SOURCE[p["source"]]
        dob_txt = fmt_date(p["dob"], style)

        if i in sentinel_old:
            dob_txt = fmt_date(date(1900, 1, 1), style)
        elif i in sentinel_future:
            dob_txt = fmt_date(date(9999, 12, 31), style)
        elif i in future_dob:
            dob_txt = fmt_date(date(2031, 6, 12), style)
        elif i in unparseable:
            dob_txt = rng.choice(["", "N/A", "UNKNOWN", "NULL", "  "])

        dod = p["dod"]
        dod_txt = fmt_date(dod, style) if dod else rng.choice(["", None, "N/A", ""])
        if i in death_before_birth:
            dod = None      # must be discarded, not kept
            dod_txt = fmt_date(p["dob"] - timedelta(days=rng.randint(400, 6000)), style)
        elif i in future_death:
            dod = None      # nobody has died in 2029 yet
            dod_txt = fmt_date(date(2029, rng.randint(1, 12), rng.randint(1, 28)), style)

        rows.append({
            "record_id": "REC%07d" % (i + 1),
            "nino": p["nino"],
            "title": p["title"],
            "first_name": messy_ws(p["first_name"], rng),
            "last_name": messy_ws(p["last_name"], rng),
            "date_of_birth": dob_txt,
            "sex": p["sex"],
            "marital_status": junk_null(rng, p["marital_status"], 0.10),
            "date_of_death": dod_txt,
            "email": junk_null(rng, p["email"], 0.10),
            "phone": junk_null(rng, p["phone"], 0.10),
            "source_system": p["source"],
            "ingested_at": (date(2025, 6, 1) + timedelta(days=rng.randint(0, 300))).strftime("%Y-%m-%d %H:%M:%S"),
        })

        if i not in excluded:
            kept.append((p, None if (i in death_before_birth or i in future_death) else dod))
            if p["source"] == "LEGACY_CSV" and "uk" not in anchors and p["dob"].day <= 12 and p["dob"].month != p["dob"].day:
                anchors["uk"] = (p["nino"], iso(p["dob"]), fmt_date(p["dob"], "uk_slash"))
            if p["source"] == "DIGITAL" and "mon" not in anchors:
                anchors["mon"] = (p["nino"], iso(p["dob"]), fmt_date(p["dob"], "mon"))
            if p["source"] == "CIS" and "iso" not in anchors:
                anchors["iso"] = (p["nino"], iso(p["dob"]), fmt_date(p["dob"], "iso"))

    kept_people = [k[0] for k in kept]
    deceased = sum(1 for _p, d in kept if d is not None)
    dobs = sorted(p["dob"] for p in kept_people)

    # Claim start dates are written in the same three styles. This is the
    # bonus task: the same CASE pattern, applied to a second table.
    addrs, raw_claims, pays = [], [], []
    pid = 1
    claim_anchor = None
    for i, p in enumerate(kept_people):
        addrs.append(make_address_for(p, i + 1, rng))
        c = make_claim_for(p, i + 1, rng)
        style = STYLE_BY_SOURCE[p["source"]]
        raw_claims.append({
            "claim_ref": c["claim_ref"], "claimant_ref": c["nino"],
            "claim_status": c["claim_status"], "pension_type": c["pension_type"],
            "claim_start_date": fmt_date(c["claim_start_date"], style),
            "qualifying_years": str(c["qualifying_years"]),
            "weekly_amount": "%.2f" % c["weekly_amount"],
            "deferral_indicator": "Y" if c["deferral_indicator"] else "N",
            "deferral_weeks": "0",
            "payment_frequency": c["payment_frequency"],
            "last_updated": "2026-03-01",
        })
        if claim_anchor is None and p["source"] == "LEGACY_CSV" \
                and c["claim_start_date"].day <= 12 \
                and c["claim_start_date"].day != c["claim_start_date"].month:
            claim_anchor = (c["claim_ref"], iso(c["claim_start_date"]))
        ps = make_payments_for(c, pid, rng)
        pid += len(ps) + 2
        pays.extend(ps)
    claims = raw_claims

    exp = {
        "claim_count": len(raw_claims),
        "anchor_claim_ref": claim_anchor[0],
        "anchor_claim_start": claim_anchor[1],
        "future_death_count": len(future_death),
        "death_before_birth_count": len(death_before_birth),
        "clean_claimant_count": len(kept_people),
        "raw_claimant_rows": len(rows),
        "deceased_count": deceased,
        "oldest_dob": iso(dobs[0]),
        "youngest_dob": iso(dobs[-1]),
        "anchor_uk_nino": anchors["uk"][0], "anchor_uk_dob": anchors["uk"][1],
        "anchor_uk_raw": anchors["uk"][2],
        "anchor_mon_nino": anchors["mon"][0], "anchor_mon_dob": anchors["mon"][1],
        "anchor_mon_raw": anchors["mon"][2],
        "anchor_iso_nino": anchors["iso"][0], "anchor_iso_dob": anchors["iso"][1],
        "under_66_count": sum(1 for p in kept_people if age_on(p["dob"]) < 66),
        "excluded_count": len(excluded),
    }
    return rows, addrs, claims, pays, exp


# ==========================================================================
# TEAM 3 - The Address Mess
# ==========================================================================
def mess_postcode(pc, rng):
    style = rng.choices(["canon", "nospace", "lower", "double", "padded", "lowernospace"],
                        weights=[26, 20, 16, 12, 14, 12])[0]
    if style == "canon":
        return pc
    if style == "nospace":
        return pc.replace(" ", "")
    if style == "lower":
        return pc.lower()
    if style == "double":
        return pc.replace(" ", "  ")
    if style == "padded":
        return "  %s " % pc
    if style == "lowernospace":
        return pc.replace(" ", "").lower()
    return pc


BAD_POSTCODES = ["", "N/A", "UNKNOWN", "NULL", "12345", "SW1A", "ZZ99 9ZZZ",
                 "NOT KNOWN", "-", "TBC"]


def build_team3(rng):
    people = make_people(rng, N_PEOPLE, "QQ")

    rows = []
    for i, p in enumerate(people):
        rows.append({
            "record_id": "REC%07d" % (i + 1),
            "nino": p["nino"],
            "title": p["title"],
            "first_name": messy_ws(p["first_name"], rng),
            "last_name": messy_ws(p["last_name"], rng),
            "date_of_birth": iso(p["dob"]),
            "sex": p["sex"],
            "marital_status": junk_null(rng, p["marital_status"], 0.10),
            "date_of_death": iso(p["dod"]),
            "email": junk_null(rng, p["email"], 0.10),
            "phone": junk_null(rng, p["phone"], 0.10),
            "source_system": p["source"],
            "ingested_at": "2025-08-01 09:00:00",
        })

    # 200 people have moved: an older address plus a current one.
    movers = set(rng.sample(range(len(people)), 200))
    addrs = []
    aid = 0
    current_pc = {}
    for i, p in enumerate(people):
        town, county, area, region = p["place"]
        entries = []
        if i in movers:
            aid += 1
            old = make_address_for(p, aid, rng, older=True)
            old["valid_to"] = old["valid_from"] + timedelta(days=rng.randint(700, 4000))
            old["is_current"] = False
            entries.append(old)
        aid += 1
        cur = make_address_for(p, aid, rng)
        cur["valid_from"] = max(cur["valid_from"],
                                (entries[0]["valid_to"] + timedelta(days=1)) if entries else cur["valid_from"])
        entries.append(cur)
        current_pc[p["nino"]] = cur["postcode"]
        for e in entries:
            e["_keep"] = True
        rows_for_person = entries
        addrs.extend(rows_for_person)

    # Break things. Only ever break the OLD address of a mover, so nobody is
    # left with no valid address at all.
    old_rows = [a for a in addrs if a["is_current"] is False]
    rng.shuffle(old_rows)
    for a in old_rows[:38]:
        a["postcode"] = rng.choice(BAD_POSTCODES)
        a["_keep"] = False

    # Orphans: addresses for people who are not in the claimant table.
    n_orphans = 25
    for k in range(n_orphans):
        aid += 1
        town, county, area, region = rng.choice(PLACES)
        addrs.append({
            "address_id": "ADR%07d" % aid,
            "nino": "QQ%06d%s" % (rng.randint(900000, 999999), rng.choice("ABCD")),
            "line_1": "%d %s" % (rng.randint(1, 99), rng.choice(STREETS)),
            "line_2": None, "town": town, "county": county,
            "postcode": make_postcode(area, rng),
            "valid_from": REFERENCE_DATE - timedelta(days=rng.randint(500, 4000)),
            "valid_to": None, "is_current": True, "_keep": False,
        })

    expected_addresses = sum(1 for a in addrs if a["_keep"])

    # Now write them out messily. The is_current flag is deliberately
    # unreliable - the truth is in valid_from.
    TRUE_WORDS = ["Y", "y", "YES", "Yes", "1", "TRUE", "true", "T"]
    FALSE_WORDS = ["N", "n", "NO", "No", "0", "FALSE", "false", "F", ""]
    raw_addrs = []
    by_person = {}
    for a in addrs:
        by_person.setdefault(a["nino"], []).append(a)

    for n, group in by_person.items():
        # 30% of people have a misleading flag: both marked current, or neither.
        mode = rng.choices(["honest", "all_true", "all_false"], weights=[70, 18, 12])[0]
        for a in group:
            if mode == "all_true":
                flag = rng.choice(TRUE_WORDS)
            elif mode == "all_false":
                flag = rng.choice(FALSE_WORDS)
            else:
                flag = rng.choice(TRUE_WORDS if a["is_current"] else FALSE_WORDS)
            raw_addrs.append({
                "address_id": a["address_id"],
                "claimant_ref": a["nino"],
                "address_line_1": messy_ws(a["line_1"], rng),
                "address_line_2": a["line_2"],
                "town": messy_ws(a["town"], rng),
                "county": a["county"],
                "postcode": mess_postcode(a["postcode"], rng)
                            if a["postcode"] not in BAD_POSTCODES else a["postcode"],
                "valid_from": iso(a["valid_from"]),
                "valid_to": iso(a["valid_to"]),
                "is_current": flag,
            })
    rng.shuffle(raw_addrs)

    anchor_nino = people[7]["nino"]
    claims, pays = [], []
    pid = 1
    for i, p in enumerate(people):
        c = make_claim_for(p, i + 1, rng)
        claims.append(c)
        ps = make_payments_for(c, pid, rng)
        pid += len(ps) + 2
        pays.extend(ps)

    exp = {
        "clean_claimant_count": len(people),
        "clean_address_count": expected_addresses,
        "raw_address_rows": len(raw_addrs),
        "orphan_addresses": n_orphans,
        "bad_postcodes": 38,
        "anchor_nino": anchor_nino,
        "anchor_postcode": current_pc[anchor_nino],
        "people_with_address": len(people),
        "region_london": sum(1 for p in people if p["place"][3] == "London"),
        "region_north_west": sum(1 for p in people if p["place"][3] == "North West"),
        "regions_present": len({p["place"][3] for p in people}),
    }
    return rows, raw_addrs, claims, pays, exp


# ==========================================================================
# TEAM 4 - The Money Problem
# ==========================================================================
def mess_money(v, rng, allow_comma=True):
    """Write a number the way five different systems would write it."""
    s = "%.2f" % abs(v)
    if allow_comma and abs(v) >= 1000:
        whole, frac = s.split(".")
        s = "{:,}".format(int(whole)) + "." + frac
    style = rng.choices(["plain", "pound", "padded", "gbp", "poundpad"],
                        weights=[34, 30, 12, 10, 14])[0]
    if style == "pound":
        s = "£" + s
    elif style == "padded":
        s = "  " + s + " "
    elif style == "gbp":
        s = s + " GBP"
    elif style == "poundpad":
        s = " £" + s + "  "
    if v < 0:
        s = "(" + s.strip().lstrip("£") + ")"
        if style in ("pound", "poundpad"):
            s = "(£" + s[1:]
    return s


def build_team4(rng):
    people = make_people(rng, N_PEOPLE, "QQ")

    rows = []
    for i, p in enumerate(people):
        rows.append({
            "record_id": "REC%07d" % (i + 1), "nino": p["nino"], "title": p["title"],
            "first_name": messy_ws(p["first_name"], rng),
            "last_name": messy_ws(p["last_name"], rng),
            "date_of_birth": iso(p["dob"]), "sex": p["sex"],
            "marital_status": junk_null(rng, p["marital_status"], 0.10),
            "date_of_death": iso(p["dod"]),
            "email": junk_null(rng, p["email"], 0.10),
            "phone": junk_null(rng, p["phone"], 0.10),
            "source_system": p["source"], "ingested_at": "2025-08-01 09:00:00",
        })

    addrs = [make_address_for(p, i + 1, rng) for i, p in enumerate(people)]

    claims, pays = [], []
    pid = 1
    weekly_total = 0.0
    for i, p in enumerate(people):
        c = make_claim_for(p, i + 1, rng)
        claims.append(c)
        weekly_total += c["weekly_amount"]
        ps = make_payments_for(c, pid, rng)
        pid += len(ps) + 5
        pays.extend(ps)

    # -- Corrupt the payments ------------------------------------------------
    good = list(pays)

    # 1. Double postings: the same payment entered twice.
    n_dupes = 200
    dupe_sources = rng.sample(good, n_dupes)
    dupes = []
    for k, src in enumerate(dupe_sources):
        d = dict(src)
        d["payment_id"] = "PAY9%07d" % (100000 + k)
        dupes.append(d)

    # 2. Reversals: a genuine negative that cancels an earlier payment.
    #    Same claim, same date, same value, opposite sign. These are REAL
    #    and must survive de-duplication.
    n_rev = 120
    rev_sources = rng.sample([p for p in good if p not in dupe_sources], n_rev)
    reversals = []
    for k, src in enumerate(rev_sources):
        r = dict(src)
        r["payment_id"] = "PAY8%07d" % (200000 + k)
        r["amount"] = -src["amount"]
        r["payment_status"] = "REVERSED"
        reversals.append(r)

    # 3. Failed and pending payments, which must not reach the clean table.
    n_failed, n_pending = 260, 90
    others = []
    for k in range(n_failed + n_pending):
        src = rng.choice(good)
        o = dict(src)
        o["payment_id"] = "PAY7%07d" % (300000 + k)
        o["payment_status"] = "FAILED" if k < n_failed else "PENDING"
        o["payment_date"] = src["payment_date"] + timedelta(days=rng.randint(1, 20))
        others.append(o)

    all_pays = good + dupes + reversals + others
    rng.shuffle(all_pays)

    settled_total = sum(p["amount"] for p in good)
    reversal_total = sum(p["amount"] for p in reversals)
    expected_clean_payments = len(good) + len(reversals)

    raw_pays = []
    for p in all_pays:
        raw_pays.append({
            "payment_id": p["payment_id"],
            "claim_ref": p["claim_ref"],
            "payment_date": iso(p["payment_date"]),
            "amount": mess_money(p["amount"], rng),
            "payment_method": p["payment_method"],
            "payment_status": p["payment_status"],
            "created_at": iso(p["payment_date"] + timedelta(days=rng.randint(0, 3))),
        })

    raw_claims = []
    for c in claims:
        raw_claims.append({
            "claim_ref": c["claim_ref"], "claimant_ref": c["nino"],
            "claim_status": c["claim_status"], "pension_type": c["pension_type"],
            "claim_start_date": iso(c["claim_start_date"]),
            "qualifying_years": str(c["qualifying_years"]),
            "weekly_amount": mess_money(c["weekly_amount"], rng, allow_comma=False),
            "deferral_indicator": "Y" if c["deferral_indicator"] else "N",
            "deferral_weeks": "0",
            "payment_frequency": c["payment_frequency"],
            "last_updated": "2026-03-01",
        })

    claims_without_payment = len({c["claim_ref"] for c in claims}
                                 - {p["claim_ref"] for p in good})

    exp = {
        "clean_claimant_count": len(people),
        "clean_claim_count": len(claims),
        "weekly_amount_total": "%.2f" % round(weekly_total, 2),
        "clean_payment_count": expected_clean_payments,
        "settled_total": "%.2f" % round(settled_total, 2),
        "reversal_count": len(reversals),
        "reversal_total": "%.2f" % round(reversal_total, 2),
        "net_total": "%.2f" % round(settled_total + reversal_total, 2),
        "duplicate_payments": n_dupes,
        "failed_payments": n_failed,
        "pending_payments": n_pending,
        "claims_without_payment": claims_without_payment,
        "raw_payment_rows": len(raw_pays),
    }
    return rows, addrs, raw_claims, raw_pays, exp


# ==========================================================================
# TEAM 5 - The Code Chaos
# ==========================================================================
STATUS_WORDS = {
    "ACTIVE":    ["ACTIVE", "Active", "active", "A", "LIVE", "In Payment", "INPAY"],
    "SUSPENDED": ["Suspended", "SUSP", "S", "On Hold", "SUSPENDED"],
    "CLOSED":    ["Closed", "CLOSED", "C", "Ceased", "CEASED", "Terminated"],
}
PENSION_WORDS = {
    "NEW_STATE_PENSION":   ["New State Pension", "nSP", "NSP", "NEW", "Single Tier", "ST"],
    "BASIC_STATE_PENSION": ["Basic State Pension", "bSP", "BSP", "BASIC",
                            "Category A", "CAT A", "Category B", "CAT B"],
}
FREQ_WORDS = {
    "WEEKLY":      ["Weekly", "W", "WKLY", "1", "weekly"],
    "FOUR_WEEKLY": ["4-Weekly", "4W", "FOUR WEEKLY", "4", "Four Weekly", "4 WEEKLY"],
    "QUARTERLY":   ["Quarterly", "Q", "QTR", "13", "quarterly"],
}
TRUE_WORDS = ["Y", "y", "YES", "Yes", "TRUE", "T", "1"]
FALSE_WORDS = ["N", "n", "NO", "No", "FALSE", "F", "0", ""]
METHOD_WORDS = {
    "BACS":        ["BACS", "bacs", "Bank Transfer", "BANK TRANSFER", "Bank Tfr"],
    "CHEQUE":      ["Cheque", "CHQ", "cheque", "CHEQUE"],
    "POST_OFFICE": ["Post Office", "PO", "POST OFFICE", "Giro"],
}
# Deliberately NOT in ref.code_mapping - these must fall back to UNKNOWN.
UNMAPPED_METHODS = {"Bank Tfr", "Giro"}


def build_team5(rng):
    people = make_people(rng, N_PEOPLE, "QQ")

    rows = []
    for i, p in enumerate(people):
        rows.append({
            "record_id": "REC%07d" % (i + 1), "nino": p["nino"], "title": p["title"],
            "first_name": messy_ws(p["first_name"], rng),
            "last_name": messy_ws(p["last_name"], rng),
            "date_of_birth": iso(p["dob"]), "sex": p["sex"],
            "marital_status": junk_null(rng, p["marital_status"], 0.10),
            "date_of_death": iso(p["dod"]),
            "email": junk_null(rng, p["email"], 0.10),
            "phone": junk_null(rng, p["phone"], 0.10),
            "source_system": p["source"], "ingested_at": "2025-08-01 09:00:00",
        })

    addrs = [make_address_for(p, i + 1, rng) for i, p in enumerate(people)]

    claims, pays = [], []
    pid = 1
    for i, p in enumerate(people):
        c = make_claim_for(p, i + 1, rng)
        claims.append(c)
        ps = make_payments_for(c, pid, rng)
        pid += len(ps) + 2
        pays.extend(ps)

    status_counts = {"ACTIVE": 0, "SUSPENDED": 0, "CLOSED": 0}
    pension_counts = {"NEW_STATE_PENSION": 0, "BASIC_STATE_PENSION": 0}
    freq_counts = {"WEEKLY": 0, "FOUR_WEEKLY": 0, "QUARTERLY": 0}
    deferral_true = 0
    for c in claims:
        status_counts[c["claim_status"]] += 1
        pension_counts[c["pension_type"]] += 1
        freq_counts[c["payment_frequency"]] += 1
        if c["deferral_indicator"]:
            deferral_true += 1

    raw_claims = []
    for c in claims:
        raw_claims.append({
            "claim_ref": c["claim_ref"], "claimant_ref": c["nino"],
            "claim_status": rng.choice(STATUS_WORDS[c["claim_status"]]),
            "pension_type": rng.choice(PENSION_WORDS[c["pension_type"]]),
            "claim_start_date": iso(c["claim_start_date"]),
            "qualifying_years": str(c["qualifying_years"]),
            "weekly_amount": "%.2f" % c["weekly_amount"],
            "deferral_indicator": rng.choice(TRUE_WORDS if c["deferral_indicator"] else FALSE_WORDS),
            "deferral_weeks": "0",
            "payment_frequency": rng.choice(FREQ_WORDS[c["payment_frequency"]]),
            "last_updated": "2026-03-01",
        })

    # Orphan claims: point at people who are not in the claimant table.
    n_orphan_claims = 30
    for k in range(n_orphan_claims):
        raw_claims.append({
            "claim_ref": "SP9%06d" % (700000 + k),
            "claimant_ref": "QQ%06d%s" % (rng.randint(900000, 999999), rng.choice("ABCD")),
            "claim_status": rng.choice(STATUS_WORDS["ACTIVE"]),
            "pension_type": rng.choice(PENSION_WORDS["NEW_STATE_PENSION"]),
            "claim_start_date": "2021-05-04", "qualifying_years": "30",
            "weekly_amount": "190.00",
            "deferral_indicator": "N", "deferral_weeks": "0",
            "payment_frequency": "4-Weekly", "last_updated": "2026-03-01",
        })
    rng.shuffle(raw_claims)

    method_counts = {"BACS": 0, "CHEQUE": 0, "POST_OFFICE": 0, "UNKNOWN": 0}
    raw_pays = []
    for p in pays:
        word = rng.choice(METHOD_WORDS[p["payment_method"]])
        method_counts["UNKNOWN" if word in UNMAPPED_METHODS else p["payment_method"]] += 1
        raw_pays.append({
            "payment_id": p["payment_id"], "claim_ref": p["claim_ref"],
            "payment_date": iso(p["payment_date"]),
            "amount": "%.2f" % p["amount"],
            "payment_method": word,
            "payment_status": rng.choice(["SETTLED", "Settled", "SETTLED", "S"]),
            "created_at": iso(p["payment_date"]),
        })

    # Orphan payments: point at claims that do not exist.
    n_orphan_pays = 45
    for k in range(n_orphan_pays):
        raw_pays.append({
            "payment_id": "PAY9%07d" % (500000 + k),
            "claim_ref": "SP0%06d" % (999000 + k),
            "payment_date": "2026-01-14", "amount": "185.15",
            "payment_method": "BACS", "payment_status": "SETTLED",
            "created_at": "2026-01-14",
        })
    rng.shuffle(raw_pays)

    exp = {
        "clean_claimant_count": len(people),
        "clean_claim_count": len(claims),
        "orphan_claims": n_orphan_claims,
        "status_active": status_counts["ACTIVE"],
        "status_suspended": status_counts["SUSPENDED"],
        "status_closed": status_counts["CLOSED"],
        "pension_new": pension_counts["NEW_STATE_PENSION"],
        "pension_basic": pension_counts["BASIC_STATE_PENSION"],
        "freq_weekly": freq_counts["WEEKLY"],
        "freq_four_weekly": freq_counts["FOUR_WEEKLY"],
        "freq_quarterly": freq_counts["QUARTERLY"],
        "deferral_true": deferral_true,
        "clean_payment_count": len(pays),
        "orphan_payments": n_orphan_pays,
        "method_bacs": method_counts["BACS"],
        "method_cheque": method_counts["CHEQUE"],
        "method_post_office": method_counts["POST_OFFICE"],
        "method_unknown": method_counts["UNKNOWN"],
    }
    return rows, addrs, raw_claims, raw_pays, exp


# ==========================================================================
# Converting canonical rows into raw-table shape
# ==========================================================================
def to_raw_address(a, rng):
    return {
        "address_id": a["address_id"],
        "claimant_ref": a["nino"],
        "address_line_1": a["line_1"],
        "address_line_2": a["line_2"],
        "town": a["town"],
        "county": a["county"],
        "postcode": a["postcode"],
        "valid_from": iso(a["valid_from"]),
        "valid_to": iso(a["valid_to"]),
        "is_current": "Y" if a["is_current"] else "N",
    }


def to_raw_claim(c, rng):
    return {
        "claim_ref": c["claim_ref"],
        "claimant_ref": c["nino"],
        "claim_status": c["claim_status"],
        "pension_type": c["pension_type"],
        "claim_start_date": iso(c["claim_start_date"]),
        "qualifying_years": str(c["qualifying_years"]),
        "weekly_amount": "%.2f" % c["weekly_amount"],
        "deferral_indicator": "Y" if c["deferral_indicator"] else "N",
        "deferral_weeks": "0",
        "payment_frequency": c["payment_frequency"],
        "last_updated": "2026-03-01",
    }


def to_raw_payment(p, rng):
    return {
        "payment_id": p["payment_id"],
        "claim_ref": p["claim_ref"],
        "payment_date": iso(p["payment_date"]),
        "amount": "%.2f" % p["amount"],
        "payment_method": p["payment_method"],
        "payment_status": p["payment_status"],
        "created_at": iso(p["payment_date"]),
    }


RAW_CLAIMANT_COLS = ["record_id", "nino", "title", "first_name", "last_name",
                     "date_of_birth", "sex", "marital_status", "date_of_death",
                     "email", "phone", "source_system", "ingested_at"]
RAW_ADDRESS_COLS = ["address_id", "claimant_ref", "address_line_1", "address_line_2",
                    "town", "county", "postcode", "valid_from", "valid_to", "is_current"]
RAW_CLAIM_COLS = ["claim_ref", "claimant_ref", "claim_status", "pension_type",
                  "claim_start_date", "qualifying_years", "weekly_amount",
                  "deferral_indicator", "deferral_weeks", "payment_frequency",
                  "last_updated"]
RAW_PAYMENT_COLS = ["payment_id", "claim_ref", "payment_date", "amount",
                    "payment_method", "payment_status", "created_at"]


# ==========================================================================
# CHALLENGE 2 - the curated dataset
#
# Built cell by cell so that k-anonymity behaves predictably:
#   - with five age bands (..., 80-84, 85+) several groups have fewer
#     than 5 people, so the test FAILS
#   - merging the top two bands into 80+ makes every group >= 5, so it PASSES
# That is the lesson, and it has to be reliable.
# ==========================================================================
REGION_WEIGHTS = {
    "London": 175, "South East": 168, "North West": 158, "Scotland": 145,
    "East of England": 130, "West Midlands": 128, "South West": 122,
    "Yorkshire and The Humber": 122, "East Midlands": 108, "Wales": 88,
    "North East": 72, "Northern Ireland": 54,
}
BANDS4 = ["65-69", "70-74", "75-79", "80+"]
BAND_WEIGHTS = [0.32, 0.27, 0.22, 0.19]
BAND_AGES = {"65-69": (66, 69), "70-74": (70, 74), "75-79": (75, 79),
             "80-84": (80, 84), "85+": (85, 92)}


def plan_curated_cells(rng):
    """Decide how many people sit in each (region, sex, band) cell."""
    cells = {}
    for region, total in sorted(REGION_WEIGHTS.items()):
        for sex, share in (("M", 0.47), ("F", 0.53)):
            n = int(round(total * share))
            counts = [int(round(n * w)) for w in BAND_WEIGHTS]
            # Every cell must be empty or comfortably above the threshold,
            # so that the four-band view always passes.
            counts = [0 if c == 0 else max(c, 5) for c in counts]
            for band, c in zip(BANDS4, counts):
                if band != "80+":
                    cells[(region, sex, band)] = c

            b = counts[3]
            if b >= 6 and rng.random() < 0.62:
                e85 = rng.randint(1, 4)          # deliberately too small
                e80 = b - e85
            else:
                e85 = 0
                e80 = b
            cells[(region, sex, "80-84")] = e80
            cells[(region, sex, "85+")] = e85
    return cells


def build_curated(rng):
    cells = plan_curated_cells(rng)

    # Sanity: the five-band view must fail, the four-band view must pass.
    five_band_small = sum(1 for k, v in cells.items() if 0 < v < 5)
    four = {}
    for (region, sex, band), v in cells.items():
        b4 = "80+" if band in ("80-84", "85+") else band
        four[(region, sex, b4)] = four.get((region, sex, b4), 0) + v
    four_band_small = sum(1 for v in four.values() if 0 < v < 5)
    assert five_band_small >= 6, "need violations in the 5-band view, got %d" % five_band_small
    assert four_band_small == 0, "4-band view must be clean, got %d bad" % four_band_small

    people = []
    used = set()
    for (region, sex, band), n in sorted(cells.items()):
        lo, hi = BAND_AGES[band]
        for _ in range(n):
            while True:
                num = rng.randint(100000, 899999)
                if num not in used:
                    used.add(num)
                    break
            first = rng.choice(FIRST_M if sex == "M" else FIRST_F)
            last = rng.choice(LAST)
            age = rng.randint(lo, hi)
            dob = dob_for_age(age, rng)
            dod = None
            if rng.random() < 0.06:
                dod = REFERENCE_DATE - timedelta(days=rng.randint(30, 1200))
                if dod <= dob:
                    dod = None
            people.append({
                "nino": nino("ZZ", num, rng),
                "title": ("Mr" if sex == "M" else rng.choice(["Mrs", "Ms", "Miss"])),
                "first_name": first, "last_name": last, "dob": dob, "sex": sex,
                "marital_status": rng.choices(
                    ["Single", "Married", "Widowed", "Divorced", "Civil Partnership"],
                    weights=[18, 44, 22, 13, 3])[0],
                "dod": dod,
                "email": "%s.%s%d@example.invalid" % (first.lower(), last.lower(), num % 1000),
                "phone": "07%03d %06d" % (rng.randint(100, 999), rng.randint(0, 999999)),
                "place": rng.choice(PLACES_BY_REGION[region]),
                "source": "DIGITAL",
                "_region": region, "_band": band,
            })
    rng.shuffle(people)

    addresses, claims, payments = [], [], []
    pid = 1
    for i, p in enumerate(people):
        a = make_address_for(p, i + 1, rng)
        addresses.append(a)
        c = make_claim_for(p, i + 1, rng)
        claims.append(c)
        ps = make_payments_for(c, pid, rng, 6, 10)
        pid += len(ps) + 2
        payments.extend(ps)

    exp = {
        "claimant_count": len(people),
        "claim_count": len(claims),
        "payment_count": len(payments),
        "five_band_violations": five_band_small,
        "regions": len(REGION_WEIGHTS),
    }
    return people, addresses, claims, payments, exp


def emit_curated(people, addresses, claims, payments):
    parts = ["""-- ---------------------------------------------------------------------------
-- 05 - The curated dataset: your Challenge 2 input.
--
-- Identical for every team. These are NOT the same people as in the raw
-- tables - it is a separate population, already cleaned by someone else.
--
-- Generated data. Every person here is invented. The National Insurance
-- numbers all start ZZ, which is a prefix that is never issued in real life.
-- ---------------------------------------------------------------------------
"""]
    parts.append(copy_block(
        "curated.claimant",
        ["nino", "title", "first_name", "last_name", "date_of_birth", "sex",
         "marital_status", "date_of_death", "email", "phone"],
        [{"nino": p["nino"], "title": p["title"], "first_name": p["first_name"],
          "last_name": p["last_name"], "date_of_birth": iso(p["dob"]),
          "sex": p["sex"], "marital_status": p["marital_status"],
          "date_of_death": iso(p["dod"]), "email": p["email"], "phone": p["phone"]}
         for p in people]))

    parts.append(copy_block(
        "curated.address",
        ["address_id", "nino", "line_1", "line_2", "town", "county", "postcode",
         "valid_from", "valid_to", "is_current"],
        [{"address_id": a["address_id"], "nino": a["nino"], "line_1": a["line_1"],
          "line_2": a["line_2"], "town": a["town"], "county": a["county"],
          "postcode": a["postcode"], "valid_from": iso(a["valid_from"]),
          "valid_to": iso(a["valid_to"]), "is_current": "t"}
         for a in addresses]))

    parts.append(copy_block(
        "curated.claim",
        ["claim_ref", "nino", "claim_status", "pension_type", "claim_start_date",
         "qualifying_years", "weekly_amount", "deferral_indicator", "payment_frequency"],
        [{"claim_ref": c["claim_ref"], "nino": c["nino"],
          "claim_status": c["claim_status"], "pension_type": c["pension_type"],
          "claim_start_date": iso(c["claim_start_date"]),
          "qualifying_years": c["qualifying_years"],
          "weekly_amount": "%.2f" % c["weekly_amount"],
          "deferral_indicator": "t" if c["deferral_indicator"] else "f",
          "payment_frequency": c["payment_frequency"]}
         for c in claims]))

    parts.append(copy_block(
        "curated.payment",
        ["payment_id", "claim_ref", "payment_date", "amount", "payment_method",
         "payment_status"],
        [{"payment_id": p["payment_id"], "claim_ref": p["claim_ref"],
          "payment_date": iso(p["payment_date"]), "amount": "%.2f" % p["amount"],
          "payment_method": p["payment_method"], "payment_status": p["payment_status"]}
         for p in payments]))

    return "\n".join(parts)


# ==========================================================================
# Reference data
# ==========================================================================
def emit_reference():
    lines = ["""-- ---------------------------------------------------------------------------
-- 02 - Reference data: small lookup tables you CAN trust.
--
-- Not everything in a data warehouse is a mess. These two tables are clean,
-- maintained by someone else, and safe to join to.
-- ---------------------------------------------------------------------------

CREATE TABLE ref.postcode_area (
    area_code TEXT PRIMARY KEY,
    region    TEXT NOT NULL
);

COMMENT ON TABLE ref.postcode_area IS
'Maps the letters at the start of a postcode to a UK region. SW -> London.';
""",
             "INSERT INTO ref.postcode_area (area_code, region) VALUES"]
    seen = sorted(AREA_TO_REGION.items())
    vals = [("('%s', '%s')" % (a, r.replace("'", "''"))) for a, r in seen]
    lines.append(",\n".join(vals) + ";")

    lines.append("""

CREATE TABLE ref.code_mapping (
    domain         TEXT NOT NULL,
    raw_value      TEXT NOT NULL,
    standard_value TEXT NOT NULL,
    PRIMARY KEY (domain, raw_value)
);

COMMENT ON TABLE ref.code_mapping IS
'Maps messy source values onto standard codes. WARNING: it is INCOMPLETE. The team that maintains it has not kept up with every spelling the source systems use. Anything missing from here is your problem to handle.';
""")
    lines.append("INSERT INTO ref.code_mapping (domain, raw_value, standard_value) VALUES")
    rows = []
    for std, words in sorted(METHOD_WORDS.items()):
        for wd in words:
            if wd in UNMAPPED_METHODS:
                continue          # deliberate gap
            rows.append("('payment_method', '%s', '%s')" % (wd.replace("'", "''"), std))
    lines.append(",\n".join(rows) + ";")
    lines.append("")
    return "\n".join(lines)


# ==========================================================================
# Main
# ==========================================================================
BUILDERS = {1: build_team1, 2: build_team2, 3: build_team3,
            4: build_team4, 5: build_team5}

TEAM_TITLES = {
    1: "The Duplicate Claimants",
    2: "The Date Disaster",
    3: "The Address Mess",
    4: "The Money Problem",
    5: "The Code Chaos",
}


def main():
    print("Generating hackathon datasets")
    print("=" * 62)
    manifest = {"reference_date": iso(REFERENCE_DATE), "teams": {}}

    for team in (1, 2, 3, 4, 5):
        rng = random.Random(40000 + team * 7919)
        claimants, addrs, claims, pays, exp = BUILDERS[team](rng)

        if addrs and "claimant_ref" not in addrs[0]:
            addrs = [to_raw_address(a, rng) for a in addrs]
        if claims and "claimant_ref" not in claims[0]:
            claims = [to_raw_claim(c, rng) for c in claims]
        if pays and "created_at" not in pays[0]:
            pays = [to_raw_payment(p, rng) for p in pays]

        header = """-- ---------------------------------------------------------------------------
-- Challenge 1 dataset for TEAM %d - "%s"
--
-- Loaded automatically into the raw schema when your database first starts.
--
-- Every person in here is invented. All National Insurance numbers begin
-- QQ, a prefix that is never issued in real life. No real government data is used.
-- ---------------------------------------------------------------------------
""" % (team, TEAM_TITLES[team])

        body = "\n".join([
            header,
            copy_block("raw.claimant", RAW_CLAIMANT_COLS, claimants),
            copy_block("raw.address", RAW_ADDRESS_COLS, addrs),
            copy_block("raw.claim", RAW_CLAIM_COLS, claims),
            copy_block("raw.payment", RAW_PAYMENT_COLS, pays),
        ])
        write("data/team%d.sql" % team, body)

        exp["title"] = TEAM_TITLES[team]
        exp["raw_claimant_rows"] = exp.get("raw_claimant_rows", len(claimants))
        exp["raw_address_rows"] = exp.get("raw_address_rows", len(addrs))
        exp["raw_claim_rows"] = len(claims)
        exp["raw_payment_rows"] = len(pays)
        manifest["teams"][str(team)] = exp
        print("    team %d: %5d claimant / %5d address / %5d claim / %6d payment rows"
              % (team, len(claimants), len(addrs), len(claims), len(pays)))

    write("initdb/02_reference_data.sql", emit_reference())

    rng = random.Random(987654321)
    people, addresses, claims, payments, cexp = build_curated(rng)
    write("initdb/05_curated_data.sql", emit_curated(people, addresses, claims, payments))
    manifest["curated"] = cexp
    print("    curated: %5d people / %5d claims / %6d payments (%d groups too small at 5 bands)"
          % (cexp["claimant_count"], cexp["claim_count"], cexp["payment_count"],
             cexp["five_band_violations"]))

    write("_organiser/generator/manifest.json",
          json.dumps(manifest, indent=2, sort_keys=True) + "\n")

    print("=" * 62)
    print("Done.")


if __name__ == "__main__":
    main()
