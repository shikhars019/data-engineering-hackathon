#!/usr/bin/env python3
"""
Sanity-check the generated data files against the manifest, without needing
a database. Catches generator mistakes early.

Run:  python _organiser/generator/verify_data.py
"""
import io
import json
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
MANIFEST = json.load(io.open(os.path.join(ROOT, "_organiser/generator/manifest.json"),
                             encoding="utf-8"))

NINO_RE = re.compile(r"^[A-Z]{2}[0-9]{6}[A-Z]$")
PC_RE = re.compile(r"^[A-Z]{1,2}[0-9][A-Z0-9]? [0-9][A-Z]{2}$")

problems = []


def fail(msg):
    problems.append(msg)
    print("  FAIL  " + msg)


def ok(msg):
    print("  ok    " + msg)


def parse_copy_blocks(path):
    """Return {table: (cols, [rows...])} from a file of COPY ... FROM stdin."""
    out = {}
    with io.open(path, encoding="utf-8") as f:
        lines = f.read().split("\n")
    i = 0
    while i < len(lines):
        line = lines[i]
        m = re.match(r"^COPY ([\w.]+) \(([^)]*)\) FROM stdin;$", line)
        if m:
            table = m.group(1)
            cols = [c.strip() for c in m.group(2).split(",")]
            rows = []
            i += 1
            while i < len(lines) and lines[i] != "\\.":
                vals = lines[i].split("\t")
                rows.append(dict(zip(cols, vals)))
                i += 1
            out[table] = (cols, rows)
        i += 1
    return out


def unesc(v):
    return None if v == "\\N" else v


def norm_nino(s):
    return (s or "").strip().upper().replace(" ", "").replace("-", "")


print("Verifying generated data")
print("=" * 62)

# ---------------------------------------------------------------- per team
for team in "12345":
    exp = MANIFEST["teams"][team]
    path = os.path.join(ROOT, "data", "team%s.sql" % team)
    blocks = parse_copy_blocks(path)
    print("\nTeam %s - %s" % (team, exp["title"]))

    for t in ("raw.claimant", "raw.address", "raw.claim", "raw.payment"):
        if t not in blocks:
            fail("team %s: missing %s" % (team, t))
    if problems:
        continue

    claimants = blocks["raw.claimant"][1]
    addrs = blocks["raw.address"][1]
    claims = blocks["raw.claim"][1]
    pays = blocks["raw.payment"][1]

    if len(claimants) != exp["raw_claimant_rows"]:
        fail("team %s: claimant rows %d != manifest %d"
             % (team, len(claimants), exp["raw_claimant_rows"]))
    else:
        ok("row counts match the manifest")

    # No literal tabs / stray columns
    ncols = len(blocks["raw.claimant"][0])
    bad = [r for r in claimants if len(r) != ncols]
    if bad:
        fail("team %s: %d claimant rows have the wrong column count" % (team, len(bad)))

    # record_id unique
    rids = [r["record_id"] for r in claimants]
    if len(set(rids)) != len(rids):
        fail("team %s: duplicate record_id values" % team)

    # every NINO normalises to a valid one
    bad_nino = [r for r in claimants if not NINO_RE.match(norm_nino(r["nino"]))]
    if bad_nino:
        fail("team %s: %d NINOs do not normalise to a valid format (e.g. %r)"
             % (team, len(bad_nino), bad_nino[0]["nino"]))
    else:
        ok("all NINOs normalise to a valid format")

    people = {norm_nino(r["nino"]) for r in claimants}

    # Claims must reference real people, except where orphans are intended
    orphan_claims = {c["claim_ref"] for c in claims
                     if norm_nino(c["claimant_ref"]) not in people}
    expected_orphan_claims = exp.get("orphan_claims", 0)
    if len(orphan_claims) != expected_orphan_claims:
        fail("team %s: %d orphan claims, expected %d"
             % (team, len(orphan_claims), expected_orphan_claims))
    else:
        ok("orphan claims: %d (as intended)" % len(orphan_claims))

    claim_refs = {c["claim_ref"] for c in claims}
    orphan_pays = [p for p in pays if p["claim_ref"] not in claim_refs]
    expected_orphan_pays = exp.get("orphan_payments", 0)
    if len(orphan_pays) != expected_orphan_pays:
        fail("team %s: %d orphan payments, expected %d"
             % (team, len(orphan_pays), expected_orphan_pays))
    else:
        ok("orphan payments: %d (as intended)" % len(orphan_pays))

    orphan_addrs = [a for a in addrs if norm_nino(a["claimant_ref"]) not in people]
    expected_orphan_addrs = exp.get("orphan_addresses", 0)
    if len(orphan_addrs) != expected_orphan_addrs:
        fail("team %s: %d orphan addresses, expected %d"
             % (team, len(orphan_addrs), expected_orphan_addrs))

    # Distinct people
    if team == "1":
        if len(people) != exp["clean_claimant_count"]:
            fail("team 1: %d distinct people, manifest says %d"
                 % (len(people), exp["clean_claimant_count"]))
        else:
            ok("%d raw records resolve to %d distinct people"
               % (len(claimants), len(people)))
        # the anchor must really be ambiguous
        a = exp["anchor_nino"]
        recs = [r for r in claimants if norm_nino(r["nino"]) == a]
        emails = {unesc(r["email"]) for r in recs}
        if len(recs) < 2:
            fail("team 1: anchor %s has only %d record(s)" % (a, len(recs)))
        elif len(emails) < 2:
            fail("team 1: anchor %s has the same email on every record - "
                 "the survivorship test would pass by accident" % a)
        else:
            newest = max(recs, key=lambda r: r["ingested_at"])
            if unesc(newest["email"]) != exp["anchor_email"]:
                fail("team 1: anchor newest email %r != manifest %r"
                     % (unesc(newest["email"]), exp["anchor_email"]))
            else:
                ok("anchor %s: %d records, %d different emails, newest wins"
                   % (a, len(recs), len(emails)))
    else:
        if len(people) != len(claimants):
            fail("team %s: should have no duplicate people, found %d dupes"
                 % (team, len(claimants) - len(people)))
        else:
            ok("no duplicate people (that is team 1's job, not this team's)")

# ------------------------------------------------------------- team 3 extra
exp3 = MANIFEST["teams"]["3"]
b3 = parse_copy_blocks(os.path.join(ROOT, "data", "team3.sql"))
addrs3 = b3["raw.address"][1]
people3 = {norm_nino(r["nino"]) for r in b3["raw.claimant"][1]}
print("\nTeam 3 - postcode detail")


def canon_pc(s):
    s = (s or "").upper().replace(" ", "")
    return s[:-3] + " " + s[-3:] if len(s) >= 5 else s


valid = [a for a in addrs3
         if norm_nino(a["claimant_ref"]) in people3 and PC_RE.match(canon_pc(unesc(a["postcode"]) or ""))]
if len(valid) != exp3["clean_address_count"]:
    fail("team 3: %d addresses survive cleaning, manifest says %d"
         % (len(valid), exp3["clean_address_count"]))
else:
    ok("%d of %d addresses survive cleaning" % (len(valid), len(addrs3)))

# everyone must keep at least one address
with_addr = {norm_nino(a["claimant_ref"]) for a in valid}
missing = people3 - with_addr
if missing:
    fail("team 3: %d people would be left with NO valid address" % len(missing))
else:
    ok("every person still has at least one valid address")

# ------------------------------------------------------------- team 4 extra
exp4 = MANIFEST["teams"]["4"]
b4 = parse_copy_blocks(os.path.join(ROOT, "data", "team4.sql"))
pays4 = b4["raw.payment"][1]
print("\nTeam 4 - money detail")


def parse_money(s):
    s = (s or "").strip()
    neg = s.startswith("(") or s.endswith(")")
    s = s.replace("(", "").replace(")", "").replace("£", "")
    s = s.replace(",", "").replace(" GBP", "").strip()
    try:
        v = float(s)
    except ValueError:
        return None
    return -v if neg else v


unparseable = [p for p in pays4 if parse_money(p["amount"]) is None]
if unparseable:
    fail("team 4: %d payment amounts cannot be parsed (e.g. %r)"
         % (len(unparseable), unparseable[0]["amount"]))
else:
    ok("every payment amount is parseable")

keep = [p for p in pays4 if p["payment_status"] in ("SETTLED", "REVERSED")]
seen, deduped = set(), []
for p in keep:
    k = (p["claim_ref"], p["payment_date"], "%.2f" % parse_money(p["amount"]))
    if k in seen:
        continue
    seen.add(k)
    deduped.append(p)
if len(deduped) != exp4["clean_payment_count"]:
    fail("team 4: dedup gives %d payments, manifest says %d"
         % (len(deduped), exp4["clean_payment_count"]))
else:
    ok("filter + dedup gives exactly %d payments" % len(deduped))

negatives = [p for p in deduped if parse_money(p["amount"]) < 0]
if len(negatives) != exp4["reversal_count"]:
    fail("team 4: %d reversals survive, manifest says %d"
         % (len(negatives), exp4["reversal_count"]))
else:
    ok("%d reversals survive de-duplication" % len(negatives))

total = sum(parse_money(p["amount"]) for p in deduped if parse_money(p["amount"]) > 0)
if abs(total - float(exp4["settled_total"])) > 0.01:
    fail("team 4: settled total %.2f != manifest %s" % (total, exp4["settled_total"]))
else:
    ok("settled total reconciles to %s" % exp4["settled_total"])

# --------------------------------------------------------------- curated
print("\nCurated dataset (Challenge 2)")
bc = parse_copy_blocks(os.path.join(ROOT, "initdb", "05_curated_data.sql"))
cc = bc["curated.claimant"][1]
ca = bc["curated.address"][1]
expc = MANIFEST["curated"]
if len(cc) != expc["claimant_count"]:
    fail("curated: %d claimants, manifest says %d" % (len(cc), expc["claimant_count"]))
else:
    ok("%d claimants" % len(cc))

ninos = {r["nino"] for r in cc}
if len(ninos) != len(cc):
    fail("curated: duplicate NINOs")
if any(not n.startswith("ZZ") for n in ninos):
    fail("curated: some NINOs do not use the ZZ prefix")
else:
    ok("all curated NINOs use the never-issued ZZ prefix")

# Challenge 1 and Challenge 2 must not share people
for team in "12345":
    bt = parse_copy_blocks(os.path.join(ROOT, "data", "team%s.sql" % team))
    tn = {norm_nino(r["nino"]) for r in bt["raw.claimant"][1]}
    if tn & ninos:
        fail("team %s shares %d people with the curated dataset" % (team, len(tn & ninos)))
ok("no overlap between any team's data and the curated dataset")

# k-anonymity behaviour
AREA = {}
for line in io.open(os.path.join(ROOT, "initdb", "02_reference_data.sql"), encoding="utf-8"):
    m = re.match(r"^\('([A-Z]{1,2})', '(.+)'\),?$", line.strip())
    if m:
        AREA[m.group(1)] = m.group(2)

addr_by_nino = {a["nino"]: a for a in ca}
REF = MANIFEST["reference_date"]


def age_of(dob):
    y, m, d = (int(x) for x in dob.split("-"))
    ry, rm, rd = (int(x) for x in REF.split("-"))
    a = ry - y
    if (rm, rd) < (m, d):
        a -= 1
    return a


def band5(a):
    if a < 70: return "65-69"
    if a < 75: return "70-74"
    if a < 80: return "75-79"
    if a < 85: return "80-84"
    return "85+"


def band4(a):
    return "80+" if a >= 80 else band5(a)


def groups(bander):
    g = {}
    for r in cc:
        a = addr_by_nino.get(r["nino"])
        if not a:
            continue
        area = re.match(r"^[A-Z]{1,2}", a["postcode"]).group(0)
        key = (bander(age_of(r["date_of_birth"])), r["sex"], AREA.get(area, "?"))
        g[key] = g.get(key, 0) + 1
    return g


g5 = groups(band5)
g4 = groups(band4)
small5 = {k: v for k, v in g5.items() if v < 5}
small4 = {k: v for k, v in g4.items() if v < 5}

if not small5:
    fail("curated: five age bands produce NO small groups - the k-anonymity "
         "exercise would pass without any work")
else:
    ok("five age bands leave %d groups below 5 (the exercise has something to fix)"
       % len(small5))

if small4:
    fail("curated: merging to 80+ still leaves %d small groups %s - the "
         "intended fix would not work" % (len(small4), list(small4.items())[:3]))
else:
    ok("merging the top bands into 80+ fixes every group (the intended fix works)")

print("\n" + "=" * 62)
if problems:
    print("%d PROBLEM(S) FOUND" % len(problems))
    sys.exit(1)
print("All checks passed.")
