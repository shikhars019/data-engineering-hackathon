-- ===========================================================================
-- REFERENCE SOLUTION - Challenge 2 - Safe Data for Analysts  (ORGANISER ONLY)
-- Passes all 11 core and all 3 bonus tests. Re-runnable.
-- ===========================================================================

DROP TABLE IF EXISTS analytics.agg_claims_by_region;
DROP TABLE IF EXISTS analytics.fct_claim_anon;
DROP TABLE IF EXISTS analytics.dim_claimant_anon;

-- Task 1 ---------------------------------------------------------------
CREATE TABLE analytics.dim_claimant_anon (
    person_pseudo_id  TEXT PRIMARY KEY,
    age_band          TEXT,
    sex               TEXT,
    region            TEXT,
    marital_status    TEXT,
    is_deceased       BOOLEAN
);

CREATE TABLE analytics.fct_claim_anon (
    claim_pseudo_id     TEXT PRIMARY KEY,
    person_pseudo_id    TEXT,
    claim_year_month    TEXT,
    claim_status        TEXT,
    pension_type        TEXT,
    weekly_amount_band  TEXT,
    payment_frequency   TEXT
);

-- Tasks 2 to 5, and 7 --------------------------------------------------
INSERT INTO analytics.dim_claimant_anon
SELECT
    -- Task 2: salted. md5(nino) on its own could be cracked in seconds.
    md5((SELECT value FROM meta.etl_config
         WHERE setting = 'pseudonymisation_salt') || c.nino),

    -- Tasks 3 and 7: four bands, not five. Five leaves groups of 85+ that
    -- are too small to publish, so the top two are merged.
    CASE
        WHEN date_part('year', age(DATE '2026-04-06', c.date_of_birth)) < 70 THEN '65-69'
        WHEN date_part('year', age(DATE '2026-04-06', c.date_of_birth)) < 75 THEN '70-74'
        WHEN date_part('year', age(DATE '2026-04-06', c.date_of_birth)) < 80 THEN '75-79'
        ELSE '80+'
    END,

    c.sex,

    -- Task 4: the region, never the postcode
    r.region,

    c.marital_status,
    (c.date_of_death IS NOT NULL)

-- Task 5: name, NINO, email, phone, address and exact date of birth are
-- simply not selected. That is the whole of the suppression step.
FROM curated.claimant c
JOIN curated.address a
  ON a.nino = c.nino AND a.is_current
LEFT JOIN ref.postcode_area r
  ON r.area_code = substring(a.postcode from '^[A-Z]{1,2}');

-- Task 6 ---------------------------------------------------------------
INSERT INTO analytics.fct_claim_anon
SELECT
    md5((SELECT value FROM meta.etl_config
         WHERE setting = 'pseudonymisation_salt') || cl.claim_ref),
    -- the SAME recipe as the dimension, so the join still works
    md5((SELECT value FROM meta.etl_config
         WHERE setting = 'pseudonymisation_salt') || cl.nino),
    to_char(cl.claim_start_date, 'YYYY-MM'),
    cl.claim_status,
    cl.pension_type,
    CASE
        WHEN cl.weekly_amount < 100 THEN 'under 100'
        WHEN cl.weekly_amount < 150 THEN '100-149'
        WHEN cl.weekly_amount < 200 THEN '150-199'
        WHEN cl.weekly_amount < 250 THEN '200-249'
        ELSE '250 and over'
    END,
    cl.payment_frequency
FROM curated.claim cl;

-- Bonus A: small numbers suppressed ------------------------------------
CREATE TABLE analytics.agg_claims_by_region AS
SELECT
    d.region,
    d.age_band,
    CASE WHEN count(*) < 5 THEN NULL ELSE count(*) END AS claim_count
FROM analytics.fct_claim_anon f
JOIN analytics.dim_claimant_anon d
  ON d.person_pseudo_id = f.person_pseudo_id
GROUP BY d.region, d.age_band;

-- Bonus B: the analyst can read analytics and nothing else -------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'analyst_ro') THEN
        CREATE ROLE analyst_ro NOLOGIN;
    END IF;
END
$$;

GRANT USAGE ON SCHEMA analytics TO analyst_ro;
GRANT SELECT ON ALL TABLES IN SCHEMA analytics TO analyst_ro;

REVOKE ALL ON SCHEMA curated FROM analyst_ro;
REVOKE ALL ON ALL TABLES IN SCHEMA curated FROM analyst_ro;
REVOKE ALL ON SCHEMA clean   FROM analyst_ro;
REVOKE ALL ON ALL TABLES IN SCHEMA clean   FROM analyst_ro;
