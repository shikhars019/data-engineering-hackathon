-- ===========================================================================
-- REFERENCE SOLUTION - Team 5 - The Code Chaos   (ORGANISER ONLY)
-- Passes all 9 core and all 3 bonus tests.
-- ===========================================================================

TRUNCATE clean.payment;
TRUNCATE clean.claim;
TRUNCATE clean.claimant;

-- Given to the students already written.
INSERT INTO clean.claimant (nino, title, first_name, last_name, date_of_birth,
                            sex, marital_status, date_of_death, email, phone)
SELECT
    upper(btrim(nino)),
    replace(initcap(btrim(title)), '.', ''),
    initcap(btrim(first_name)),
    initcap(btrim(last_name)),
    util.to_date(date_of_birth, 'YYYY-MM-DD'),
    upper(btrim(sex)),
    CASE WHEN btrim(coalesce(marital_status, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE initcap(btrim(marital_status)) END,
    util.to_date(date_of_death, 'YYYY-MM-DD'),
    CASE WHEN btrim(coalesce(email, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE lower(btrim(email)) END,
    CASE WHEN btrim(coalesce(phone, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE replace(btrim(phone), ' ', '') END
FROM raw.claimant;


INSERT INTO clean.claim (claim_ref, nino, claim_status, pension_type,
                         claim_start_date, qualifying_years, weekly_amount,
                         deferral_indicator, payment_frequency)
SELECT
    c.claim_ref,
    upper(btrim(c.claimant_ref)),

    -- Task 1: seven ways of saying the same three things
    CASE upper(btrim(c.claim_status))
        WHEN 'ACTIVE'     THEN 'ACTIVE'
        WHEN 'A'          THEN 'ACTIVE'
        WHEN 'LIVE'       THEN 'ACTIVE'
        WHEN 'IN PAYMENT' THEN 'ACTIVE'
        WHEN 'INPAY'      THEN 'ACTIVE'
        WHEN 'SUSPENDED'  THEN 'SUSPENDED'
        WHEN 'SUSP'       THEN 'SUSPENDED'
        WHEN 'S'          THEN 'SUSPENDED'
        WHEN 'ON HOLD'    THEN 'SUSPENDED'
        WHEN 'CLOSED'     THEN 'CLOSED'
        WHEN 'C'          THEN 'CLOSED'
        WHEN 'CEASED'     THEN 'CLOSED'
        WHEN 'TERMINATED' THEN 'CLOSED'
    END,

    -- Task 2: two different coding schemes describing the same two products.
    -- Category A and Category B are both forms of the old Basic State Pension.
    CASE upper(btrim(c.pension_type))
        WHEN 'NEW STATE PENSION'   THEN 'NEW_STATE_PENSION'
        WHEN 'NSP'                 THEN 'NEW_STATE_PENSION'
        WHEN 'NEW'                 THEN 'NEW_STATE_PENSION'
        WHEN 'SINGLE TIER'         THEN 'NEW_STATE_PENSION'
        WHEN 'ST'                  THEN 'NEW_STATE_PENSION'
        WHEN 'BASIC STATE PENSION' THEN 'BASIC_STATE_PENSION'
        WHEN 'BSP'                 THEN 'BASIC_STATE_PENSION'
        WHEN 'BASIC'               THEN 'BASIC_STATE_PENSION'
        WHEN 'CATEGORY A'          THEN 'BASIC_STATE_PENSION'
        WHEN 'CAT A'               THEN 'BASIC_STATE_PENSION'
        WHEN 'CATEGORY B'          THEN 'BASIC_STATE_PENSION'
        WHEN 'CAT B'               THEN 'BASIC_STATE_PENSION'
    END,

    util.to_date(c.claim_start_date, 'YYYY-MM-DD'),
    util.to_number(c.qualifying_years)::int,
    util.to_number(c.weekly_amount),

    -- Task 3: a yes/no flag with eleven spellings
    upper(btrim(coalesce(c.deferral_indicator, 'N'))) IN ('Y', 'YES', 'TRUE', 'T', '1'),

    -- Task 4
    CASE upper(btrim(c.payment_frequency))
        WHEN 'WEEKLY'      THEN 'WEEKLY'
        WHEN 'W'           THEN 'WEEKLY'
        WHEN 'WKLY'        THEN 'WEEKLY'
        WHEN '1'           THEN 'WEEKLY'
        WHEN '4-WEEKLY'    THEN 'FOUR_WEEKLY'
        WHEN '4W'          THEN 'FOUR_WEEKLY'
        WHEN 'FOUR WEEKLY' THEN 'FOUR_WEEKLY'
        WHEN '4'           THEN 'FOUR_WEEKLY'
        WHEN '4 WEEKLY'    THEN 'FOUR_WEEKLY'
        WHEN 'QUARTERLY'   THEN 'QUARTERLY'
        WHEN 'Q'           THEN 'QUARTERLY'
        WHEN 'QTR'         THEN 'QUARTERLY'
        WHEN '13'          THEN 'QUARTERLY'
    END
FROM raw.claim c
-- Task 5: a claim for somebody who does not exist is not a claim
WHERE EXISTS (SELECT 1 FROM clean.claimant cc
              WHERE cc.nino = upper(btrim(c.claimant_ref)));


INSERT INTO clean.payment (payment_id, claim_ref, payment_date, amount,
                           payment_method, payment_status)
SELECT
    p.payment_id,
    p.claim_ref,
    util.to_date(p.payment_date, 'YYYY-MM-DD'),
    util.to_number(p.amount),
    -- Task 6: the lookup table is incomplete. 'Bank Tfr' and 'Giro' are not
    -- in it. Those rows must still come through, marked UNKNOWN.
    coalesce(m.standard_value, 'UNKNOWN'),
    CASE WHEN upper(btrim(p.payment_status)) IN ('SETTLED', 'S') THEN 'SETTLED'
         ELSE 'REVERSED' END
FROM raw.payment p
LEFT JOIN ref.code_mapping m
       ON m.domain = 'payment_method'
      AND m.raw_value = p.payment_method
-- Task 7: payments against claims that do not exist
WHERE EXISTS (SELECT 1 FROM clean.claim c WHERE c.claim_ref = p.claim_ref);
