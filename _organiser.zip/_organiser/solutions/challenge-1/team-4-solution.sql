-- ===========================================================================
-- REFERENCE SOLUTION - Team 4 - The Money Problem   (ORGANISER ONLY)
-- Passes all 8 core and all 3 bonus tests.
-- ===========================================================================

TRUNCATE clean.payment;
TRUNCATE clean.claim;
TRUNCATE clean.claimant;

-- Given to the students already written.
INSERT INTO clean.claimant (nino, title, first_name, last_name, date_of_birth,
                            sex, marital_status, date_of_death, email, phone)
SELECT
    upper(btrim(nino)),
    replace(initcap(btrim(title)), '.', ''),
    initcap(btrim(first_name)),
    initcap(btrim(last_name)),
    util.to_date(date_of_birth, 'YYYY-MM-DD'),
    upper(btrim(sex)),
    CASE WHEN btrim(coalesce(marital_status, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE initcap(btrim(marital_status)) END,
    util.to_date(date_of_death, 'YYYY-MM-DD'),
    CASE WHEN btrim(coalesce(email, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE lower(btrim(email)) END,
    CASE WHEN btrim(coalesce(phone, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE replace(btrim(phone), ' ', '') END
FROM raw.claimant;


-- Tasks 1 to 3: money as a number.
INSERT INTO clean.claim (claim_ref, nino, claim_status, pension_type,
                         claim_start_date, qualifying_years, weekly_amount,
                         deferral_indicator, payment_frequency)
SELECT
    claim_ref,
    upper(btrim(claimant_ref)),
    claim_status,
    pension_type,
    util.to_date(claim_start_date, 'YYYY-MM-DD'),
    util.to_number(qualifying_years)::int,
    util.to_number(
        replace(replace(replace(replace(btrim(weekly_amount),
            '£', ''), ',', ''), 'GBP', ''), ' ', '')
    ),
    upper(btrim(deferral_indicator)) IN ('Y', 'YES', 'TRUE', 'T', '1'),
    payment_frequency
FROM raw.claim;


-- Tasks 4 to 6: parse, filter, then de-duplicate. In that order.
INSERT INTO clean.payment (payment_id, claim_ref, payment_date, amount,
                           payment_method, payment_status)
WITH stripped AS (
    SELECT
        payment_id,
        claim_ref,
        util.to_date(payment_date, 'YYYY-MM-DD') AS payment_date,
        payment_method,
        upper(btrim(payment_status))             AS payment_status,
        -- accounting brackets mean a negative number
        btrim(amount) LIKE '(%'                  AS is_bracketed,
        replace(replace(replace(replace(replace(replace(btrim(amount),
            '(', ''), ')', ''), '£', ''), ',', ''), 'GBP', ''), ' ', '') AS digits
    FROM raw.payment
),
parsed AS (
    SELECT
        payment_id, claim_ref, payment_date, payment_method, payment_status,
        CASE WHEN is_bracketed THEN -util.to_number(digits)
             ELSE util.to_number(digits) END AS amount
    FROM stripped
),
kept AS (
    -- Task 5: FAILED and PENDING money never actually moved
    SELECT * FROM parsed
    WHERE payment_status IN ('SETTLED', 'REVERSED')
),
deduped AS (
    -- Task 6: the same payment entered twice is one payment.
    -- A reversal has the opposite sign, so it lands in its own group and
    -- survives. That is the whole point.
    SELECT k.*,
           ROW_NUMBER() OVER (PARTITION BY claim_ref, payment_date, amount
                              ORDER BY payment_id) AS rn
    FROM kept k
)
SELECT payment_id, claim_ref, payment_date, amount, payment_method, payment_status
FROM deduped
WHERE rn = 1;


-- Bonus: a statement per claim -------------------------------------------
DROP TABLE IF EXISTS clean.claim_payment_summary;
CREATE TABLE clean.claim_payment_summary AS
SELECT c.claim_ref,
       count(p.payment_id)::int                  AS payment_count,
       coalesce(sum(p.amount), 0)::numeric(12,2) AS total_paid
FROM clean.claim c
LEFT JOIN clean.payment p ON p.claim_ref = c.claim_ref
GROUP BY c.claim_ref;
