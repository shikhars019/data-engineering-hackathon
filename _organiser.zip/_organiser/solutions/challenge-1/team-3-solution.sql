-- ===========================================================================
-- REFERENCE SOLUTION - Team 3 - The Address Mess   (ORGANISER ONLY)
-- Passes all 8 core and all 3 bonus tests.
-- ===========================================================================

TRUNCATE clean.address;
TRUNCATE clean.claimant;

-- Task 1: given to the students already written.
INSERT INTO clean.claimant (nino, title, first_name, last_name, date_of_birth,
                            sex, marital_status, date_of_death, email, phone)
SELECT
    upper(btrim(nino)),
    replace(initcap(btrim(title)), '.', ''),
    initcap(btrim(first_name)),
    initcap(btrim(last_name)),
    util.to_date(date_of_birth, 'YYYY-MM-DD'),
    upper(btrim(sex)),
    CASE WHEN btrim(coalesce(marital_status, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE initcap(btrim(marital_status)) END,
    util.to_date(date_of_death, 'YYYY-MM-DD'),
    CASE WHEN btrim(coalesce(email, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE lower(btrim(email)) END,
    CASE WHEN btrim(coalesce(phone, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
         THEN NULL ELSE replace(btrim(phone), ' ', '') END
FROM raw.claimant;


INSERT INTO clean.address (address_id, nino, line_1, line_2, town, county,
                           postcode, valid_from, valid_to, is_current)
WITH squashed AS (
    -- Given: strip every space out and shout it
    SELECT
        a.*,
        replace(upper(btrim(a.postcode)), ' ', '') AS pc_squashed
    FROM raw.address a
),
tidied AS (
    SELECT
        address_id,
        upper(btrim(claimant_ref))              AS nino,
        initcap(btrim(address_line_1))          AS line_1,
        address_line_2                          AS line_2,
        initcap(btrim(town))                    AS town,
        county,
        -- Task 3: put exactly one space back, three from the end
        CASE WHEN length(pc_squashed) BETWEEN 5 AND 7
             THEN left(pc_squashed, length(pc_squashed) - 3)
                  || ' ' || right(pc_squashed, 3)
        END                                     AS postcode,
        util.to_date(valid_from, 'YYYY-MM-DD')  AS valid_from,
        util.to_date(valid_to,   'YYYY-MM-DD')  AS valid_to
    FROM squashed
),
usable AS (
    SELECT t.*
    FROM tidied t
    -- Task 5: drop addresses for people who do not exist
    JOIN clean.claimant c ON c.nino = t.nino
    -- Task 4: drop addresses whose postcode is not a postcode
    WHERE t.postcode ~ '^[A-Z]{1,2}[0-9][A-Z0-9]? [0-9][A-Z]{2}$'
),
ranked AS (
    SELECT
        u.*,
        -- Task 6: the most recent address is the current one.
        -- Do NOT trust the is_current flag.
        ROW_NUMBER() OVER (PARTITION BY nino
                           ORDER BY valid_from DESC, address_id DESC) AS rn
    FROM usable u
)
SELECT address_id, nino, line_1, line_2, town, county, postcode,
       valid_from, valid_to, (rn = 1) AS is_current
FROM ranked;


-- Bonus: pensioners per region -------------------------------------------
DROP TABLE IF EXISTS clean.address_summary;
CREATE TABLE clean.address_summary AS
SELECT r.region,
       count(*)::int AS claimant_count
FROM clean.address a
JOIN ref.postcode_area r
  ON r.area_code = substring(a.postcode from '^[A-Z]{1,2}')
WHERE a.is_current
GROUP BY r.region;
