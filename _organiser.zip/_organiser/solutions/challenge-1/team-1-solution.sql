-- ===========================================================================
-- REFERENCE SOLUTION - Team 1 - The Duplicate Claimants   (ORGANISER ONLY)
-- Passes all 9 core and all 3 bonus tests.
-- ===========================================================================

TRUNCATE clean.claimant;

INSERT INTO clean.claimant (nino, title, first_name, last_name, date_of_birth,
                            sex, marital_status, date_of_death, email, phone)
WITH tidied AS (
    SELECT
        record_id,
        ingested_at,
        -- Task 1: one spelling of the NINO
        upper(replace(replace(btrim(nino), ' ', ''), '-', ''))          AS nino,
        -- Bonus A: 'MR.' -> 'Mr'
        replace(initcap(btrim(title)), '.', '')                          AS title,
        -- Task 3: names
        initcap(btrim(first_name))                                       AS first_name,
        initcap(btrim(last_name))                                        AS last_name,
        util.to_date(date_of_birth, 'YYYY-MM-DD')                        AS date_of_birth,
        upper(btrim(sex))                                                AS sex,
        -- Task 4: 'N/A' and friends are not values
        CASE WHEN btrim(coalesce(marital_status, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
             THEN NULL ELSE initcap(btrim(marital_status)) END           AS marital_status,
        util.to_date(date_of_death, 'YYYY-MM-DD')                        AS date_of_death,
        CASE WHEN btrim(coalesce(email, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
             THEN NULL ELSE lower(btrim(email)) END                      AS email,
        -- Bonus C: digits only
        CASE WHEN btrim(coalesce(phone, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
             THEN NULL ELSE replace(btrim(phone), ' ', '') END           AS phone
    FROM raw.claimant
),
ranked AS (
    SELECT
        t.*,
        -- Task 5: the newest record wins
        ROW_NUMBER() OVER (PARTITION BY nino
                           ORDER BY ingested_at DESC, record_id DESC)    AS rn,
        -- Bonus B: any email this person has on any record
        max(email) OVER (PARTITION BY nino)                              AS fallback_email
    FROM tidied t
)
SELECT nino, title, first_name, last_name, date_of_birth, sex, marital_status,
       date_of_death, coalesce(email, fallback_email), phone
FROM ranked
WHERE rn = 1;
