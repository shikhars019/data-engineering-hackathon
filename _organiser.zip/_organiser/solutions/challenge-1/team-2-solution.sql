-- ===========================================================================
-- REFERENCE SOLUTION - Team 2 - The Date Disaster   (ORGANISER ONLY)
-- Passes all 8 core and all 3 bonus tests.
-- ===========================================================================

TRUNCATE clean.claim;
TRUNCATE clean.claimant;

INSERT INTO clean.claimant (nino, title, first_name, last_name, date_of_birth,
                            sex, marital_status, date_of_death, email, phone)
WITH parsed AS (
    SELECT
        upper(btrim(nino))                                              AS nino,
        replace(initcap(btrim(title)), '.', '')                         AS title,
        initcap(btrim(first_name))                                      AS first_name,
        initcap(btrim(last_name))                                       AS last_name,
        upper(btrim(sex))                                               AS sex,
        -- Tasks 1, 2 and 3: the source system tells you the format
        CASE source_system
            WHEN 'CIS'        THEN util.to_date(date_of_birth, 'YYYY-MM-DD')
            WHEN 'LEGACY_CSV' THEN util.to_date(date_of_birth, 'DD/MM/YYYY')
            WHEN 'DIGITAL'    THEN util.to_date(date_of_birth, 'DD-Mon-YYYY')
        END                                                             AS dob,
        CASE source_system
            WHEN 'CIS'        THEN util.to_date(date_of_death, 'YYYY-MM-DD')
            WHEN 'LEGACY_CSV' THEN util.to_date(date_of_death, 'DD/MM/YYYY')
            WHEN 'DIGITAL'    THEN util.to_date(date_of_death, 'DD-Mon-YYYY')
        END                                                             AS dod,
        CASE WHEN btrim(coalesce(marital_status, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
             THEN NULL ELSE initcap(btrim(marital_status)) END          AS marital_status,
        CASE WHEN btrim(coalesce(email, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
             THEN NULL ELSE lower(btrim(email)) END                     AS email,
        CASE WHEN btrim(coalesce(phone, '')) IN ('', 'N/A', 'UNKNOWN', 'NULL', 'n/a', '-')
             THEN NULL ELSE replace(btrim(phone), ' ', '') END          AS phone
    FROM raw.claimant
)
SELECT
    nino, title, first_name, last_name, dob, sex, marital_status,
    -- Task 5: a death before birth, or in the future, is an error not a death
    CASE WHEN dod IS NULL              THEN NULL
         WHEN dod <= dob               THEN NULL
         WHEN dod > DATE '2026-04-06'  THEN NULL
         ELSE dod
    END,
    email, phone
FROM parsed
-- Task 6: keep only believable birthdays
WHERE dob IS NOT NULL
  AND dob >= DATE '1930-01-01'
  AND dob <= DATE '2026-04-06';


-- Bonus A: the same pattern again, on the claim table.
INSERT INTO clean.claim (claim_ref, nino, claim_status, pension_type,
                         claim_start_date, qualifying_years, weekly_amount,
                         deferral_indicator, payment_frequency)
SELECT
    c.claim_ref,
    c.claimant_ref,
    c.claim_status,
    c.pension_type,
    CASE r.source_system
        WHEN 'CIS'        THEN util.to_date(c.claim_start_date, 'YYYY-MM-DD')
        WHEN 'LEGACY_CSV' THEN util.to_date(c.claim_start_date, 'DD/MM/YYYY')
        WHEN 'DIGITAL'    THEN util.to_date(c.claim_start_date, 'DD-Mon-YYYY')
    END,
    util.to_number(c.qualifying_years)::int,
    util.to_number(c.weekly_amount),
    upper(btrim(c.deferral_indicator)) IN ('Y', 'YES', 'TRUE', 'T', '1'),
    c.payment_frequency
FROM raw.claim c
JOIN raw.claimant   r  ON upper(btrim(r.nino)) = upper(btrim(c.claimant_ref))
JOIN clean.claimant cc ON cc.nino              = upper(btrim(c.claimant_ref));
