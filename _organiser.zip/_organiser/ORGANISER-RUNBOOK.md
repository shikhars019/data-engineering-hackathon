# Organiser Runbook — State Pension Data Hackathon

**Local only. Never push this to the student repo.**

---

## 1. What has been validated

Every reference solution was run against a real PostgreSQL server:

| | Core | Bonus |
|---|---|---|
| Team 1 — Duplicate Claimants | 9/9 | 3/3 |
| Team 2 — Date Disaster | 8/8 | 3/3 |
| Team 3 — Address Mess | 8/8 | 3/3 |
| Team 4 — Money Problem | 8/8 | 3/3 |
| Team 5 — Code Chaos | 9/9 | 3/3 |
| Challenge 2 | 12/12 | 3/3 |

**Totals: 54 core + 18 bonus, all passing.** Challenge 2 was run twice in
succession to confirm the pipeline is idempotent.

Also confirmed: every starter file runs without a SQL error before a student
touches it, and no team's dataset shares a single person with another team's
or with the Challenge 2 dataset.

### Where each team starts

Scores when they first run `./check.sh`, before doing anything:

| Team | Starting score | First win |
|---|---|---|
| 1 | **0 / 9** | Task 1 (names) → 2 tests, ~3 minutes |
| 2 | 1 / 8 | Task 1 is pre-solved and already green |
| 3 | 2 / 8 | Task 1 is pre-solved and already green |
| 4 | 1 / 8 | Task 1 (strip `£`) → 2 tests |
| 5 | 2 / 9 | Task 1 is pre-solved and already green |
| Challenge 2 | 8 / 12 | Tasks 2, 4, 7, 8 are the real work |

Bonus baselines after the v2 fixes: Teams 3 and 4 start on **0/3** (their
bonuses now require building a summary table); Teams 2 and 5 start on 1/3;
Team 1 and Challenge 2 on 0/3.

> **Watch Team 1.** They are the only team that starts on zero. Tell them at
> the outset: *"Do Task 1 first — you will see green within three minutes."*
> Otherwise a blank scorecard can read as "we are failing" when they are not.

---

## 2. Before the day

### A week ahead — run a setup session

This is the single biggest risk to the event. Do not let it happen on the
morning.

1. Everyone follows `docs/01-setup-macos.md`
2. Everyone runs `./preflight.sh` until it prints the green banner
3. **Collect the names of anyone who could not finish**

Homebrew needs admin rights for its first install. If it is blocked on a
machine, that machine cannot use Colima either — go straight to
`docs/99-fallback-postgres-app.md`, or hand them a hosted database.

### Team size and roles

**Three or four per team. Four is the maximum.** There is one database and
one file per team, so a team of five means two people watching.

The README gives students a Driver / Navigator / Checker rotation and tells
them to swap after every task. **Enforce it.** Left alone, one confident
student takes the keyboard for the whole hour and the other three learn
nothing - and the confident one is rarely the one who needed the day.

A useful intervention if you see a team going quiet: ask the person NOT
typing to explain what the current task is. If they cannot, swap the roles
there and then.

### A note on the audience

Some of these students, or their families, will have been on the other side
of a the agency counter. The framing deliberately puts them on the staff side -
capable, trusted, doing a real job - and that is the point of the day.

The briefs do say things like "miss a payment and somebody does not eat".
That is true, it is why the work matters, and it should stay. But be aware
it may land closer to home for some people in the room than for you, and do
not labour it.

### On the morning

- [ ] Confirm every laptop passes `./preflight.sh`
- [ ] Have the `postgres:16` image pre-pulled on a spare machine
- [ ] Have two spare hosted PostgreSQL connection strings ready
- [ ] Print the handouts (`_organiser/handouts/`)
- [ ] Have the reference solutions to hand — but see §5

---

## 3. Timings

| Time | What |
|---|---|
| 0:00–0:20 | Welcome. What a government agency does. What a data engineer actually does. |
| 0:20–0:30 | `./start.sh <team>`, confirm green banner, connect TablePlus |
| 0:30–1:30 | **Challenge 1** — hints at 20 / 35 / 45 minutes |
| 1:30–1:45 | Break. Two minutes per team: *what was your mess?* |
| 1:45–2:45 | **Challenge 2** |
| 2:45–3:00 | Scores, debrief |

### The opening twenty minutes

Do not open with schemas. Open with the problem.

> "Twelve million people get the State Pension. For a lot of them it is most
> of their income. Everything the agency knows about them lives in systems that were
> built decades apart and have never properly talked to each other.
>
> Somebody has to make that data trustworthy before anyone can use it. That
> person is a data engineer. Today that is you."

Worth saying explicitly:

- **You have the tests from the start.** That is not us making it easy — it
  is how real data teams work.
- **Breaking the database is free.** `./reset.sh`, twenty seconds.
- **Every team has a different problem.** Nobody can copy, and nobody is
  behind.

---

## 4. Hint ladder

Give hint 1 at **20 minutes**, hint 2 at **35**, hint 3 at **45** — but only
to teams who are actually stuck. A team making progress should be left alone.

### Team 1 — Duplicate Claimants
1. *"Have you done Task 1 yet? It takes three minutes and turns two tests green."*
2. *"Run `./explore.sh values raw.claimant nino`. How many ways is the same number written?"*
3. *"Look at the `ORDER BY` inside `ROW_NUMBER()`. It says `record_id`. Should the oldest record win, or the newest?"*

### Team 2 — Date Disaster
1. *"Task 1 is already done and its test already passes. Read it — Tasks 2 and 3 are the same line with one word changed."*
2. *"`06/05/1955` — is that the 6th of May or the 5th of June? Which system sent it?"*
3. *"Your dates parse now. What about the ones that say 1900, or 9999, or 2031? Task 6 is a `WHERE` clause."*

### Team 3 — Address Mess
1. *"Run `./explore.sh values raw.address postcode`. The brackets show you the spaces."*
2. *"Throw away ALL the spaces first, then put one back three characters from the end. `left()`, `right()` and `length()` are all you need."*
3. *"Which address does somebody live at now? Do not trust the flag — look at `valid_from`. Same `ORDER BY` idea as the postcode tasks."*

### Team 4 — Money Problem
1. *"Start with the `£`. One `replace()`, two tests green."*
2. *"What does `(185.15)` mean on a bank statement? It is not a typo."*
3. *"Before you de-duplicate: a reversal has the same claim, same date, same value as the payment it cancels. What is different about it, and will your de-duplication keep it?"*

### Team 5 — Code Chaos
1. *"Task 1 is finished and its test is already green. Read it — it is the pattern for everything else."*
2. *"Run `./explore.sh values raw.claim pension_type`. There are two different naming schemes in one column. Which era does `Category A` belong to?"*
3. *"Compare `ref.code_mapping` with what is actually in the data. Some values are missing from the mapping. What should happen to those payments?"*

### Challenge 2 (all teams)
1. *"Look at `analytics.dim_claimant_anon`. You have published the full postcode. How precise is a postcode?"*
2. *"Run `SELECT * FROM meta.etl_config`. Why is there a salt, and what happens without it?"*
3. *(For the k-anonymity test — this is the centrepiece, let them sit with it a while first.)* *"Run the query in Task 7 that shows the failing groups. Which age band keeps appearing? What if that band were wider?"*

---

## 5. When to show a solution

**Prefer not to.** A team that gets there at 55 minutes learns more than a
team handed the answer at 40.

If a team is genuinely stuck and demoralised, give them the *shape* rather
than the code: sit down, run their query with them, and ask what they expect
each column to contain.

Reference solutions are in `_organiser/solutions/`. Use them to answer your
own questions quickly, not to hand out.

---

## 6. Common failures and fixes

| Symptom | Cause | Fix |
|---|---|---|
| `Cannot connect to the Docker daemon` | Colima stopped | `colima start` |
| `port is already allocated` | Something on 55432 | `lsof -nP -iTCP:55432 -sTCP:LISTEN` |
| Data will not reload after editing SQL | initdb only runs on an empty volume | `./reset.sh` — the `-v` is what matters |
| `permission denied: ./start.sh` | Lost the executable bit | `chmod +x *.sh` |
| Loaded the wrong team's data | Ran `start.sh` with no argument first | `./reset.sh <team>` |
| All tests show `ERROR: relation ... does not exist` | Their SQL failed before creating anything | Look at the error `check.sh` printed above the scores |
| Tests were passing, now failing | Their last edit broke something | Good. That is the tests working. |

**The universal first response is `./reset.sh`.** Say so early and often, so
nobody is frightened of breaking anything.

---

## 7. Scoring

`./check.sh` prints `CORE n/m  BONUS n/m`. Teams report their own score.

Suggested weighting if you want a single winner:

| | |
|---|---|
| Core tests | 1 point each |
| Bonus tests | 2 points each |
| Explaining their approach at the debrief | up to 5 |

The last one matters most. A team that can say *"we kept the newest record
because that is the one the pensioner most recently confirmed"* has
understood the job better than a team that got one more test green.

Maximum without the debrief: Challenge 1 is 8–9 core + 3 bonus, Challenge 2
is 12 core + 3 bonus.

Note that teams have 8 or 9 core tests depending on their dataset. If you are
ranking, **use percentages, not raw counts**.

---

## 8. The debrief

Ask each team two questions:

1. **What was your mess, and what did you decide to do about it?**
2. **What did you have to decide that the data could not tell you?**

The second one is the point of the whole day. Every team had to make a
judgement call that no amount of SQL could settle:

- **Team 1** — which record wins when duplicates disagree
- **Team 2** — whether a wrong date is worse than a missing one
- **Team 3** — whether to drop a bad address or keep a person without one
- **Team 4** — whether something that looks like a duplicate actually is one
- **Team 5** — what to do with a value your lookup table has never heard of
- **Everyone** — how much detail to give up so that data can be published at all

Close on this: the SQL is learnable in a fortnight. The judgement is the job.

---

## 9. Rebuilding the materials

All generated files are reproducible and deterministic.

```bash
python _organiser/generator/generate.py      # datasets + curated + reference data
python _organiser/generator/verify_data.py   # checks the data without a database
python _organiser/generator/gen_tests.py     # rebuilds the tests from the manifest
```

Tests are generated from `manifest.json`, which the generator writes, so the
expected values can never drift from the data. **If you change the generator,
re-run all three.**

### After ANY change to the pack, run the consistency check

```bash
python _organiser/testing/check_consistency.py
```

The same fact - a task number, a test count, a line number, a command name -
is written down in up to five places: the starter, the brief, the printed
handout, the test file and this runbook. Nothing stops those drifting apart,
and during the build they drifted three separate times.

This checks all 48 of them: task numbers run 1..N and agree across starter,
brief and handout; the "YOUR JOB: N LINES" header matches the number of edit
markers; every line number quoted in a checklist actually lands on a marker;
every test's task number exists; the test counts quoted in each brief match
the test files; every script and link mentioned in the docs exists; and the
port story is the same everywhere.

`gen_tests.py` runs a subset of this automatically and refuses to build if a
test points at a task that does not exist.

**Note on the printed handout:** page 1 is at 268mm of the 278mm that fits on
A4. If you add to it, re-check the pagination before printing.

To re-validate against a real database:

```bash
python _organiser/testing/run_db_tests.py --all               # reference solutions
python _organiser/testing/run_db_tests.py --all --no-solution # starters
```

The connection string lives in `_organiser/testing/pgurl.txt`. The throwaway
cloud database used during the build should be deleted once the event is over.
