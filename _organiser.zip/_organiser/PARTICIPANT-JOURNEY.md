# Playing the hackathon as a participant

**Organiser-only. A dry run of Challenge 1, all five teams.**

I worked each team the way a student would: reset the database, read only the
brief and the starter file, looked at the data, wrote SQL, ran the tests,
iterated. I did not open the reference solutions.

Every team reached **100% of core and bonus tests**. Along the way I hit four
things that will cost real students real time, and two of them are serious.

---

## Scoreboard

| Team | Start | After 1st edit | After 2nd | After 3rd | Final |
|---|---|---|---|---|---|
| 1 — Duplicate Claimants | 0/9 | 2/9 | 7/9 | **7/9 (stuck)** | 9/9 + 3/3 |
| 2 — Date Disaster | 1/8 | 3/8 | 8/8 | — | 8/8 + 3/3 |
| 3 — Address Mess | 2/8 | 4/8 | 8/8 | — | 8/8 + 3/3 |
| 4 — Money Problem | 1/8 | 3/8 | 8/8 | — | 8/8 + 3/3 |
| 5 — Code Chaos | 2/9 | 6/9 | 9/9 | — | 9/9 + 3/3 |

Two or three edit-and-check cycles per team. The pacing is right: each cycle
moved several tests at once, which feels like progress.

---

## Team 1 — The Duplicate Claimants

**What I read.** The brief told me three source systems never talked to each
other, that the same pensioner appears more than once, and that the rule is
*the most recently ingested record wins*. It told me to start with Task 1
because I begin on zero.

**What I saw.** `./check.sh 1` gave me **0/9**. Then I looked:

```
record_id   nino           first_name  source_system
REC0000005  QQ-44-07-91-B  Joan        LEGACY_CSV
REC0000006    QQ402439D    Maureen     DIGITAL
REC0000007  QQ 54 26 05 A    frank     CIS
REC0000010  Qq149890a       STANLEY    CIS
```

The NINO problem was obvious immediately — dashes, inner spaces, padding,
mixed case. The name problem was **not** obvious, which is gap 4 below.

**What I wrote.** Task 1, exactly as the file suggested:

```sql
initcap(btrim(first_name))  AS first_name,
initcap(btrim(last_name))   AS last_name,
```

→ **2/9**. Under three minutes, and it proved the loop worked.

Then Tasks 2 and 3 together. The file said of `email` and `phone`: *"same
treatment as marital_status above"*. So I copied the `marital_status` CASE
literally, including its `initcap`:

```sql
CASE WHEN btrim(coalesce(email,'')) IN ('','N/A','UNKNOWN','NULL','n/a','-')
     THEN NULL ELSE initcap(btrim(email)) END AS email,
```

and normalised the NINO:

```sql
upper(replace(replace(btrim(nino), ' ', ''), '-', '')) AS nino
```

→ **7/9**. Only the two survivorship tests left.

**Where I got stuck.** I fixed the survivorship rule:

```sql
ROW_NUMBER() OVER (PARTITION BY nino
                   ORDER BY ingested_at DESC, record_id DESC) AS rn
```

Still **7/9**:

```
C1.08  expected [derek469@webmail.invalid]  got [Derek469@Webmail.Invalid]
       hint: "Task 5. QQ209469B has 3 records, each with a different email."
```

I had picked **the right record**. The survivorship logic was correct. The
test failed on capitalisation — and the hint still pointed me at Task 5,
which I had just done correctly. Nothing in the brief or the starter ever
said emails should be lower case, and no test names casing as the problem.

I only escaped because I could see the two strings side by side and spotted
the capital D. A student with 12 minutes left will not.

**Final:** 9/9 + 3/3 after lowercasing the email and doing the three bonuses,
which were genuine extra work (title tidying, email fallback, phone digits).

---

## Team 2 — The Date Disaster

**What I read.** Three systems, three date formats, and `source_system` tells
you which. Task 1 (CIS) is done and already passing.

**What I saw.** Baseline **1/8**, exactly as promised, which is reassuring —
one green test proves the harness works before you have done anything.

Then I ran the LOOK FIRST query from the starter:

```sql
SELECT source_system, date_of_birth
FROM raw.claimant
ORDER BY source_system, random() LIMIT 30;
```

**It returned 30 CIS rows and nothing else.** I checked:

```
source_system  rows_shown
CIS            30
```

The whole challenge is "three systems write dates three different ways", and
the query the file gives you to discover that shows you exactly one of them.
Sorting by `source_system` puts all ~540 CIS rows first, and the limit never
reaches the others. This is gap 2 below.

I found the formats with a different query:

```sql
SELECT DISTINCT ON (source_system) source_system, date_of_birth, date_of_death
FROM raw.claimant WHERE date_of_death <> '' ORDER BY source_system, random();
```

```
CIS         1958-02-08     N/A
DIGITAL     06-Sep-1952    16-Oct-1949
LEGACY_CSV  14/02/1947     N/A
```

**What I wrote.** The two format strings, in the birth CASE and the death
CASE → **3/8**. Then the exclusion rule and the impossible-death rule:

```sql
WHERE dob IS NOT NULL
  AND dob >= DATE '1930-01-01'
  AND dob <= DATE '2026-04-06'
```

```sql
CASE WHEN dod IS NULL             THEN NULL
     WHEN dod <= dob              THEN NULL
     WHEN dod > DATE '2026-04-06' THEN NULL
     ELSE dod END
```

→ **8/8**. Bonus A was real work — writing a whole second INSERT and joining
back to `raw.claimant` to find the source system. That is a good bonus.

**Nice detail:** `util.to_date` silently turned the `9999-12-31` sentinels
into NULL, so they never crashed the script. The `1900-01-01` ones parsed
fine and had to be caught by the range rule. Two different failure modes for
two different kinds of bad data, which teaches the right lesson.

---

## Team 3 — The Address Mess

**What I saw.** Baseline **2/8**. Here the exploration tool worked *well*:

```
[SW1A]       7      [ZZ99 9ZZZ]  5      [NULL]  4      [12345]  3
[-]          6      [TBC]        4      []      3      [N/A]    2
```

The junk sits at the top because bad postcodes repeat, while good ones are
unique. The opposite of Team 1's experience with names — worth knowing.

**What I wrote.** Squash-then-reinsert, following the hint exactly:

```sql
CASE WHEN length(pc_squashed) BETWEEN 5 AND 7
     THEN left(pc_squashed, length(pc_squashed) - 3)
          || ' ' || right(pc_squashed, 3)
END AS postcode
```

→ **4/8**. Then the two filters and the current-address rule:

```sql
JOIN clean.claimant c ON c.nino = t.nino
WHERE t.postcode ~ '^[A-Z]{1,2}[0-9][A-Z0-9]? [0-9][A-Z]{2}$'
...
ROW_NUMBER() OVER (PARTITION BY nino
                   ORDER BY valid_from DESC, address_id DESC) AS rn
```

→ **8/8 and 3/3 in the same run.**

**The problem: all three bonuses passed automatically.** I did no extra work
at all. "Every postcode area is recognised", "old addresses have an end
date", "94 claimants live in London" — all fall out of a correct core
solution. Team 3 finishes and has nothing left to do. Gap 3.

**Small wording issue:** the file says *"tidy these two the same way you
would a name"* and then lists three columns (`line_1`, `line_2`, `town`).
I had to guess which two.

---

## Team 4 — The Money Problem

**What I saw.** Baseline **1/8**. The data made the problem obvious:

```
[ £201.36  ]   [75.84]      [£126.40]
[£2,218.32]    [  2,054.00 ]    [(£328.64)]  REVERSED
```

Brackets clearly paired with `REVERSED`, which made the trap in the brief
click before I wrote anything.

**What I wrote.** Weekly amounts first:

```sql
util.to_number(
    replace(replace(replace(replace(btrim(weekly_amount),
        '£',''), ',',''), 'GBP',''), ' ','')
)
```

→ **3/8**, including the exact-total test `167245.75`, which is a very
satisfying thing to see go green.

Then payments: the same stripping plus `(` and `)`, the sign flip, the
status filter, and `WHERE rn = 1`.

→ **8/8 + 3/3.**

**The trap works.** Grouping by `amount` rather than its magnitude keeps
`+185.15` and `-185.15` in different groups, so the 120 reversals survive
naturally — *if* you follow the file's ordering. The brief's warning plus
the ordering of the CTEs makes the right thing the easy thing, and the
`C4.06` test would catch you immediately if you used `abs()`.

**Same bonus problem as Team 3** — all three bonuses passed with no extra
work. Notably `C4.B3` ("no payment dated after 2026-04-06") was failing at
47 mid-way and fixed itself once I applied the status filter.

---

## Team 5 — The Code Chaos

**What I saw.** Baseline **2/9**. The mapping gaps were immediately visible:

```
payment_method   standard_value
Bank Tfr         NULL
Giro             NULL
BACS             BACS
bacs             BACS
...
```

That one query makes the whole "the lookup table is incomplete" lesson land
before you write a line. The best discovery moment of the five.

**What I wrote.** Orphan filter and the `pension_type` CASE → **6/9**, the
biggest single jump of the whole exercise. Then deferral, frequency,
`coalesce(..., 'UNKNOWN')` and the orphan-payment filter → **9/9 + 3/3**.

**The `Category A`/`Category B` decision is genuinely good.** Nothing in the
data tells you they are the old pension. You have to read the brief, or know
it. And `C5.06` (642 New State Pension) catches you instantly if you guess
wrong.

**Structural oddity:** Task 5 (`payment_frequency`) appears in the numbered
task list, but its only test is a *bonus* (`C5.B2`). So a student doing all
the numbered tasks earns a bonus point without realising, and a student
skipping to "core only" has no signal that Task 5 is optional.

---

## Gaps, in priority order

### 1. Team 1: the email-casing dead end — **fix before the event**

Doing Task 5 correctly still leaves `C1.08`/`C1.09` red, and the hint points
back at Task 5. The real cause is `initcap` on an email, which nothing warns
against and no test names.

Three things combine:
- the starter says *"same treatment as marital_status"*, and that example uses `initcap`
- the brief never says emails should be lower case
- the only failing test is about **survivorship**, so the hint misdirects

**Fix:** compare case-insensitively in the two anchor tests — the lesson is
survivorship, not capitalisation — *and* make the starter explicit:
`lower(btrim(email))`, not `initcap`.

### 2. Team 2: the discovery query returns only one source system — **fix before the event**

`ORDER BY source_system, random() LIMIT 30` shows 30 CIS rows. The entire
challenge is that three systems differ.

**Fix:** one line in `challenges/challenge-1/team-2/solution.sql:35`:

```sql
SELECT DISTINCT ON (source_system) source_system, date_of_birth
FROM raw.claimant ORDER BY source_system, random();
```

(The version in the BRIEF has no `ORDER BY` and is fine — only the starter is wrong.)

### 3. Bonus tasks are free for Teams 3 and 4 — **fix if you want a fair contest**

All six bonuses passed automatically the moment core was correct. Teams 1, 2
and 5 had real bonus work; Teams 3 and 4 had none. Those teams will finish
around the 40-minute mark with nothing to do, and the bonus round cannot
separate anybody.

**Fix:** give Teams 3 and 4 bonuses that need new SQL — for example, Team 3:
*"which region has the most pensioners?"*; Team 4: *"reconcile each claim's
payments against weekly_amount × weeks and list any that disagree"*.

### 4. `explore.sh values` hides low-frequency anomalies — **worth fixing**

It sorts by frequency. For `first_name` the first bad value is at **row 37**
and the first whitespace one at **row 59** of a 60-row limit. The first
screen is all clean names, so a student concludes the names are fine. For
`postcode` and the code columns it works well, because there the junk
repeats — so the tool is only misleading on high-cardinality columns, which
is exactly Team 1's case.

**Fix:** print a summary line above the list — *"1500 values: 557 have
leading/trailing spaces, 903 are not Title Case, 341 are placeholders"*.
That tells you what is wrong without scrolling.

### 5. Smaller things

- **Team 3:** *"tidy these two"* followed by three columns. Say which two.
- **Team 2:** `C2.B3` passes vacuously while `clean.claim` is empty (0 rows,
  0 violations), so the baseline reads `BONUS 1/3` before any work. Harmless
  but slightly dishonest.
- **Team 5:** Task 5's only test is a bonus. Either label it "(bonus)" in the
  task list or promote the test to core.
- **Team 1 starts on 0/9** while everyone else starts on 1–2. Already
  flagged in the runbook; the brief handles it, but facilitators should say
  it out loud.

---

## What worked well

- **Two to three edit-check cycles per team.** Each cycle moved several tests.
  Nobody grinds on one test for twenty minutes.
- **`util.to_date` / `util.to_number` never crashed a script.** Bad input
  surfaced as a failing test with a readable number, not a stack trace. This
  is the single best decision in the build.
- **Exact-total tests** (`167245.75`, `4612417.76`) are far more convincing
  than row counts. You know you got it right.
- **The traps land.** Team 4's reversals and Team 5's incomplete mapping both
  made me stop and think, and both are caught immediately by a named test.
- **Starting scores of 1–2** reassure before any work is done.
- **`TRUNCATE` at the top of every file** meant re-running was always safe. I
  never once needed `./reset.sh` mid-team.


---

# Fixes applied, and re-validated

All four gaps are fixed. Everything below was re-run against the live
database afterwards.

| Gap | Fix | Proof |
|---|---|---|
| **1. Team 1 email dead end** | `C1.08`/`C1.09` now compare with `lower(email)`, so the survivorship tests test survivorship and not capitalisation. The starter also spells it out: *"An email address is NOT a word - use `lower(btrim(email))`"* | Replayed the exact stuck state (Task 5 correct, email `initcap`'d): **was 7/9, now 9/9** |
| **2. Team 2 discovery query** | Starter now uses `SELECT DISTINCT ON (source_system) ...`, with a note explaining why a plain `LIMIT` would not work | Query now returns one row per system: CIS `1900-01-01`, DIGITAL `01-Jan-1900`, LEGACY_CSV `11/03/1958` |
| **3. Free bonuses, Teams 3 and 4** | Both teams now build a summary table of their own. Team 3: `clean.address_summary` (region, claimant_count) via `ref.postcode_area`. Team 4: `clean.claim_payment_summary` (claim_ref, payment_count, total_paid), which needs a `LEFT JOIN` so claims with no payments still appear, and `coalesce` so they read `0.00` | Team 4 bonus baseline dropped **1/3 to 0/3**; Team 3 stays 0/3. Reference solutions still make both 3/3 |
| **4. `explore.sh values` hid anomalies** | The command now prints a data-quality summary *before* the value list, and tells you what to run if the numbers show a problem you cannot see | On `raw.claimant.first_name` it now reports `stray_spaces 557`, `not_title_case 903` on the first screen — previously invisible until row 37 |

## Re-validation after the fixes

```
  OK  team 1 solution          core  9/9    bonus  3/3
  OK  team 2 solution          core  8/8    bonus  3/3
  OK  team 3 solution          core  8/8    bonus  3/3
  OK  team 4 solution          core  8/8    bonus  3/3
  OK  team 5 solution          core  9/9    bonus  3/3
  OK  challenge 2              core 12/12   bonus  3/3
```

Starters, all still running cleanly before any edit:

```
  team 1   core 0/9   bonus 0/3          team 4   core 1/8   bonus 0/3
  team 2   core 1/8   bonus 1/3          team 5   core 2/9   bonus 1/3
  team 3   core 2/8   bonus 0/3          challenge 2  core 8/12  bonus 0/3
```

## Left alone deliberately

- **Team 3's "tidy these two" listing three columns.** Tidying `line_2` as
  well is harmless, so the ambiguity costs nothing.
- **Team 2's `C2.B3` passing vacuously** on an empty `clean.claim`. Making
  it strict would mean failing a student for not having started a bonus,
  which is worse than a free point.
- **Team 5's Task 5 mapping only to a bonus test.** The task table already
  says `(bonus B)` in the "turns green" column, which is honest enough.
- **Team 1 starting on 0/9.** Fixing it would mean pre-solving a task, which
  would cost Team 1 the best early win in the set. The brief, the handout
  and the runbook all tell facilitators to point them at Task 1.
