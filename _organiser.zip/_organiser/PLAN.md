# State Pension Data Hackathon — Build Plan

**Audience:** NEET students as junior data engineers at a government agency. **Assume no prior SQL.**
**Format:** 2 × 1-hour challenges, 5 teams, local PostgreSQL on MacBooks
**Stack:** PostgreSQL in Docker (Colima runtime, **no Docker Desktop licence needed**) + a GUI client for browsing.
No Python. No bash authoring. No local Postgres install.
**Repo:** https://github.com/shikhars019/data-engineering-hackathon

> **v3.** Difficulty recalibrated for genuine beginners — tuned so **all five teams finish the core
> tasks**, with bonus tasks providing the competitive edge (§2). Environment is **Docker via Colima**,
> since no Docker Desktop licence is available (§7).

---

## 1. Core design decisions

### 1.1 Challenge 1 is per-team; Challenge 2 is shared — how they stay independent

Each team loads **its own corrupted dataset** into a `raw` schema and cleans it into a `clean` schema.
The five datasets contain different people and different defect profiles, so no team's work depends
on another's. Teams are on separate laptops with separate databases.

**Challenge 2 must not be blocked by Challenge 1.** Challenge 2 does *not* read the team's `clean`
schema. Every team gets a pre-loaded `curated` schema — clean, conformed, identical for all five.
The narrative: *"the overnight pipeline has already landed clean data; your job is to publish it safely."*

The `curated` population is **entirely different people** from any team's Challenge 1 data, so it
cannot be used to reverse-engineer Challenge 1 answers.

```
   Challenge 1 (unique per team)          Challenge 2 (identical for all)
   raw.*  ──student SQL──▶  clean.*       curated.*  ──student ETL──▶  analytics.*
```

### 1.2 Test-driven by design

Students get the tests **at the start**. The tests *are* the spec — it removes all ambiguity about
"am I done yet", and it is the single most valuable habit they can take away. Target DDL is provided
pre-built and empty with real constraints, so a bad transform fails loudly at `INSERT` rather than
silently producing garbage.

### 1.3 The syntax is the easy part; the judgement is the challenge

The first draft had this backwards. Machinery is pre-written; the **interesting decision** is the blank:

```sql
ROW_NUMBER() OVER (
    PARTITION BY nino_clean
    ORDER BY  -- TODO: which record should win? Most complete? Most recent?
)
```

That `ORDER BY` *is* the data engineering lesson. Writing `ROW_NUMBER()` from memory never was.

---

## 2. Difficulty calibration

### 2.1 What a beginner can actually do in an hour

| Realistic | Not realistic cold |
|---|---|
| Run a provided script, read the output | Write a window function from scratch |
| Change a value or column in a provided query | Author a postcode regex |
| Write `SELECT ... WHERE` | Date-range overlap detection |
| Write `GROUP BY ... HAVING` | `GRANT`/`REVOKE` role modelling |
| Copy a worked pattern and adapt it | Design k-anonymity from first principles |

### 2.2 Three tiers inside every challenge

- **Tier 1 — Guided** (tasks 1–3): SQL ~90% written, one blank to fill. ~5 min each. *Everyone finishes.*
- **Tier 2 — Patterned** (tasks 4–6): one column worked as an example, they apply the shape to two more. ~8 min each. *Most teams finish.*
- **Tier 3 — Bonus**: open-ended. *Separates the teams.*

### 2.3 Non-negotiable build rules

1. **Starter files run cleanly from second zero.** Tests fail, then go green. Never a syntax-error cliff.
2. **No task exceeds ~10 lines of SQL to type.** Beginners type slowly and typo often.
3. **No student writes regex.** Where one is needed it is provided, and they use it.
4. **First test goes green inside 10 minutes.** Early win or you lose the room.
5. **~8 core + 3 bonus tests per challenge.** A progress bar you can read at a glance.
6. **One command for the feedback loop:** `./check.sh` runs their SQL then the tests.

### 2.4 Cut from v1 as misjudged

| Cut | Why |
|---|---|
| Address validity-period **overlap detection** (Team 2) | Genuinely hard; experienced engineers get it wrong |
| Student-authored **postcode regex** (Team 3) | Intermediate-plus and brutal to debug |
| European decimal `185,15` (Team 4) | A third parsing rule that added nothing |
| **`GRANT`/`REVOKE` role model** (Challenge 2) | Senior-level; cryptic failures |
| **Writing bash** (Challenge 2) | They *run* a provided pipeline script instead |
| Idempotency requirement, audit table (Challenge 2) | Demoted to bonus |
| Fuzzy/transposed name matching (Team 1) | Demoted to bonus |

---

## 3. Data model

Five tables, ~2,000 claimants, ~15,000 payments per dataset.

### `raw` schema — what students receive (deliberately ugly)
All columns `TEXT`, no keys, no constraints.

| Table | Columns |
|---|---|
| `raw.claimant` | `record_id, nino, title, first_name, last_name, date_of_birth, sex, marital_status, date_of_death, email, phone, source_system, ingested_at` |
| `raw.address` | `address_id, claimant_ref, address_line_1, address_line_2, town, county, postcode, valid_from, valid_to, is_current` |
| `raw.claim` | `claim_ref, claimant_ref, claim_status, pension_type, claim_start_date, qualifying_years, weekly_amount, deferral_indicator, deferral_weeks, payment_frequency, last_updated` |
| `raw.payment` | `payment_id, claim_ref, payment_date, amount, payment_method, payment_status, created_at` |
| `ref.postcode_area` | `area_code, region` (clean lookup — teaches joins) |
| `ref.code_mapping` | `domain, raw_value, standard_value` (deliberately incomplete) |

Three source systems (`CIS`, `LEGACY_CSV`, `DIGITAL`) explain *why* the data is inconsistent.

### `clean` schema — Challenge 1 target (DDL provided, students populate)
Typed and constrained: `nino CHAR(9)` with a format `CHECK`, real `DATE`s, `NUMERIC(10,2)` money,
`BOOLEAN` flags, `FOREIGN KEY`s between all four tables.

### `curated` schema — Challenge 2 input (pre-loaded, same for all teams)
Same shape as `clean`, different population, already clean.

### `analytics` schema — Challenge 2 target (students build)
`dim_claimant_anon`, `fct_claim_anon`, `agg_claims_by_region`.

---

## 4. Challenge 1 — five team variants

**Shared baseline in all five:** whitespace and casing noise, `''` vs `NULL` vs literal
`'NULL'`/`'N/A'`/`'UNKNOWN'`, and a few exact duplicate rows.

> **Deliberately off-limits as exercises.** `sex` is carried as a clean, tidy `M`/`F` in every dataset
> — realistic for the agency data, never corrupted, never part of any Challenge 1 task. `title` likewise.
> Neither is something a room of students should spend their hour standardising.

| Team | Title | Core tasks (guided → patterned) | Bonus |
|---|---|---|---|
| **1** | The Duplicate Claimants | Normalise NINO with `UPPER`/`REPLACE`; find duplicates with `GROUP BY ... HAVING COUNT(*) > 1`; pick the survivor — window function pre-written, they choose the `ORDER BY` rule | Name variants (`Jon`/`John`, `MacDonald`), transposed first/last name |
| **2** | The Date Disaster | Three date formats via `CASE` + `TO_DATE` (format strings to fill in, `source_system` decides which); sentinel dates (`9999-12-31`, `1900-01-01`) → `NULL`; flag death-before-birth with a simple `<` | Claim start before age 60; DOB in the future |
| **3** | The Address Mess | Tidy postcodes with `UPPER`/`REPLACE`/`LEFT`/`RIGHT` (no regex written); validate using a **provided** regex; find orphan addresses with `LEFT JOIN ... IS NULL`; one-current-address (pre-written, they pick the tie-break) | Postcode duplicated into the `town` field; join to `ref.postcode_area` for region |
| **4** | The Money Problem | Strip `£` and `,` with `REPLACE` then cast to `NUMERIC(10,2)`; exclude `FAILED` payments with a `WHERE`; find double-posted payments with `GROUP BY`/`HAVING`; **keep the legitimate reversals** | Reconcile payment totals against `weekly_amount`; accounting negatives `(185.15)` |
| **5** | The Code Chaos | `CASE` mappings for `claim_status`, `pension_type`, `payment_method`; parse `deferral_indicator` booleans (`Y`/`YES`/`TRUE`/`1`/`N`/`0`/`''`); orphan claims via anti-join | Handle values missing from `ref.code_mapping`; reconcile the two competing `pension_type` schemes |

**The two deliberate traps, both conceptual rather than syntactic:**
Team 4's reversals must survive de-duplication (a clearly-named test fails if they're deleted), and
Team 5's mapping table is incomplete on purpose. These reward thinking, not pattern-matching.

Team 5 was already correctly pitched, so it is the benchmark the other four are tuned against.

---

## 5. Challenge 2 — identical for all teams

**Brief:** *Analysts and researchers need this data. They must never see personal information.
Publish a safe analytics layer.*

### Core (5 tasks)
1. **Create the analytics schema** — one provided command. Instant first win.
2. **Pseudonymise** — `person_pseudo_id = md5(salt || nino)`, stable across tables so joins still work.
   Salt sits in a config table outside `analytics`. (`md5()` is built-in — no extension to install.)
3. **Generalise age** — DOB → age band (60-64 … 85+) via `CASE`.
4. **Generalise location** — postcode → area via `LEFT`, joined to `ref.postcode_area` for region.
5. **Suppress** — no names, NINO, email, phone, full address or exact dates reach `analytics`.
   *The most important lesson of the day is also the easiest task: don't put them in the `SELECT`.*

### Then the set-piece
They run the tests and **k-anonymity fails** — the output *names the groups that are too small*
on `(age_band, sex, region)`. Their job is to merge two age bands and re-run until every group
has ≥ 5 people. They experience k-anonymity as a problem they fixed, not a theory they were told.
The dataset is sized so a handful of groups fail: enough to be real, few enough to be tractable.

### Bonus
Small-number suppression (`CASE WHEN count(*) < 5 THEN NULL`); a guided one-line `GRANT`;
a lineage table recording run timestamp and row counts.

### Pipeline
`run_pipeline.sh` is **provided**. They run it and watch stages execute in order — feeling what a
pipeline is without fighting shell syntax. Bonus: add one stage to it.

**Standout test:** one check computes plain `md5(nino)` and asserts no `person_pseudo_id` matches it,
so an unsalted hash fails. One line for them; the concept lands harder than any slide.

---

## 6. Test harness

```bash
./check.sh          # runs your SQL, then the tests — the whole feedback loop
```

Everything runs through `docker compose exec -T db psql ...`, so **students need no local Postgres
and never type a `psql` command themselves.**

```
 #      | TYPE  | TEST                                   | EXPECTED | ACTUAL | RESULT
--------+-------+----------------------------------------+----------+--------+--------
 C1.01  | core  | No duplicate NINOs in clean.claimant   | 0        | 0      | PASS
 C1.02  | core  | All NINOs are 9 characters             | 0        | 3      | FAIL
 ...
 CORE 7/8    BONUS 1/3
```

**Implementation:** a plpgsql helper `test.check(id, type, name, expected, sql_text)` runs each
assertion in its own `BEGIN ... EXCEPTION WHEN OTHERS` block. A broken student query yields
`ERROR: <message>` on one row instead of killing the run — essential when beginners iterate fast.
Target tables are created empty by setup, so tests always execute rather than erroring on missing objects.

**~8 core + 3 bonus per challenge.** Test names are written as plain English goals, not jargon.

---

## 7. Student environment — Docker CLI + Colima

**macOS cannot run containers natively.** Docker Desktop was providing the Linux VM; without a
licence we need a free replacement for that layer. **Colima** is it — Colima, Lima, the Docker CLI
and Compose are all Apache 2.0, and Docker Desktop is never installed.

```bash
brew install colima docker docker-compose
colima start
./start.sh 3          # team number
```

### Why Docker earns its keep here

| Win | Detail |
|---|---|
| **Zero-step data load** | The official image auto-runs `/docker-entrypoint-initdb.d/*.sql` on first boot. Database, schemas, reference data and the team's corrupted dataset all appear inside `docker compose up`. |
| **A reset button** | Students *will* mangle their data in hour one. `./reset.sh` gives a pristine database in ~20s. |
| **Version parity** | Identical Postgres and locale on every machine, so tests cannot drift on someone's older install. |
| **No local Postgres** | Everything runs via `docker compose exec`. Nothing to install but the runtime. |

### Gotchas, each handled in code not prose

| Risk | Mitigation |
|---|---|
| **Port 5432 already in use** | Map host port **`55432`**. Removes the whole class of problem for free. |
| **Init scripts run only once** — they fire only on an empty data directory, so restarts and SQL edits appear to do nothing | `reset.sh` does `docker compose down -v`. The `-v` is the bit everyone forgets. Called out prominently in the docs, not buried. |
| **Homebrew's compose plugin isn't wired up** — `docker-compose` works, `docker compose` often doesn't until symlinked into `~/.docker/cli-plugins` | Scripts detect which form works and use it. Students never meet this. |
| **Colima not running** → `Cannot connect to the Docker daemon` | `start.sh` checks `docker info` and starts Colima itself. |
| **Init errors hide in logs** — a bad SQL file makes the container exit with no visible cause | `start.sh` health-checks and surfaces `docker compose logs db` automatically. Validation guarantees zero init errors to begin with. |
| **Image pull over event wifi** | `preflight.sh` pre-pulls `postgres:16` days beforehand. |

**Compose, not a Dockerfile.** Stock `postgres:16` image with SQL bind-mounted in. No build step means
no build errors and nothing to host — a custom image would bake in data we'd then have to distribute.

### The three commands students learn

```bash
./start.sh 3      # bring up the DB for team 3, load everything, print connection details
./check.sh        # run my SQL, then the tests
./reset.sh        # pristine database, start over
```

Then connect the GUI to `localhost:55432`.

**GUI client for browsing** — TablePlus (free tier ample; DBeaver CE as the fully-free alternative).
Scripts run the tests; the GUI is how they *see* the mess. Spotting `'  John  '` versus `'John'`
in a grid is immediate; in wrapped terminal output it is not.

### Risk controls

- **`preflight.sh`** — verifies Colima, Docker, compose, the image and a test container; prints a green
  banner. **Run in a short session days before the event.** Setup is the biggest threat to the agenda,
  and it surfaces any Homebrew/Colima policy blocks while there is still time to act.
- **Postgres.app appendix** — a genuine escape hatch. If Homebrew or Colima is blocked on a machine,
  that team is working again in two minutes instead of losing the session. One extra document.
- **Hosted-Postgres contingency** — free Neon/Supabase instance as a last resort. Organiser runbook only.

---

## 8. Repository layout (pushed to GitHub)

```
data-engineering-hackathon/
├── README.md                       # front door, agenda, quick start
├── docker-compose.yml              # postgres:16, host port 55432, SQL bind-mounted
├── start.sh                        # ./start.sh 3 — starts Colima if needed, loads team 3's data
├── check.sh                        # run my SQL + tests
├── reset.sh                        # down -v + up — pristine database
├── preflight.sh                    # "am I ready?" — run days before the event
├── docs/
│   ├── 01-setup-macos.md           # Colima + Docker CLI + GUI client, step by step
│   ├── 02-challenge-1.md
│   ├── 03-challenge-2.md
│   ├── 04-running-tests.md         # reading PASS/FAIL, troubleshooting
│   ├── 05-sql-cheatsheet.md        # the ~20 things needed today, with examples
│   ├── 06-glossary.md              # NINO, State Pension, PII, pseudonymisation, k-anonymity
│   └── 99-fallback-postgres-app.md # escape hatch if Homebrew/Colima is blocked
├── initdb/                         # auto-run by the container on first boot
│   ├── 01_schema_raw.sql
│   ├── 02_reference_data.sql
│   ├── 03_load_raw_team1.sql … team5.sql
│   ├── 04_schema_clean.sql
│   └── 05_curated_seed.sql
├── challenges/
│   ├── challenge-1/team-1/{BRIEF.md,starter.sql} … team-5/
│   └── challenge-2/{BRIEF.md,starter.sql,run_pipeline.sh}
└── tests/
    ├── run_tests.sh
    ├── _helpers.sql
    ├── challenge1_team1_tests.sql … team5
    └── challenge2_tests.sql
```

## 9. Organiser material (local in `_organiser/`, gitignored, never pushed)

- `generator/generate.py` — seeded, deterministic generator for all datasets
- `solutions/challenge-1/team-{1..5}-solution.sql` and `solutions/challenge-2/`
- `ORGANISER-RUNBOOK.md` — timings, facilitator script, per-team **hint ladder** (hints at 20 / 35 / 45
  min), common failure modes, the hosted-Postgres contingency
- `MARKING.md` — scoring and a light rubric
- `validate.sh` — end-to-end proof

## 10. Validation before you push

I'll run the students' own `docker-compose.yml` locally to prove:

1. `./start.sh N` brings up a fully loaded database from empty for all five teams, with zero init errors.
2. Tests run against empty `clean` schemas and report FAIL — never crash.
3. Each of the five reference solutions turns **all core tests green**.
4. The Challenge 2 solution passes, including the k-anonymity fix.
5. Every starter file executes without error before any student edits it *(rule 2.3.1)*.
6. `./reset.sh` returns a mangled database to a pristine, fully-loaded state.
7. Scripts work with both `docker compose` and `docker-compose` invocation forms.

I'll report actual output from these runs rather than asserting it works.

## 11. Agenda (3 hours)

| Time | Session |
|---|---|
| *Days before* | **Setup session — install Colima, pre-pull the image, run `preflight.sh` until green** |
| 0:00–0:20 | Welcome; what the agency does; what a data engineer does; why dirty data costs money |
| 0:20–0:30 | Preflight re-check, teams settle |
| 0:30–1:30 | **Challenge 1** — hint ladder at 20/35/45 min |
| 1:30–1:45 | Break + 2-minute show-and-tell per team |
| 1:45–2:45 | **Challenge 2** |
| 2:45–3:00 | Scores, debrief, "what this job looks like in real life" |

## 12. Build order

1. `generator/generate.py` → all datasets
2. Schema DDL, `docker-compose.yml`, `start.sh`, `check.sh`, `reset.sh`, `preflight.sh`
3. Test harness helpers → Challenge 1 tests ×5 → Challenge 2 tests
4. Reference solutions ×6, written against the tests
5. Validation loop against real containers until green
6. Briefs and starters — **written last, so they can be tuned to the verified solutions**
7. README and docs
8. Organiser runbook, hint ladders, marking guide
9. `git init`, `.gitignore` excluding `_organiser/`, commit — **push only on your say-so**

---

## Open point

**Team names** — currently `team-1` … `team-5`. Happy to use real names if you have them.
